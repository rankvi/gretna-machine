import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.pexels.com",
        pathname: "/photos/**",
      },
    ],
  },
  async redirects() {
    return [
      // Legacy WordPress backup / duplicate URLs from the existing site.
      { source: "/backups/:path*", destination: "/", permanent: true },
      { source: "/capabilities-2", destination: "/services/cnc-machining-houston-tx", permanent: true },
      { source: "/capabilities/aerospace", destination: "/industries/aerospace-cnc-machining", permanent: true },
      { source: "/capabilities/aerospace-2", destination: "/industries/aerospace-cnc-machining", permanent: true },
      { source: "/capabilities", destination: "/equipment-list", permanent: true },
      { source: "/category/:path*", destination: "/resources", permanent: true },
      { source: "/operations", destination: "/equipment-list", permanent: true },
      { source: "/services", destination: "/services/cnc-machining-houston-tx", permanent: true },
      { source: "/industries", destination: "/industries/aerospace-cnc-machining", permanent: true },
      { source: "/services/cnc-machining", destination: "/services/cnc-machining-houston-tx", permanent: true },
      { source: "/request-quote", destination: "/request-a-quote", permanent: true },
      { source: "/contact-us", destination: "/contact", permanent: true },
      { source: "/about-us", destination: "/about", permanent: true },
    ];
  },
};

export default nextConfig;
