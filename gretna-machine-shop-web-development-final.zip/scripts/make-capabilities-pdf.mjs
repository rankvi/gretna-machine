import { writeFileSync, mkdirSync } from "node:fs";

const lines = [
  ["B", "GRETNA MACHINE SHOP, INC."],
  ["N", "The Pinnacle of Precision  |  Manufacturing Precision Components from Subsea to Mars"],
  ["N", "3450 Lang Rd., Houston, TX 77092  |  713-690-7328  |  quotes@gretnamachine.com"],
  ["N", "AS9100 Rev D  |  ISO 9001:2015  |  ITAR Registered  |  SBA HUBZone  |  SBA WOSB"],
  ["N", "DUNS 054633755  |  CAGE 0AXC7  |  SAM Registered  |  100% Women & Minority Owned"],
  ["N", ""],
  ["B", "COMPANY PROFILE"],
  ["N", "Founded 1980. 50,000 sq. ft. air-conditioned lean manufacturing facility in Houston, TX."],
  ["N", "50+ employees. In-house certified Professional Engineer (PE). ERP barcode order tracking."],
  ["N", "Class-A machinist supervisors program all CAD/CAM in-house."],
  ["N", ""],
  ["B", "NAICS CODES"],
  ["N", "332510 Hardware Mfg  |  332710 Machine Shops  |  332721 Precision Turned Products"],
  ["N", "332912 Metal Valve & Pipe Fitting  |  336411 Aircraft Mfg"],
  ["N", "336413 Aircraft Parts & Auxiliary Equipment  |  336419 Guided Missile & Space Vehicle Parts"],
  ["N", ""],
  ["B", "TRUE 5-AXIS CNC MILLING"],
  ["N", "Okuma MU5000V-L: 12,000 RPM spindle, 1,000 RPM platter, travels 31.5 x 41.400 x 23.700 in,"],
  ["N", "  max platter swing 27.5 in, max load 1,100 lbs (true 5-axis with vertical lathe)."],
  ["N", "Okuma M460V-5AX: 12,000 RPM, travels 30.0 x 18.0 x 18.0 in, swing 23.5 in, 600 lbs."],
  ["N", "HAAS UMC-1000: 8,100 RPM, travels 40.0 x 25.0 x 29.0 in, swing 34.0 in, 1,000 lbs."],
  ["N", ""],
  ["B", "4-AXIS VERTICAL & HORIZONTAL CNC MILLING"],
  ["N", "Okuma Millac 1052V II: 6,000 RPM, 80.7 x 41.7 x 31.5 in, 5,551 lbs table load."],
  ["N", "Okuma MB-5000H horizontal: 12,000 RPM TCPC, 29.9 x 29.9 x 31.89 in, 19.69 in pallet."],
  ["N", "Doosan DNM 6700: 8,000 RPM, 51.1 x 26.37 x 24.6 in, 2,866 lbs."],
  ["N", "Doosan Mill 5700 (2 units): 8,000 RPM, 41.400 x 22.00 x 23.750 in, 2,205 lbs."],
  ["N", "Okuma MILLAC 761V vertical machining center."],
  ["N", ""],
  ["B", "LARGE-CAPACITY 2-AXIS CNC TURNING"],
  ["N", "Doosan Puma 480 XL: 22 in max turning dia., 120 in max turn length, 6.500 in thru-bore."],
  ["N", "Doosan Puma 400 L: 21.7 in max dia., 81.7 in max turn length, 7.12 in thru-bore."],
  ["N", "Pass-through steady rests on long-bed turning operations."],
  ["N", ""],
  ["B", "MULTI-AXIS LATHE / MILL-TURN"],
  ["N", "DNX 2100SB: main 4,000 RPM, sub 5,000 RPM, milling 12,000 RPM; X 29.9 / Y 9.1 / Z 11.50 / A 45.7 / B +/-120."],
  ["N", "Doosan Puma 3100 LSY dual spindle: 16 in dia., 30 in length, 4.0 in bore, Y +/-2.5 in."],
  ["N", "Doosan Puma 3100 LY: 16.5 in dia., 50.4 in length, 4.0 in bore, Y +/-2.5 in."],
  ["N", "Doosan Puma GT3100M: 14.8 in dia., 29 in length, 4.5 in bore, C-axis."],
  ["N", ""],
  ["B", "ADDITIONAL IN-HOUSE SERVICES"],
  ["N", "ONA Wire EDM  |  Raycus 50W fiber laser engraving (100x100 mm and 300x300 mm)."],
  ["N", "CAD/CAM programming  |  In-house certified PE  |  Mechanical assembly."],
  ["N", "Aerospace packaging, marking & delivery  |  ERP barcoding & real-time tracking."],
  ["N", ""],
  ["B", "INSPECTION & METROLOGY"],
  ["N", "Hexagon CMM  |  IMX Keyence  |  Gagemaker MIC trac MT-3000  |  Mitutoyo PH35C"],
  ["N", "Tesa Microhite Plus M900 36 in height gage  |  12 in optical comparator with DRO"],
  ["N", "Hardness tester  |  TQM quality management system"],
  ["N", ""],
  ["B", "MATERIALS MACHINED"],
  ["N", "Inconel 625/718/925  |  Monel K-500  |  Hastelloy  |  Waspaloy  |  MP35N  |  Titanium"],
  ["N", "Stainless 13-8, 17-4 PH, 300 series, 410, 420 mod  |  13%, 22%, Super 13%, 9% chrome, S410 duplex"],
  ["N", "4130, 4140-4145, 4340, 1018-1026, 8620  |  Castings, forgings, casing, cast iron"],
  ["N", "Aluminum 2011, 2024, 6061, 7075  |  Brass, bronze, copper alloys  |  PEEK, Delrin, Acetal, HDPE"],
  ["N", ""],
  ["B", "PROGRAM EXPERIENCE"],
  ["N", "NASA Orion Project (secondary structure brackets & assembly parts), Boeing, Lockheed Martin,"],
  ["N", "Honeywell, Oceaneering and Fortune 500 OEM programs."],
  ["N", ""],
  ["B", "PROCUREMENT DATA"],
  ["N", "[Client to Provide: Standard & Tightest Tolerances]"],
  ["N", "[Client to Provide: Quote Turnaround Time & Standard/Expedite Lead Times]"],
  ["N", "[Client to Provide: Production Volume Sweet Spot / MOQ]"],
  ["N", "[Client to Provide: Accepted CAD Formats & ITAR Secure Upload Details]"],
  ["N", "[Client to Provide: Quality Documentation - AS9102 FAIR, MTRs, C of C, PPAP]"],
  ["N", "[Client to Provide: Approved Outside Processing / Nadcap Partners]"],
  ["N", "[Client to Provide: OTD %, Quality Rate % & Current Machine Count]"],
  ["N", ""],
  ["N", "Contact: Alex Barreneche, Director of Sales & Marketing  |  alex.barreneche@gretnamachine.com"],
  ["N", "RFQs: quotes@gretnamachine.com  |  Phone 713-690-7328  |  Fax 713-690-7350  |  Mon-Fri 7:00-16:30 CST"],
];

const esc = (s) => s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
const content =
  "BT\n/F1 9 Tf\n1 0 0 1 44 756 Tm\n13 TL\n" +
  lines
    .map(([style, text]) => {
      const font = style === "B" ? "/F2 10 Tf" : "/F1 8.4 Tf";
      return `${font}\n(${esc(text)}) Tj\nT*\n`;
    })
    .join("") +
  "ET\n";

const objects = [
  "<< /Type /Catalog /Pages 2 0 R >>",
  "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
  "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>",
  `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}endstream`,
  "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
  "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>",
  "<< /Title (Gretna Machine Shop - Capabilities Statement) /Author (Gretna Machine Shop, Inc.) /Subject (AS9100 Rev D CNC machining capabilities, Houston TX) >>",
];

let pdf = "%PDF-1.4\n";
const offsets = [];
objects.forEach((obj, i) => {
  offsets.push(Buffer.byteLength(pdf));
  pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
});
const xrefStart = Buffer.byteLength(pdf);
pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
offsets.forEach((o) => {
  pdf += `${String(o).padStart(10, "0")} 00000 n \n`;
});
pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info 7 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`;

mkdirSync("public", { recursive: true });
writeFileSync("public/gretna-capabilities-statement.pdf", pdf, "latin1");
console.log("Wrote public/gretna-capabilities-statement.pdf", Buffer.byteLength(pdf), "bytes");
