import { img } from "./images";

export const mainNav = [
  {
    label: "Services",
    href: "/services/cnc-machining-houston-tx",
    groups: [
      {
        heading: "CNC Machining",
        links: [
          { label: "Precision CNC Machining", href: "/services/cnc-machining-houston-tx" },
          { label: "5-Axis CNC Machining", href: "/services/5-axis-cnc-machining" },
          { label: "CNC Milling", href: "/services/cnc-milling" },
          { label: "CNC Turning", href: "/services/cnc-turning" },
        ],
      },
      {
        heading: "Specialty Processes",
        links: [
          { label: "Multi-Axis Mill-Turn", href: "/services/multi-axis-mill-turn" },
          { label: "Wire EDM Machining", href: "/services/wire-edm-machining" },
          { label: "Laser Marking & UID", href: "/services/laser-engraving-part-marking" },
          { label: "Engineering & Assembly", href: "/services/engineering-cad-cam-assembly" },
        ],
      },
    ],
  },
  {
    label: "Industries",
    href: "/industries/aerospace-cnc-machining",
    groups: [
      {
        heading: "Markets Served",
        links: [
          { label: "Aerospace", href: "/industries/aerospace-cnc-machining" },
          { label: "Defense & ITAR", href: "/industries/defense-itar-machining" },
          { label: "Oil & Gas", href: "/industries/oil-and-gas-machining-houston" },
          { label: "Geothermal Energy", href: "/industries/geothermal-energy-machining" },
        ],
      },
      {
        heading: "Proof & Coverage",
        links: [
          { label: "Case Studies", href: "/case-studies" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
          { label: "Certifications", href: "/certifications" },
        ],
      },
    ],
  },
  {
    label: "Materials",
    href: "/materials",
    groups: [
      {
        heading: "Material Families",
        links: [
          { label: "Inconel & Superalloys", href: "/materials/inconel-superalloy-machining" },
          { label: "Titanium & Stainless", href: "/materials/titanium-stainless-steel-machining" },
          { label: "Aluminum & Alloy Steel", href: "/materials/aluminum-alloy-steel-machining" },
          { label: "Engineering Plastics", href: "/materials/engineering-plastics-machining" },
        ],
      },
    ],
  },
  {
    label: "Equipment & Quality",
    href: "/equipment-list",
    groups: [
      {
        heading: "Shop Capability",
        links: [
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Certifications", href: "/certifications" },
        ],
      },
      {
        heading: "Procurement",
        links: [
          { label: "Case Studies", href: "/case-studies" },
          { label: "Resources & DFM", href: "/resources" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ],
      },
    ],
  },
  {
    label: "About",
    href: "/about",
    groups: [
      {
        heading: "Gretna Machine Shop",
        links: [
          { label: "About Gretna", href: "/about" },
          { label: "Texas & Regional Reach", href: "/texas-cnc-machining" },
          { label: "Careers", href: "/careers" },
          { label: "Contact", href: "/contact" },
        ],
      },
    ],
  },
];

export const caseStudies = [
  {
    slug: "nasa-orion-secondary-structure-brackets",
    title: "NASA Orion Project — Secondary Structure Brackets",
    industry: "Aerospace",
    image: img.aerospaceEngine,
    summary:
      "Secondary structure brackets and assembly parts produced for the Orion program under AS9100 Rev D controls, from 5-axis machining through CMM layout and aerospace packaging.",
    specs: [
      { label: "Program", value: "NASA Orion Project" },
      { label: "Part type", value: "Secondary structure brackets & assembly parts" },
      { label: "Quality system", value: "AS9100 Rev. D" },
      { label: "Location", value: "Houston HUBZone facility" },
    ],
  },
  {
    slug: "subsea-superalloy-components",
    title: "Subsea Superalloy Valve & Flow Components",
    industry: "Oil & Gas",
    image: img.oilGas,
    summary:
      "Inconel and 17-4 PH subsea flow components turned and milled in-house, with Gagemaker thread verification and material traceability retained against the heat number.",
    specs: [
      { label: "Material", value: "Inconel 625 / 17-4 PH" },
      { label: "Process", value: "Large-bore turning + mill-turn" },
      { label: "Inspection", value: "Gagemaker MIC trac MT-3000" },
      { label: "Documentation", value: "[Client to Provide: MTRs & C of C]" },
    ],
  },
  {
    slug: "defense-instrumentation-housings",
    title: "ITAR-Controlled Instrumentation Housings",
    industry: "Defense",
    image: img.defenseJet,
    summary:
      "Multi-face housings machined on true 5-axis equipment with UID laser marking and ITAR-aware handling from quote through packing.",
    specs: [
      { label: "Compliance", value: "ITAR registered / CAGE 0AXC7" },
      { label: "Process", value: "5-axis milling + wire EDM" },
      { label: "Marking", value: "Raycus 50W fiber laser UID" },
      { label: "Dimensional data", value: "Hexagon CMM report" },
    ],
  },
];

export const resources = [
  {
    slug: "dfm-tolerance-guide",
    category: "DFM Guide",
    title: "How to Call Out Tolerances Without Overpaying",
    excerpt:
      "A practical guide to functional tolerancing for procurement engineers: where tight tolerances belong, and where a blanket callout adds cost without adding value.",
    readTime: "6 min read",
  },
  {
    slug: "inconel-machining-guide",
    category: "Material Guide",
    title: "Machining Inconel 718 and 625: What Buyers Should Specify",
    excerpt:
      "Work hardening, tooling strategy, heat treat sequencing and what to include in an RFQ so superalloy parts hit tolerance the first time.",
    readTime: "8 min read",
  },
  {
    slug: "long-bed-turning-guide",
    category: "Capability Guide",
    title: "Long-Bed Turning up to 120 Inches: Design Rules",
    excerpt:
      "Steady-rest bearing surfaces, runout control and practical limits when you need a shaft longer than 80 inches in Houston.",
    readTime: "5 min read",
  },
  {
    slug: "aerospace-rfq-checklist",
    category: "Procurement Checklist",
    title: "The Aerospace RFQ Checklist: 12 Items to Include",
    excerpt:
      "From revision control to first article requirements, the information that lets a machine shop quote accurately instead of guessing.",
    readTime: "7 min read",
  },
  {
    slug: "hubzone-wosb-procurement",
    category: "Federal Procurement",
    title: "Using HUBZone and WOSB Status in Subcontracting Plans",
    excerpt:
      "How prime contractors can apply HUBZone, WOSB and minority-owned credit toward small business subcontracting goals.",
    readTime: "6 min read",
  },
  {
    slug: "cad-upload-itar-guide",
    category: "Process Guide",
    title: "Sending Controlled CAD Files: Formats, Markings and Handling",
    excerpt:
      "Which formats to send, what to label controlled data, and how to plan an RFQ when drawings cannot move over open email.",
    readTime: "4 min read",
  },
];

export const procurementGaps = [
  { label: "Achievable Tolerances", spec: "[Client to Provide: Standard & Tightest Tolerances, e.g., ±0.0005\"]" },
  { label: "RFQ Turnaround & Lead Times", spec: "[Client to Provide: Quote Turnaround Time & Standard/Expedite Lead Times]" },
  { label: "Production Volume / MOQ", spec: "[Client to Provide: Production Volume Sweet Spot / MOQ]" },
  { label: "Accepted CAD Formats & ITAR Portal", spec: "[Client to Provide: Accepted CAD Formats & ITAR Secure Upload Details]" },
  { label: "Quality Documentation Package", spec: "[Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C, PPAP]" },
  { label: "Secondary / Outside Processing", spec: "[Client to Provide: Approved Outside Processing / Nadcap Partners]" },
  { label: "Quantified Part Case Studies", spec: "[Client to Provide: 3-6 Real Part Case Studies with Dimensions & Photos]" },
  { label: "Verified Shop KPIs", spec: "[Client to Provide: OTD %, Quality Rate %, & Current Machine Count]" },
];

export const homeFaqs = [
  {
    q: "What tolerances can Gretna Machine Shop hold?",
    a: "We hold precision tolerances daily on 5-axis, long-bed turning and wire EDM work. [Client to Provide: Standard & Tightest Tolerances, e.g., ±0.0005\"]. Every critical feature is verified on the Hexagon CMM.",
  },
  {
    q: "Are you AS9100 and ITAR registered?",
    a: "Yes. Gretna is AS9100 Rev. D and ISO 9001:2015 registered (Platinum Registration, Inc.), ITAR registered, SAM registered, with CAGE code 0AXC7 and DUNS 054633755.",
  },
  {
    q: "What makes HUBZone and WOSB status valuable to my procurement team?",
    a: "Gretna is an SBA HUBZone-certified, Woman-Owned Small Business (WOSB), WBENC certified and minority-owned business located in Houston, TX — supporting set-aside eligibility and subcontracting plan credit.",
  },
  {
    q: "What is your maximum part envelope?",
    a: 'Milling reaches 80.7" X travel on the Okuma Millac 1052V II and 41.400" X on the Okuma MU5000V-L 5-axis. Turning reaches 22" diameter and 120" length with a 7.12" thru-bore.',
  },
  {
    q: "Can you machine Inconel, titanium and other exotic alloys?",
    a: "Yes. Inconel 625/718/925, Monel K-500, Hastelloy, Waspaloy, MP35N, titanium, 13%/22% chrome, duplex stainless and 17-4 PH are all routine materials.",
  },
  {
    q: "How do I submit an RFQ, and how fast is a quote?",
    a: "Upload CAD or prints through our RFQ page, email quotes@gretnamachine.com, or call 713-690-7328. [Client to Provide: Quote Turnaround Time & Standard/Expedite Lead Times].",
  },
];
