export const company = {
  name: "Gretna Machine Shop, Inc.",
  shortName: "Gretna",
  tagline: "The Pinnacle of Precision",
  taglineAlt: "Manufacturing Precision Components from Subsea to Mars",
  founded: 1980,
  address: {
    street: "3450 Lang Rd.",
    city: "Houston",
    state: "TX",
    zip: "77092",
    country: "USA",
    full: "3450 Lang Rd., Houston, TX 77092",
  },
  phone: "713-690-7328",
  phoneHref: "+17136907328",
  fax: "713-690-7350",
  hours: "Mon–Fri, 7:00 AM – 4:30 PM CST",
  emails: {
    quotes: "quotes@gretnamachine.com",
    info: "info@gretnamachine.com",
    sales: "alex.barreneche@gretnamachine.com",
    hr: "Hr@gretnamachine.com",
  },
  salesContact: {
    name: "Alex Barreneche",
    title: "Director of Sales & Marketing",
    email: "alex.barreneche@gretnamachine.com",
  },
  identifiers: {
    duns: "054633755",
    cage: "0AXC7",
  },
  facility: "50,000 sq. ft. air-conditioned lean manufacturing facility",
  employees: "50+",
  ownership: "100% Women-Owned & Minority-Owned",
  naics: [
    { code: "332510", label: "Hardware Manufacturing" },
    { code: "332710", label: "Machine Shops" },
    { code: "332721", label: "Precision Turned Product Manufacturing" },
    { code: "332912", label: "Metal Valve & Pipe Fitting Manufacturing" },
    { code: "336411", label: "Aircraft Manufacturing" },
    { code: "336413", label: "Aircraft Parts & Auxiliary Equipment" },
    { code: "336419", label: "Guided Missile & Space Vehicle Parts" },
  ],
  certifications: [
    { name: "AS9100 Rev. D", detail: "Aerospace quality management system" },
    { name: "ISO 9001:2015", detail: "Platinum Registration, Inc." },
    { name: "ITAR Registered", detail: "Defense & export-controlled work" },
    { name: "SBA HUBZone", detail: "Houston HUBZone certified" },
    { name: "SBA WOSB", detail: "Woman-Owned Small Business" },
    { name: "WBENC Certified", detail: "Women's Business Enterprise" },
    { name: "Minority-Owned (MOB)", detail: "Minority-owned business" },
    { name: "SAM Registered", detail: "System for Award Management" },
    { name: "BBB A+ Accredited", detail: "Accredited business" },
    { name: "UL-Certified Machines", detail: "UL-certified CNC equipment" },
  ],
  memberships: [
    "Greater Houston Manufacturing Association (GHMA)",
    "Women In Manufacturing (WIM)",
    "National Tooling & Machining Association (NTMA)",
  ],
  clients: [
    "NASA — Orion Project",
    "Boeing",
    "Lockheed Martin",
    "Honeywell",
    "Oceaneering",
    "Fortune 500 OEMs",
  ],
  values: [
    { name: "Love It", body: "Care about the work, the team, and the parts that leave the dock." },
    { name: "Be Helpful", body: "Solve the customer's problem first — internally and externally." },
    { name: "Be Lean", body: "Remove waste from every process, from quote to packing." },
    { name: "Grow Gray Matter", body: "Train machinists and engineers continuously." },
    { name: "Raise The Bar", body: "Measure, audit, and improve every quarter." },
  ],
  leadership: [
    { name: "Ninfa G. Pérez", title: "Co-Founder & Majority Owner", tenure: "40+ years" },
    { name: "Nubia A. Pérez", title: "CEO & Part-Owner", tenure: "15+ years" },
    { name: "Nancy Pérez", title: "Head of Strategic Partnerships & Part-Owner", tenure: "20+ years" },
  ],
  founder: "Jose Benjamin \u201cBenny\u201d Pérez & Ninfa G. Pérez",
  social: {
    linkedin: "https://www.linkedin.com/",
    facebook: "https://www.facebook.com/",
  },
} as const;

export type Machine = {
  model: string;
  machines?: string;
  spindle: string;
  travels: string;
  capacity?: string;
  note?: string;
};

export const machineGroups: {
  id: string;
  label: string;
  short: string;
  summary: string;
  image: string;
  rows: Machine[];
}[] = [
  {
    id: "5-axis",
    label: "True 5-Axis CNC Mills",
    short: "5-Axis Mills",
    summary:
      "Simultaneous 5-axis contouring with dynamic work coordinate system (TCPC) for complex aerospace and energy geometry in a single set-up.",
    image: "fiveAxis",
    rows: [
      {
        model: "Okuma MU5000V-L",
        spindle: "12,000 RPM spindle / 1,000 RPM platter",
        travels: '31.5" X × 41.400" Y × 23.700" Z',
        capacity: 'Max platter swing 27.5" / max load 1,100 lbs',
        note: "True 5-axis with integral vertical lathe capability",
      },
      {
        model: "Okuma M460V-5AX",
        spindle: "12,000 RPM spindle",
        travels: '30.0" X × 18.0" Y × 18.0" Z',
        capacity: 'Max platter swing 23.5" / max load 600 lbs',
        note: "True 5-axis, high-accuracy trunnion",
      },
      {
        model: "HAAS UMC-1000",
        spindle: "8,100 RPM spindle",
        travels: '40.0" X × 25.0" Y × 29.0" Z',
        capacity: 'Max platter swing 34.0" / max load 1,000 lbs',
        note: "True 5-axis, large envelope",
      },
    ],
  },
  {
    id: "4-axis",
    label: "4-Axis Vertical & Horizontal CNC Mills",
    short: "4-Axis Mills",
    summary:
      "Vertical and horizontal machining centers for production milling, tombstone workholding, and multi-face parts with repeatable fixtures.",
    image: "milling",
    rows: [
      {
        model: "Okuma Millac 1052V II",
        spindle: "6,000 RPM",
        travels: '80.7" X × 41.7" Y × 31.5" Z',
        capacity: "Max table load 5,551 lbs",
      },
      {
        model: "Okuma MB-5000H (Horizontal)",
        spindle: "12,000 RPM with TCPC",
        travels: '29.9" X × 29.9" Y × 31.89" Z',
        capacity: '19.69" × 19.69" rotary pallet / 1,100 lbs',
      },
      {
        model: "Doosan DNM 6700",
        spindle: "8,000 RPM",
        travels: '51.1" X × 26.37" Y × 24.6" Z',
        capacity: "Max table load 2,866 lbs",
      },
      {
        model: "Doosan Mill 5700 (2 units)",
        spindle: "8,000 RPM",
        travels: '41.400" X × 22.00" Y × 23.750" Z',
        capacity: "Max table load 2,205 lbs",
      },
      {
        model: "Okuma Millac 761V",
        spindle: "Vertical machining center",
        travels: "Production VMC envelope",
      },
    ],
  },
  {
    id: "lathes",
    label: "Large-Capacity 2-Axis CNC Lathes",
    short: "CNC Lathes",
    summary:
      "Long-bed, large-bore turning with pass-through steady rests — up to 120 inches of turn length and a 7.12 inch hollow spindle.",
    image: "lathe",
    rows: [
      {
        model: "Doosan Puma 480 XL",
        spindle: 'Max turning dia. 22"',
        travels: 'Max turn length 120"',
        capacity: 'Thru-bore 6.500"',
        note: "Long-bed energy shaft and sleeve work",
      },
      {
        model: "Doosan Puma 400 L",
        spindle: 'Max turning dia. 21.7"',
        travels: 'Max turn length 81.7"',
        capacity: 'Thru-bore 7.12"',
        note: "Bar-fed large-bore production",
      },
    ],
  },
  {
    id: "mill-turn",
    label: "Multi-Axis CNC Lathes / Mill-Turn",
    short: "Mill-Turn",
    summary:
      "Dual-spindle, Y-axis and live-tooling turning centers that finish milled features, cross holes, and second ops without re-fixturing.",
    image: "cncCloseup",
    rows: [
      {
        model: "DNX 2100SB",
        spindle: "Main 4,000 RPM / Sub 5,000 RPM / Milling 12,000 RPM",
        travels: 'X 29.9" / Y 9.1" / Z 11.50" / A 45.7" / B ±120°',
        capacity: "Multi-axis mill-turn with sub-spindle",
      },
      {
        model: "Doosan Puma 3100 LSY",
        spindle: "Dual spindle with live tooling",
        travels: 'Max dia. 16" / max length 30"',
        capacity: 'Thru-bore 4.0" / Y-axis ±2.5"',
      },
      {
        model: "Doosan Puma 3100 LY",
        spindle: "Y-axis live tooling",
        travels: 'Max dia. 16.5" / max length 50.4"',
        capacity: 'Thru-bore 4.0" / Y-axis ±2.5"',
      },
      {
        model: "Doosan Puma GT3100M",
        spindle: "C-axis live tooling",
        travels: 'Max dia. 14.8" / max length 29"',
        capacity: 'Thru-bore 4.5"',
      },
    ],
  },
  {
    id: "edm",
    label: "ONA Wire EDM",
    short: "Wire EDM",
    summary:
      "Wire EDM for hardened alloys, sharp internal corners, thin walls, and burr-free finishes that milling cutters cannot reach.",
    image: "edm",
    rows: [
      {
        model: "ONA Wire EDM",
        spindle: "CNC submerged wire EDM",
        travels: "Dependent on part envelope — confirm at RFQ",
        capacity: "Hardened tool steel, Inconel, titanium, thin-wall features",
      },
    ],
  },
  {
    id: "laser",
    label: "Raycus 50W Fiber Laser Engraving",
    short: "Laser Marking",
    summary:
      "In-house UID, serial, and part-number marking with two work zones — no outside vendor, no shipping delay.",
    image: "laser",
    rows: [
      {
        model: "Raycus 50W Fiber Laser Marking System",
        spindle: "50W fiber laser",
        travels: '100 × 100 mm and 300 × 300 mm work areas',
        capacity: "UID / Data Matrix / serial / lot / part marking on metals",
      },
    ],
  },
];

export const metrology = [
  {
    name: "Hexagon CMM Machine",
    purpose: "Programmed dimensional layout, GD&T verification, first article data",
  },
  {
    name: "IMX Keyence Machine",
    purpose: "Optical / vision measurement and surface documentation",
  },
  {
    name: "Gagemaker MIC trac MT-3000",
    purpose: "Thread and API connection measurement for oilfield work",
  },
  {
    name: "Mitutoyo Profile Projector PH35C",
    purpose: "Profile and edge geometry verification",
  },
  {
    name: "Tesa Microhite Plus M900",
    purpose: '36" digital height gage for large-part layout',
  },
  {
    name: "12\" Optical Comparator with DRO",
    purpose: "Thread form, radius, and small-feature inspection",
  },
  {
    name: "Hardness Tester",
    purpose: "Incoming and final material hardness verification",
  },
  {
    name: "TQM Quality Management System",
    purpose: "Calibration control, nonconformance, and corrective action records",
  },
];

export const processSteps = [
  {
    step: "01",
    title: "Submit CAD & Prints",
    body: "Send STEP, IGES, SolidWorks, DXF or a PDF print through our ITAR-aware RFQ workflow. Include material, quantity, and any quality clauses.",
  },
  {
    step: "02",
    title: "Engineering DFM & Quote",
    body: "Our machinist-programmers and in-house PE review fixturing, tolerance stack-up, and outside processes before pricing the job.",
  },
  {
    step: "03",
    title: "Precision Machining & Tracking",
    body: "Work is machined on Okuma, Doosan, HAAS and ONA equipment with ERP barcode tracking at every operation.",
  },
  {
    step: "04",
    title: "CMM Inspection & Aerospace Packing",
    body: "Hexagon CMM verification, documentation package, laser marking, and protected export-ready packaging.",
  },
];
