import type { Metadata } from "next";
import { company } from "./company";
import { img } from "./images";

export const siteUrl = "https://www.gretnamachine.com";

export function buildMetadata(opts: {
  title: string;
  description: string;
  path: string;
  image?: string;
  keywords?: string[];
}): Metadata {
  const url = `${siteUrl}${opts.path}`;
  return {
    title: opts.title,
    description: opts.description,
    keywords: opts.keywords,
    alternates: { canonical: url },
    openGraph: {
      title: opts.title,
      description: opts.description,
      url,
      siteName: company.name,
      locale: "en_US",
      type: "website",
      images: [{ url: opts.image ?? img.facility, width: 1200, height: 630, alt: opts.title }],
    },
    twitter: {
      card: "summary_large_image",
      title: opts.title,
      description: opts.description,
      images: [opts.image ?? img.facility],
    },
  };
}

export const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "Manufacturer"],
  "@id": `${siteUrl}/#organization`,
  name: company.name,
  url: siteUrl,
  slogan: company.tagline,
  description:
    "AS9100 Rev D and ITAR registered precision CNC machine shop in Houston, TX. True 5-axis machining, large-capacity turning, mill-turn, wire EDM, laser marking and turnkey assembly for aerospace, defense, oil and gas.",
  foundingDate: "1980",
  telephone: company.phone,
  faxNumber: company.fax,
  email: company.emails.info,
  address: {
    "@type": "PostalAddress",
    streetAddress: company.address.street,
    addressLocality: company.address.city,
    addressRegion: company.address.state,
    postalCode: company.address.zip,
    addressCountry: "US",
  },
  geo: { "@type": "GeoCoordinates", latitude: 29.8065, longitude: -95.4626 },
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      opens: "07:00",
      closes: "16:30",
    },
  ],
  areaServed: [
    { "@type": "State", name: "Texas" },
    { "@type": "City", name: "Houston" },
    { "@type": "City", name: "Dallas" },
    { "@type": "City", name: "Fort Worth" },
    { "@type": "City", name: "Austin" },
    { "@type": "City", name: "San Antonio" },
  ],
  identifier: [
    { "@type": "PropertyValue", name: "DUNS", value: company.identifiers.duns },
    { "@type": "PropertyValue", name: "CAGE Code", value: company.identifiers.cage },
  ],
  naics: company.naics.map((n) => n.code),
  hasCredential: company.certifications.map((c) => c.name),
  knowsAbout: [
    "5-axis CNC machining",
    "Inconel machining",
    "Titanium machining",
    "Oil and gas machining",
    "Aerospace manufacturing",
    "ITAR machining",
    "HUBZone manufacturing",
  ],
  makesOffer: {
    "@type": "Offer",
    itemOffered: {
      "@type": "Service",
      name: "Precision CNC machining",
      areaServed: "Texas",
    },
  },
  sameAs: [company.social.linkedin, company.social.facebook],
};

export const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: company.name,
  url: siteUrl,
  potentialAction: {
    "@type": "SearchAction",
    target: `${siteUrl}/resources?q={search_term_string}`,
    "query-input": "required name=search_term_string",
  },
};

export const faqJsonLd = (faqs: { q: string; a: string }[]) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a.replace(/\[Client to Provide:[^\]]*\]/g, "").trim() },
  })),
});

export const serviceJsonLd = (opts: {
  name: string;
  description: string;
  path: string;
}) => ({
  "@context": "https://schema.org",
  "@type": "Service",
  name: opts.name,
  description: opts.description,
  url: `${siteUrl}${opts.path}`,
  serviceType: opts.name,
  provider: { "@id": `${siteUrl}/#organization` },
  areaServed: [
    { "@type": "State", name: "Texas" },
    { "@type": "City", name: "Houston" },
    { "@type": "Country", name: "United States" },
  ],
  audience: { "@type": "BusinessAudience", audienceType: "Procurement engineers and OEM buyers" },
});

export const breadcrumbJsonLd = (items: { name: string; path: string }[]) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: items.map((item, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: item.name,
    item: `${siteUrl}${item.path}`,
  })),
});
