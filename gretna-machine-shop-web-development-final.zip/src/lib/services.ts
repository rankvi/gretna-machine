import { img } from "./images";

export type Card = { title: string; body: string; image?: string; points?: string[] };

export type ServiceContent = {
  slug: string;
  name: string;
  navLabel: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  heroIntro: string;
  heroImage: string;
  heroUsps: string[];
  badges: string[];
  capabilities: Card[];
  callout: string;
  machineGroups: string[];
  applications: Card[];
  dfmTitle: string;
  dfmTips: Card[];
  valueProps: Card[];
  faqs: { q: string; a: string }[];
  relatedIndustries: string[];
  relatedMaterials: string[];
  pillar?: boolean;
};

export const services: ServiceContent[] = [
  {
    slug: "cnc-machining-houston-tx",
    name: "Precision CNC Machining",
    navLabel: "Precision CNC Machining",
    h1: "Precision CNC Machining Services in Houston, TX",
    metaTitle: "Precision CNC Machining Services Houston TX | Gretna",
    metaDescription:
      "AS9100 Rev D and ITAR precision CNC machining in Houston, TX. True 5-axis milling, 120\" turning, Inconel and titanium, in-house PE and CMM inspection.",
    heroIntro:
      "One Houston shop for 5-axis milling, large-bore turning, mill-turn, wire EDM and turnkey assembly — with AS9100 Rev D documentation and a certified Professional Engineer on staff.",
    heroImage: img.fiveAxis,
    heroUsps: [
      'True 5-axis milling plus 120" long-bed CNC turning under one roof',
      "Inconel, titanium, MP35N, Hastelloy and 13% chrome machining",
      "50,000 sq. ft. air-conditioned Houston shop with Hexagon CMM",
    ],
    badges: ["AS9100 Rev D", "ITAR Registered", "HUBZone", "WOSB"],
    capabilities: [
      {
        title: "5-Axis & 4-Axis CNC Milling",
        body: "Simultaneous 5-axis contouring on Okuma MU5000V-L and M460V-5AX plus large-envelope vertical and horizontal mills for production parts.",
        image: img.fiveAxis,
        points: ['Up to 80.7" X travel', 'Platter loads to 1,100 lbs', "TCPC / dynamic work offset"],
      },
      {
        title: "Large-Capacity CNC Turning",
        body: "Long-bed turning up to 120 inches with pass-through steady rests and a 7.12 inch hollow spindle for energy and pump components.",
        image: img.lathe,
        points: ['22" max turning diameter', '7.12" thru-bore', "Gagemaker thread verification"],
      },
      {
        title: "Mill-Turn & Multi-Axis Lathes",
        body: "Dual-spindle, Y-axis and live-tooling centers finish milled flats, cross holes and second operations in one cycle.",
        image: img.cncCloseup,
        points: ['Sub-spindle part-off', "Y-axis ±2.5", "12,000 RPM milling spindle"],
      },
      {
        title: "ONA Wire EDM",
        body: "Hardened alloys, sharp internal corners, thin walls and burr-free edges that cannot be milled conventionally.",
        image: img.edm,
        points: ["Submerged machining", "Hardened materials", "Fine surface finishes"],
      },
      {
        title: "Laser Part Marking",
        body: "Raycus 50W fiber laser marks UID, serial, lot and part numbers in-house, in two work zones, before shipment.",
        image: img.laser,
        points: ["100 × 100 mm zone", "300 × 300 mm zone", "UID / Data Matrix"],
      },
      {
        title: "Turnkey Assembly & Engineering",
        body: "Certified Professional Engineer, CAD/CAM programming by Class-A machinist supervisors, mechanical assembly and aerospace packing.",
        image: img.cad,
        points: ["In-house PE review", "Assembly & kitting", "ERP barcoded routing"],
      },
    ],
    callout:
      "Every job is routed in our ERP with real-time barcode tracking, reviewed by machinist-programmers, and inspected against the print — including first article inspection and documentation packages on request.",
    machineGroups: ["5-axis", "4-axis", "lathes", "mill-turn", "edm", "laser"],
    applications: [
      {
        title: "Aerospace Structures & Brackets",
        body: "AS9100D bracket families, secondary structure, housings and fittings for NASA, Boeing and Lockheed Martin supply chains.",
        image: img.aerospaceEngine,
      },
      {
        title: "Subsea & Downhole Components",
        body: "Inconel and 13% chrome bodies, sleeves, subs and valve components built for Gulf Coast pressure and corrosion requirements.",
        image: img.oilGas,
      },
      {
        title: "Defense & ITAR-Controlled Hardware",
        body: "CAGE 0AXC7, ITAR-registered machining for guided missile and space vehicle parts under NAICS 336419.",
        image: img.defenseJet,
      },
    ],
    dfmTitle: "DFM Guidance for Houston CNC Programs",
    dfmTips: [
      { title: "Call out datums deliberately", body: "Align GD&T datums with the set-up you expect. It reduces re-fixturing and inspection cost on multi-axis parts." },
      { title: "Respect the tool radius", body: "Inside corners need a radius at least equal to the cutter radius; deeper pockets need more clearance." },
      { title: "Specify tolerance by feature", body: "Blanket ±0.001\" callouts add cost. Hold tight tolerance only where the function requires it." },
      { title: "Plan for the material", body: "Inconel, titanium and MP35N work-harden — send enough stock for controlled heat and tool engagement." },
      { title: "Send 3D, not just 2D", body: "STEP or SolidWorks models let our programmers verify stock, fixtures and probe positions before quoting." },
      { title: "Flag outside processes early", body: "Heat treat, anodize, passivation, NDT and plating change time and tolerance, so include them in the RFQ." },
    ],
    valueProps: [
      { title: "AS9100D & ITAR Ready", body: "Registered quality system and export-control awareness for aerospace and defense purchase orders." },
      { title: "HUBZone & WOSB Advantage", body: "SBA HUBZone, WOSB and minority-owned designations support set-aside and subcontracting goals." },
      { title: "Exotic Alloy Mastery", body: "Inconel 718/625, Monel K-500, Hastelloy, Waspaloy, MP35N, titanium and 13% chrome are routine work." },
      { title: "Real-Time Order Tracking", body: "ERP barcode routing shows where every part is, from saw cut to final inspection and packing." },
    ],
    faqs: [
      {
        q: "Do you have a minimum order quantity?",
        a: "We quote prototype through production. Send your quantity and annual volume so engineering can price the right process — [Client to Provide: Production Volume Sweet Spot / MOQ].",
      },
      {
        q: "What tolerances can Gretna hold?",
        a: "We machine and inspect complex 5-axis and long-bed turning work daily. [Client to Provide: Standard & Tightest Tolerances, e.g., ±0.0005\"].",
      },
      {
        q: "Which files should I upload with my RFQ?",
        a: "STEP, IGES, SolidWorks, DXF and PDF prints are preferred. [Client to Provide: Accepted CAD Formats & ITAR Secure Upload Details].",
      },
      {
        q: "Can you support ITAR-controlled work?",
        a: "Yes. Gretna is ITAR registered, SAM registered, and holds CAGE code 0AXC7. Do not email uncontrolled technical data — our RFQ workflow captures controlled submissions.",
      },
      {
        q: "What documentation comes with the parts?",
        a: "Material certifications and inspection records are standard. [Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C, PPAP].",
      },
      {
        q: "Do you work with HUBZone and WOSB set-asides?",
        a: "Yes. Gretna is an SBA HUBZone certified, Woman-Owned Small Business and minority-owned business in Houston, TX.",
      },
      {
        q: "How fast are quotes and delivery?",
        a: "Quotes are reviewed by engineering, not an automated portal. [Client to Provide: Quote Turnaround Time & Standard/Expedite Lead Times].",
      },
      {
        q: "Can you handle assembly and outside processing?",
        a: "We do mechanical assembly, laser marking and aerospace packaging in-house. [Client to Provide: Approved Outside Processing / Nadcap Partners].",
      },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "defense-itar-machining", "oil-and-gas-machining-houston"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining", "aluminum-alloy-steel-machining"],
    pillar: true,
  },
  {
    slug: "5-axis-cnc-machining",
    name: "5-Axis CNC Machining",
    navLabel: "5-Axis CNC Machining",
    h1: "5-Axis CNC Machining Services in Houston, TX",
    metaTitle: "5 Axis CNC Machining Services Houston TX | Gretna Shop",
    metaDescription:
      "True 5-axis CNC machining in Houston, TX on Okuma MU5000V-L, M460V-5AX and HAAS UMC-1000. AS9100D, ITAR, complex aerospace and energy geometry.",
    heroIntro:
      "Simultaneous 5-axis machining with dynamic work coordinate systems (TCPC) for complex aerospace geometry, deep cavities and multi-face parts finished in a single set-up.",
    heroImage: img.fiveAxis,
    heroUsps: [
      "Okuma MU5000V-L, Okuma M460V-5AX and HAAS UMC-1000",
      "TCPC / dynamic work offset for reliable multi-face accuracy",
      "Platter swings to 34\" with loads up to 1,100 lbs",
    ],
    badges: ["True 5-Axis", "AS9100 Rev D", "ITAR", "In-House PE"],
    capabilities: [
      {
        title: "Simultaneous 5-Axis Contouring",
        body: "Full simultaneous motion on Okuma and HAAS trunnions produces organic aerospace surfaces without hand blending or secondary operations.",
        image: img.fiveAxis,
        points: ["TCPC control", "One set-up, five faces", "Complex aerospace contours"],
      },
      {
        title: "5-Axis with Vertical Lathe",
        body: "Our Okuma MU5000V-L adds turning capability to the same platform, ideal for round aerospace and energy parts with milled features.",
        image: img.cncCloseup,
        points: ["1,000 RPM platter", "12,000 RPM spindle", '27.5" max swing'],
      },
      {
        title: "Fixture & Tombstone Workholding",
        body: "Engineered fixtures and probing sequences keep repeat set-ups aligned on production families of parts.",
        image: img.millingWorker,
        points: ["Probe-based set-up", "Repeatable fixtures", "Production part families"],
      },
    ],
    callout:
      "5-axis work is programmed by Class-A machinist supervisors in CAD/CAM and verified against stock models before the first cut — reducing scrap on high-value Inconel and titanium parts.",
    machineGroups: ["5-axis"],
    applications: [
      { title: "Aerospace Brackets & Housings", body: "Secondary structure with compound angles, tight true position, and inspection on the Hexagon CMM.", image: img.aerospaceEngine },
      { title: "Energy Impellers & Manifolds", body: "Pump and compressor parts with flow-path geometry machined in a single 5-axis cycle.", image: img.oilGas },
      { title: "Defense Instrumentation Parts", body: "ITAR-controlled housings and mounts with complex mounting faces and controlled surfaces.", image: img.defenseJet },
    ],
    dfmTitle: "5-Axis DFM Checklist",
    dfmTips: [
      { title: "Give us the tool axis intent", body: "Share the surfaces that must be cut and the surfaces that are non-functional so we can choose the tool orientation." },
      { title: "Watch L:D ratios", body: "Deep pockets with long-reach cutters deflect. Shorter tools or 5-axis orientation solve it — flag it at quote." },
      { title: "Model the stock", body: "A stock model or forging definition prevents air cuts, collisions and unusable probe positions." },
      { title: "Define datum scheme", body: "A repeatable 3-2-1 datum scheme keeps the 5-axis set-up consistent from first article to production." },
      { title: "Avoid sharp internal corners", body: "Use radii matched to available tooling to eliminate unnecessary Wire EDM operations." },
      { title: "Consider 3+2 versus simultaneous", body: "Positional 3+2 is faster where full simultaneous motion is not functionally required." },
    ],
    valueProps: [
      { title: "Complex Geometry", body: "Compound angles, sculpted surfaces and five-sided features without multiple fixtures." },
      { title: "Scrap Reduction", body: "Simulation and probing before the cut protect expensive superalloy parts." },
      { title: "Fewer Set-Ups", body: "Less handling means tighter position tolerances and shorter lead time." },
      { title: "Documented Inspection", body: "CMM programs verify multi-face parts and generate first article data." },
    ],
    faqs: [
      { q: "What is the largest part you can 5-axis machine?", a: "Our HAAS UMC-1000 offers 40\" × 25\" × 29\" travels and a 34\" platter swing. Larger parts can often be handled on our 4-axis mills." },
      { q: "Can you machine Inconel on a 5-axis mill?", a: "Yes. Inconel 718/625, Waspaloy, MP35N and titanium are routine. We control heat and tooling to avoid work hardening." },
      { q: "Do you do 3+2 positional machining?", a: "Yes, and we recommend it where full simultaneous motion is not required — it is faster and equally accurate." },
      { q: "What files do you need to quote 5-axis work?", a: "A STEP or SolidWorks model plus a PDF print with datums and GD&T. [Client to Provide: Accepted CAD Formats & ITAR Secure Upload Details]." },
      { q: "How do you verify multi-face parts?", a: "Hexagon CMM programs written from the model, plus Keyence and Tesa height gage checks where appropriate." },
      { q: "Are prints covered by ITAR?", a: "ITAR-registered work is handled under our registered quality system. Mark the RFQ as ITAR controlled and we will route it securely." },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "defense-itar-machining"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining"],
  },
  {
    slug: "cnc-milling",
    name: "CNC Milling",
    navLabel: "CNC Milling",
    h1: "4-Axis Vertical & Horizontal CNC Milling in Texas",
    metaTitle: "CNC Milling Services Houston TX | 4-Axis Mills",
    metaDescription:
      "4-axis vertical and horizontal CNC milling in Houston, TX. Okuma Millac and MB-5000H, Doosan DNM 6700 with 51\" travel, AS9100D quality and fast RFQ review.",
    heroIntro:
      "Production milling on Okuma and Doosan vertical and horizontal machining centers — large envelopes, pallet-changing horizontals and repeatable fixtures for Texas OEM programs.",
    heroImage: img.milling,
    heroUsps: [
      'Large envelopes to 80.7" X travel with 5,551 lb table loads',
      "Horizontal pallet changing for repeat production parts",
      "Okuma, Doosan and HAAS platforms under AS9100D",
    ],
    badges: ["4-Axis Milling", "AS9100 Rev D", "Production Quantities"],
    capabilities: [
      {
        title: "Vertical Machining Centers",
        body: "Okuma Millac 1052V II and Doosan DNM 6700 handle large plates, housings and weldments with long X travel.",
        image: img.milling,
        points: ['80.7" X travel', "5,551 lb table capacity", "4th axis rotary"],
      },
      {
        title: "Horizontal Machining",
        body: "The Okuma MB-5000H with 12,000 RPM spindle and TCPC machines four faces and runs pallet-to-pallet for production.",
        image: img.millingDetail,
        points: ["Dual pallet 19.69\"", "4 faces per set-up", "Production repeatability"],
      },
      {
        title: "Fixtures & Production Cells",
        body: "Engineered tombstones and dedicated fixtures keep cycle times down and part-to-part variation tight.",
        image: img.millingWorker,
        points: ["Tombstone workholding", "In-process probing", "ERP-tracked routing"],
      },
    ],
    callout:
      "From one-off prototypes to Kanban production runs, milling jobs are programmed, fixtured and inspected in-house — no brokered work, no surprises on delivery.",
    machineGroups: ["4-axis"],
    applications: [
      { title: "Aerospace Plates & Housings", body: "Thin-wall aluminum and stainless housings with flatness and true-position requirements.", image: img.aerospaceEngine },
      { title: "Oilfield Manifolds & Blocks", body: "Large valve blocks, adapter plates and manifold bodies in 4130/4140 and 17-4 PH.", image: img.pipelines },
      { title: "Industrial Machine Components", body: "Frames, brackets, and replacement components for Gulf Coast manufacturers.", image: img.facility },
    ],
    dfmTitle: "Milling DFM Checklist",
    dfmTips: [
      { title: "Minimum wall thickness", body: "Keep walls at 0.060\" or thicker where possible to control chatter and distortion." },
      { title: "Standard hole sizes", body: "Specify standard drill and end-mill sizes to avoid extra tool changes and cycle time." },
      { title: "Depth-to-diameter", body: "Holes deeper than 4× diameter need peck cycles or gun drilling — tell us at RFQ." },
      { title: "Thread callouts", body: "Use standard thread classes and note whether threads are inspected with Go/No-Go gages." },
      { title: "Surface finish notes", body: "Specify Ra only where sealing or bearing function requires it." },
      { title: "Deburr expectations", body: "State whether edges are broken or fully radiused so we can plan hand finishing." },
    ],
    valueProps: [
      { title: "Large Envelope Capacity", body: "Oversized plates and weldments that smaller Texas shops cannot fixture." },
      { title: "Horizontal Productivity", body: "Pallet-changing HMC work reduces cost per part on repeat orders." },
      { title: "One Shop, One PO", body: "Mill, turn, EDM, mark and assemble under a single purchase order." },
      { title: "Documented Quality", body: "AS9100D inspection records and material traceability on every lot." },
    ],
    faqs: [
      { q: "What is your largest milling envelope?", a: "The Okuma Millac 1052V II provides 80.7\" × 41.7\" × 31.5\" travels with a 5,551 lb table capacity." },
      { q: "Can you mill Inconel and titanium?", a: "Yes — nickel superalloys and titanium are core materials for us, with the tooling and coolant strategy to match." },
      { q: "Do you offer production quantities?", a: "Yes. We quote prototypes through blanket orders. [Client to Provide: Production Volume Sweet Spot / MOQ]." },
      { q: "Can you machine castings and forgings?", a: "Yes. We handle castings and forgings, and can verify datum structure on the CMM before machining." },
      { q: "Is 4th-axis work included?", a: "Yes. Rotary 4th-axis work is standard on our vertical mills and horizontal pallets." },
      { q: "Can milling be combined with turning?", a: "Yes, on our mill-turn centers and via in-house routing so the part does not leave the building." },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "oil-and-gas-machining-houston"],
    relatedMaterials: ["aluminum-alloy-steel-machining", "titanium-stainless-steel-machining"],
  },
  {
    slug: "cnc-turning",
    name: "CNC Turning",
    navLabel: "CNC Turning",
    h1: "Large Diameter, Long Bed CNC Turning in Houston, TX",
    metaTitle: "CNC Turning Houston TX | 120\" Long Bed & 7.12\" Bore",
    metaDescription:
      'Large-capacity CNC turning in Houston, TX: up to 120" turn length, 22" diameter and 7.12" hollow spindle with pass-through steady rests and thread gaging.',
    heroIntro:
      'Long-bed, large-bore CNC turning with a 7.12" hollow spindle and up to 120" between centers — engineered for subsea, downhole and compression equipment in the Gulf Coast energy corridor.',
    heroImage: img.lathe,
    heroUsps: [
      'Up to 120" max turn length and 22" turning diameter',
      '7.12" thru-bore and pass-through steady rests',
      "Gagemaker MIC trac MT-3000 thread verification",
    ],
    badges: ["Large Capacity", "AS9100 Rev D", "Energy Ready"],
    capabilities: [
      {
        title: "Long-Bed Large-Diameter Turning",
        body: "Puma 480 XL handles shafts and sleeves up to 120 inches with steady-rest support for deflection control.",
        image: img.lathe,
        points: ['120" turn length', '22" turning diameter', "Steady rest support"],
      },
      {
        title: "Large-Bore Bar Work",
        body: "With a 7.12 inch thru-bore, the Puma 400 L accepts large bar stock for efficient, low-waste production.",
        image: img.cncCloseup,
        points: ['7.12" thru-bore', '81.7" turn length', "Bar-fed efficiency"],
      },
      {
        title: "Threaded Connections & Gaging",
        body: "API-style and special threads are cut and verified with Gagemaker thread measurement equipment.",
        image: img.measuringTools,
        points: ["Gagemaker MIC trac", "API thread forms", "Dimensional records"],
      },
    ],
    callout:
      "Long parts are the hard part of turning — our steady rests, live centers and documented straightness checks keep 100-inch-plus parts concentric from the first pass to final inspection.",
    machineGroups: ["lathes", "mill-turn"],
    applications: [
      { title: "Subsea & Downhole Tools", body: "Sleeves, subs, mandrels and housings in Inconel, 13% chrome and 17-4 PH.", image: img.oilGas },
      { title: "Pump & Compressor Shafts", body: "Long shafts requiring concentric bearing journals and true running surfaces.", image: img.pipelines },
      { title: "Hydraulic Cylinder Components", body: "Bores, rods and end caps machined with sealing-surface finish control.", image: img.lathe },
    ],
    dfmTitle: "Turning DFM Checklist",
    dfmTips: [
      { title: "Provide stock condition", body: "Tell us whether you are supplying bar, tube or a forging so we can plan the bore and chucking." },
      { title: "Design for steady rest", body: "Long slender parts need a bearing surface for the steady rest — note where it can run." },
      { title: "Note straightness and runout", body: "Call out concentricity and runout on the drawing; these drive set-up and inspection time." },
      { title: "Use standard thread forms", body: "Standard UN, NPT and API threads are faster to cut and verify than special forms." },
      { title: "Balance chamfers", body: "Both-end chamfers simplify handling and prevent thread damage in transit." },
      { title: "Specify finish where it matters", body: "Seal and bearing surfaces need controlled Ra; other diameters do not." },
    ],
    valueProps: [
      { title: 'True 120" Capability', body: "Long-bed machines that many regional shops simply do not have." },
      { title: "Large Bar Capacity", body: '7.12" thru-bore cuts material cost and cycle time on production parts.' },
      { title: "Thread Expertise", body: "Dedicated thread metrology for oilfield and pressure-containing connections." },
      { title: "In-House Finishing", body: "Mill-turn and laser marking finish the part without a second supplier." },
    ],
    faqs: [
      { q: "What is the maximum part length you can turn?", a: 'Up to 120" on the Puma 480 XL. Please include overall length and steady-rest bearing locations in the RFQ.' },
      { q: "What is the largest diameter?", a: '22" maximum turning diameter, with a 6.5" thru-bore on the 480 XL and 7.12" on the Puma 400 L.' },
      { q: "Do you turn Inconel and 13% chrome?", a: "Yes — Inconel 625/718, 13% chrome, 17-4 PH, 410 and duplex stainless are routine." },
      { q: "Can you supply material?", a: "Yes. We can source mill-certified material or machine customer-supplied stock. [Client to Provide: Material Sourcing Preferences]." },
      { q: "Do you verify threads?", a: "Yes, with Gagemaker MIC trac MT-3000 measurement and documented results." },
      { q: "Can parts be marked before shipping?", a: "Yes — in-house Raycus 50W fiber laser marking for UID, serial and lot numbers." },
    ],
    relatedIndustries: ["oil-and-gas-machining-houston", "geothermal-energy-machining"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining"],
  },
  {
    slug: "multi-axis-mill-turn",
    name: "Multi-Axis Mill-Turn",
    navLabel: "Multi-Axis Mill-Turn",
    h1: "Multi-Axis Dual Spindle Mill-Turn CNC Machining",
    metaTitle: "Multi-Axis Mill-Turn CNC Machining Texas | Gretna",
    metaDescription:
      "Dual-spindle mill-turn CNC machining in Houston, TX. DNX 2100SB and Doosan Puma 3100 LSY with Y-axis live tooling for done-in-one complex parts.",
    heroIntro:
      "Dual-spindle, Y-axis and live-tooling machines complete turned and milled features in one cycle — shorter lead times, fewer set-ups, and tighter feature-to-feature relationships.",
    heroImage: img.cncCloseup,
    heroUsps: [
      "DNX 2100SB with 12,000 RPM milling spindle and sub-spindle",
      "Doosan Puma 3100 LSY dual spindle with Y-axis ±2.5\"",
      "Done-in-one processing eliminates secondary operations",
    ],
    badges: ["Live Tooling", "Dual Spindle", "Y-Axis"],
    capabilities: [
      {
        title: "Dual Spindle Done-In-One",
        body: "Main and sub-spindle transfer machines both ends of the part without manual re-chucking.",
        image: img.cncCloseup,
        points: ["Sub-spindle 5,000 RPM", "Part-off and backwork", "One-cycle completion"],
      },
      {
        title: "Y-Axis & Cross Hole Work",
        body: "Y-axis live tooling drills and mills off-center features with true position held to the print.",
        image: img.fiveAxis,
        points: ["Y-axis ±2.5\"", "Cross drilled holes", "Milled flats and pockets"],
      },
      {
        title: "Bar-Fed Production",
        body: "Bar feeders and consistent cycle times make mill-turn ideal for repeat orders and blanket releases.",
        image: img.milling,
        points: ["Bar-fed efficiency", "Repeatable cycles", "Blanket order support"],
      },
    ],
    callout:
      "One mill-turn cycle replaces three or four separate operations — a meaningful cost and lead-time advantage on stainless, Inconel and chrome components.",
    machineGroups: ["mill-turn", "lathes"],
    applications: [
      { title: "Valve Bodies & Fittings", body: "Multi-port stainless and duplex bodies with cross holes and threaded ends.", image: img.pipelines },
      { title: "Aerospace Fluid Fittings", body: "AS9100D fittings and unions with concentric bores and controlled thread forms.", image: img.aerospaceEngine },
      { title: "Instrumentation Housings", body: "Small precision housings requiring turned diameters and milled features.", image: img.caliper },
    ],
    dfmTitle: "Mill-Turn DFM Checklist",
    dfmTips: [
      { title: "Design around the sub-spindle", body: "Leave a clean gripping diameter for the sub-spindle so backworking is accurate." },
      { title: "Consolidate features", body: "Put cross holes and flats at one Z location to cut cycle time and improve accuracy." },
      { title: "Plan bar size", body: "Sizing parts near standard bar diameters reduces material waste and cost." },
      { title: "Avoid long thin necks", body: "Slender sections deflect during backwork — consider support or a two-op plan." },
      { title: "Specify threads per end", body: "Tell us which end is threaded and whether threads must be gaged before or after finishing." },
      { title: "Keep tolerances functional", body: "Over-tolerancing common diameters adds inspection time without adding value." },
    ],
    valueProps: [
      { title: "Fewer Operations", body: "One cycle replaces multiple set-ups, reducing handling damage and lead time." },
      { title: "Better Feature Alignment", body: "Features machined without re-chucking hold tighter relationships." },
      { title: "Production Economics", body: "Bar-fed, dual-spindle cycles make 50–5,000 piece runs cost-effective." },
      { title: "Proven Platforms", body: "DNX and Doosan mill-turn centers maintained and programmed in-house." },
    ],
    faqs: [
      { q: "What is the maximum diameter on mill-turn?", a: 'Up to 16.5" depending on the machine, with 50.4" maximum length on the Puma 3100 LY.' },
      { q: "Can you hold true position on cross holes?", a: "Yes. Y-axis live tooling and probing allow position verification without a secondary operation." },
      { q: "Do you bar-feed?", a: "Yes, with 4.0\"–4.5\" thru-bore capability on our Puma 3100 series." },
      { q: "Which industries use your mill-turn capacity?", a: "Oil and gas valve and fitting work, aerospace fluid components, and industrial instrumentation." },
      { q: "Can you combine with laser marking?", a: "Yes — parts are marked in-house after final inspection." },
      { q: "How is pricing different from separate operations?", a: "Mill-turn usually reduces total cost on moderate volumes. Send quantities so we can compare routing options." },
    ],
    relatedIndustries: ["oil-and-gas-machining-houston", "aerospace-cnc-machining"],
    relatedMaterials: ["titanium-stainless-steel-machining", "inconel-superalloy-machining"],
  },
  {
    slug: "wire-edm-machining",
    name: "Wire EDM Machining",
    navLabel: "Wire EDM Machining",
    h1: "Precision Wire EDM Machining Services in Houston, TX",
    metaTitle: "Wire EDM Machining Services Houston TX | ONA EDM",
    metaDescription:
      "ONA wire EDM machining in Houston, TX for hardened alloys, sharp internal corners, thin walls and burr-free finishes. AS9100D and ITAR, in-house under one roof.",
    heroIntro:
      "ONA wire EDM cuts hardened tool steel, Inconel, titanium and thin-wall features that milling cannot reach — with sharp internal corners and burr-free edges.",
    heroImage: img.edm,
    heroUsps: [
      "ONA CNC wire EDM, submerged machining",
      "Sharp internal corners with no cutter radius",
      "Heat-affected-free cutting of hardened alloys",
    ],
    badges: ["Wire EDM", "Hardened Alloys", "Thin Wall"],
    capabilities: [
      {
        title: "Hardened Material Cutting",
        body: "Cut parts after heat treatment to avoid distortion — ideal for tooling, fixtures and wear components.",
        image: img.edm,
        points: ["Post-heat-treat cutting", "No cutter deflection", "Complex profiles"],
      },
      {
        title: "Sharp Corners & Thin Walls",
        body: "Wire EDM produces true internal corners and delicate wall sections without the radius a rotating cutter leaves.",
        image: img.metalBars,
        points: ["True square corners", "Thin-wall sections", "Fine surface finish"],
      },
      {
        title: "EDM as a Machining Partner",
        body: "We combine milling and EDM in one routing so tough features are cut in the most efficient process.",
        image: img.fiveAxis,
        points: ["Mixed routing", "One purchase order", "In-house quality records"],
      },
    ],
    callout:
      "When an aerospace or energy print calls for a sharp internal corner or a hardened feature, our ONA wire EDM handles it under the same AS9100D system as the milling work.",
    machineGroups: ["edm"],
    applications: [
      { title: "Aerospace Tooling & Fixtures", body: "Hardened fixture details, gages and die components held to print.", image: img.aerospaceEngine },
      { title: "Inconel Slots & Profiles", body: "Heat-resistant alloy components with narrow slots and sharp transitions.", image: img.oilGas },
      { title: "Wear & Die Components", body: "Post-hardening cutting of tool steel with minimal distortion.", image: img.measuringTools },
    ],
    dfmTitle: "Wire EDM DFM Checklist",
    dfmTips: [
      { title: "Plan the start hole", body: "Closed internal profiles need a start hole; specify its location or let us add it." },
      { title: "Provide the heat-treat condition", body: "EDM after hardening is often better than machining soft and warping later." },
      { title: "Avoid interrupted heavy sections", body: "Very thick sections cut slower — consider rough milling before EDM." },
      { title: "Specify corner condition", body: "Tell us if sharp or radiused internal corners are functionally required." },
      { title: "Note the material", body: "Inconel, titanium, tool steel and carbide cut at different rates and cost." },
      { title: "Sketch the wire path", body: "For complex profiles, a quick note on intended wire entry saves programming time." },
    ],
    valueProps: [
      { title: "Geometry Milling Cannot Cut", body: "True internal corners and thin features with no cutter radius limitation." },
      { title: "Protects Heat Treat", body: "Cut hardened parts after treatment to control distortion." },
      { title: "In-House Process", body: "No outsourcing, no shipping delays, no lost tolerances." },
      { title: "Same Quality System", body: "EDM parts follow the same AS9100D inspection and documentation path." },
    ],
    faqs: [
      { q: "What materials can you wire EDM?", a: "Tool steel, Inconel, titanium, stainless, aluminum and conductive exotic alloys. Carbide work is quoted case by case." },
      { q: "What is your EDM part envelope?", a: "Send the part envelope and wire-start locations with your RFQ — [Client to Provide: Wire EDM Max Part Envelope]." },
      { q: "Can you EDM parts after heat treatment?", a: "Yes, that is one of the main advantages; it avoids heat-treat distortion on finished features." },
      { q: "Do you combine EDM with milling?", a: "Yes. We route the part through both processes in-house under one work order." },
      { q: "How are EDM parts inspected?", a: "On the Hexagon CMM, Keyence IMX, and profile projector depending on feature geometry." },
      { q: "Do you support ITAR work on EDM?", a: "Yes. ITAR-controlled parts can be routed through EDM under our registered quality system." },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "defense-itar-machining"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining"],
  },
  {
    slug: "laser-engraving-part-marking",
    name: "Laser Engraving & Part Marking",
    navLabel: "Laser Marking",
    h1: "Aerospace Laser Part Marking & UID Engraving in Texas",
    metaTitle: "Laser Part Marking & UID Engraving Texas | Gretna",
    metaDescription:
      "In-house Raycus 50W fiber laser part marking in Houston, TX. UID, Data Matrix, serial and lot marking with 100 × 100 mm and 300 × 300 mm work zones.",
    heroIntro:
      "Raycus 50W fiber laser marking in two work zones — UID, Data Matrix, serial numbers, lot codes and customer logos applied in-house before packing.",
    heroImage: img.laser,
    heroUsps: [
      "Raycus 50W fiber laser with 100 × 100 mm and 300 × 300 mm zones",
      "UID / Data Matrix / serial / lot marking on metals",
      "Marking performed in-house after final inspection",
    ],
    badges: ["UID Marking", "Data Matrix", "In-House"],
    capabilities: [
      {
        title: "UID & Data Matrix Marking",
        body: "Permanent, machine-readable marks that satisfy aerospace and defense traceability requirements.",
        image: img.laser,
        points: ["UID compliance", "Data Matrix / QR", "Readable contrast"],
      },
      {
        title: "Serial & Lot Traceability",
        body: "Mark lot, heat, serial and date codes so the part carries its own traceability into service.",
        image: img.laserDetail,
        points: ["Serial numbers", "Heat / lot codes", "Date codes"],
      },
      {
        title: "Large-Zone Marking",
        body: "The 300 × 300 mm zone marks larger housings, plates and panels without repositioning.",
        image: img.measuringTools,
        points: ["300 × 300 mm zone", "Larger housings", "Single set-up"],
      },
    ],
    callout:
      "Marking is a value-add we control — not an outside vendor line item. That keeps lead times short and keeps your traceability data in our ERP record.",
    machineGroups: ["laser"],
    applications: [
      { title: "Aerospace Part Identification", body: "UID labels and direct marks for NASA, Boeing and Lockheed supply chains.", image: img.aerospaceEngine },
      { title: "Oilfield Traceability", body: "Heat and lot codes on subsea and downhole components for lifecycle records.", image: img.oilGas },
      { title: "Defense Serialization", body: "ITAR-aware serial marking on controlled hardware with documented records.", image: img.defenseJet },
    ],
    dfmTitle: "Laser Marking DFM Checklist",
    dfmTips: [
      { title: "Choose the right surface", body: "Mark on a machined or ground surface for readable contrast; avoid marking on sealing faces." },
      { title: "Provide the exact text", body: "Send UID strings, serial format, and any logo files up front to avoid rework." },
      { title: "Allow mark area", body: "Leave a clear 100 × 100 mm or 300 × 300 mm region free of features and coatings." },
      { title: "Consider post-processing", body: "Mark after anodize or plating only if the mark will remain legible — otherwise mark before." },
      { title: "Check readability", body: "Data Matrix grade requirements should be stated so we can verify with the reader." },
      { title: "Keep it permanent", body: "Direct part marking is preferred over labels for harsh-service components." },
    ],
    valueProps: [
      { title: "Traceability Built In", body: "Serialization completes the quality record before the part leaves the building." },
      { title: "No Vendor Delay", body: "Marking in-house eliminates a shipping leg and scheduling risk." },
      { title: "Two Work Zones", body: "From tiny fittings to larger housings without re-fixturing." },
      { title: "Quality Records", body: "ERP-associated marking data ties to the lot and inspection record." },
    ],
    faqs: [
      { q: "Can you mark UID codes to aerospace requirements?", a: "Yes. Our Raycus 50W fiber laser marks direct UID/Data Matrix codes. [Client to Provide: UID / Data Matrix Grading Requirements]." },
      { q: "What is the maximum mark size?", a: "100 × 100 mm and 300 × 300 mm work areas depending on fixture and part geometry." },
      { q: "Do you mark on curved surfaces?", a: "Yes, with fixturing and focus adjustment. Send part geometry with the RFQ." },
      { q: "Can you laser mark customer logos?", a: "Yes — provide vector artwork or a DXF file." },
      { q: "Is marking a standalone service?", a: "Yes, we can mark customer-supplied parts, subject to inspection and handling review." },
      { q: "Does marking come with documentation?", a: "Marking content and images can be included in the inspection record." },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "defense-itar-machining"],
    relatedMaterials: ["titanium-stainless-steel-machining", "aluminum-alloy-steel-machining"],
  },
  {
    slug: "engineering-cad-cam-assembly",
    name: "Engineering, CAD/CAM & Assembly",
    navLabel: "Engineering & Assembly",
    h1: "Turnkey Engineering, CAD/CAM Programming & Assembly",
    metaTitle: "CNC Engineering, CAD/CAM & Assembly Texas | Gretna",
    metaDescription:
      "Turnkey CNC engineering in Houston, TX: in-house certified PE, Class-A machinist CAD/CAM programmers, mechanical assembly and aerospace packaging under AS9100D.",
    heroIntro:
      "A certified Professional Engineer, Class-A machinist programmers, mechanical assembly and aerospace packaging — the manufacturing engineering layer that de-risks your build.",
    heroImage: img.cad,
    heroUsps: [
      "In-house certified Professional Engineer (PE)",
      "CAD/CAM programmed by Class-A machinist supervisors",
      "Mechanical assembly, marking and aerospace packaging",
    ],
    badges: ["In-House PE", "CAD/CAM", "Turnkey Assembly"],
    capabilities: [
      {
        title: "Manufacturing Engineering",
        body: "Our PE reviews design intent, tolerance stacks and process capability before the first chip is cut.",
        image: img.cadWoman,
        points: ["PE-stamped review", "Tolerance stack analysis", "Process planning"],
      },
      {
        title: "CAD/CAM Programming",
        body: "Machinist-programmers model fixtures, simulate toolpaths and probe parts for reliable first-article results.",
        image: img.cad,
        points: ["3D modeling", "Toolpath simulation", "Probe-based set-up"],
      },
      {
        title: "Assembly & Packaging",
        body: "Mechanical assembly, hardware installation, laser marking and protected aerospace packaging complete the box.",
        image: img.team,
        points: ["Mechanical assembly", "Hardware & kitting", "Aerospace packing"],
      },
    ],
    callout:
      "Bring us the assembly, not just the print. Engineering review, machining, marking, assembly and packaging under one AS9100D system reduces supplier count and schedule risk.",
    machineGroups: ["5-axis", "lathes"],
    applications: [
      { title: "Build-To-Print Assemblies", body: "Multi-component assemblies sourced, machined, marked and delivered as one kit.", image: img.facilityFloor },
      { title: "Prototype & NPI Support", body: "Design-for-manufacturing feedback that shortens the path from concept to production.", image: img.cad },
      { title: "Aerospace Delivery Programs", body: "AS9100D documentation, FAIR support and export-ready packaging.", image: img.aerospaceEngine },
    ],
    dfmTitle: "Engineering Review Checklist",
    dfmTips: [
      { title: "Share design intent", body: "Tell us the function of critical features — it lets us propose the least expensive capable process." },
      { title: "Freeze the revision", body: "Quote and produce from one revision to avoid rework and documentation mismatches." },
      { title: "Define inspection criteria", body: "Agree on what is measured, how, and what data is reported before first article." },
      { title: "Include assembly hardware", body: "List inserts, fasteners and treatments so the bill of material is complete." },
      { title: "Plan packaging", body: "Export, clean-room or aerospace packaging requirements should be defined at RFQ." },
      { title: "Address outside processing", body: "Identify heat treat, plating and NDT requirements early so approvals do not delay the build." },
    ],
    valueProps: [
      { title: "Engineering Depth", body: "A certified PE plus machinist-programmers review your part before production." },
      { title: "Single Point of Accountability", body: "One PO covers machining, marking, assembly and packaging." },
      { title: "Documented Builds", body: "ERP routing and inspection records trace every operation." },
      { title: "Supplier Reduction", body: "Consolidating suppliers simplifies audits and shortens schedules." },
    ],
    faqs: [
      { q: "Do you have an in-house engineer?", a: "Yes — Gretna has a certified Professional Engineer (PE) on staff for design review and manufacturing engineering." },
      { q: "Can you design the part for us?", a: "We support DFM and manufacturability review. [Client to Provide: Full Design Services Scope]." },
      { q: "Do you build assemblies?", a: "Yes. Mechanical assembly, hardware installation, laser marking, and aerospace packaging are in-house." },
      { q: "Which CAD formats do you use?", a: "We work from STEP, IGES, SolidWorks and DXF, plus PDF prints. [Client to Provide: Accepted CAD Formats & ITAR Transfer Method]." },
      { q: "Can you manage outside processes?", a: "Yes, we coordinate approved heat treat, plating, passivation and NDT suppliers. [Client to Provide: Approved Outside Processing / Nadcap Partners]." },
      { q: "Do you support first article inspection?", a: "Yes. [Client to Provide: AS9102 FAIR Capability & Lead Time]." },
    ],
    relatedIndustries: ["aerospace-cnc-machining", "defense-itar-machining"],
    relatedMaterials: ["inconel-superalloy-machining", "engineering-plastics-machining"],
  },
];

export const serviceBySlug = (slug: string) => services.find((s) => s.slug === slug);
export const serviceNav = services.map((s) => ({ slug: s.slug, label: s.navLabel }));
