import { img } from "./images";

export type IndustryContent = {
  slug: string;
  name: string;
  navLabel: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  heroIntro: string;
  heroImage: string;
  heroUsps: string[];
  badges: string[];
  components: { title: string; body: string; image?: string }[];
  machineGroups: string[];
  complianceTitle: string;
  compliance: { title: string; body: string }[];
  proof: { stat: string; label: string }[];
  faqs: { q: string; a: string }[];
  relatedServices: string[];
  relatedMaterials: string[];
};

export const industries: IndustryContent[] = [
  {
    slug: "aerospace-cnc-machining",
    name: "Aerospace Manufacturing",
    navLabel: "Aerospace",
    h1: "AS9100 Aerospace CNC Machining Supplier in Texas",
    metaTitle: "AS9100 Aerospace CNC Machining Supplier Texas | Gretna",
    metaDescription:
      "AS9100 Rev D aerospace CNC machining in Houston, TX. NASA Orion flight hardware experience, 5-axis milling, Inconel and titanium, FAIR and CMM inspection.",
    heroIntro:
      "Flight-hardware discipline for aerospace primes and their Tier 1 suppliers: AS9100 Rev D controls, true 5-axis capability, CMM verification and complete documentation packages.",
    heroImage: img.aerospaceEngine,
    heroUsps: [
      "AS9100 Rev. D / ISO 9001:2015 quality system",
      "NASA Orion Project secondary structure bracket experience",
      "In-house Hexagon CMM, FAIR support and aerospace packaging",
    ],
    badges: ["AS9100 Rev D", "NASA Orion Program", "ITAR", "HUBZone"],
    components: [
      { title: "Secondary Structure Brackets", body: "Complex bracket families with compound angles and true-position callouts, machined in single set-ups.", image: img.aerospaceEngine },
      { title: "Housings & Manifolds", body: "Thin-wall aluminum and stainless housings with flatness and sealing-surface requirements.", image: img.cncCloseup },
      { title: "Assembly & Mount Components", body: "Mounting hardware and assembly parts delivered as kits with UID marking.", image: img.facilityFloor },
      { title: "Turbine & Engine Hardware", body: "Heat-resistant alloy components machined from Inconel, Waspaloy and titanium stock.", image: img.turbine },
      { title: "Fluid & Pneumatic Fittings", body: "Precision mill-turn fittings with concentric bores, cross holes and gaged threads.", image: img.caliper },
      { title: "Ground Support & Tooling", body: "Hardened fixtures and tooling cut on our ONA wire EDM after heat treatment.", image: img.edm },
    ],
    machineGroups: ["5-axis", "4-axis", "lathes", "mill-turn", "edm"],
    complianceTitle: "Aerospace Compliance & Documentation",
    compliance: [
      { title: "AS9100 Rev. D Quality System", body: "Registered aerospace QMS with documented process control, traceability, calibration and corrective action." },
      { title: "ITAR & Export Awareness", body: "ITAR-registered facility supporting controlled programs with restricted-data handling discipline." },
      { title: "Inspection & First Article", body: "Hexagon CMM programming plus Keyence IMX and Tesa Microhite M900 support dimensional reporting. [Client to Provide: AS9102 FAIR Capability & Lead Time]." },
      { title: "Documentation Package", body: "Material certifications and inspection records accompany shipments. [Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C, PPAP]." },
    ],
    proof: [
      { stat: "NASA", label: "Orion Project secondary structure brackets" },
      { stat: "50+", label: "Employees supporting aerospace programs" },
      { stat: "1980", label: "Serving aerospace OEMs since" },
      { stat: "AS9100D", label: "Aerospace quality system registered" },
    ],
    faqs: [
      { q: "Are you an AS9100-certified machine shop in Texas?", a: "Yes. Gretna Machine Shop is AS9100 Rev. D and ISO 9001:2015 registered (Platinum Registration, Inc.) in Houston, TX." },
      { q: "Do you supply Boeing, Lockheed Martin or NASA programs?", a: "Gretna has produced NASA Orion Project secondary structure brackets and supplies aerospace primes and Fortune 500 OEMs including Boeing, Lockheed Martin and Honeywell programs." },
      { q: "How do you handle first article inspection?", a: "CMM data and inspection reports are produced against the drawing. [Client to Provide: AS9102 FAIR Capability & Lead Time]." },
      { q: "Can you machine aerospace materials like Inconel and titanium?", a: "Yes. Inconel 625/718/925, Waspaloy, MP35N, titanium and 15-5/17-4 PH stainless are routine materials." },
      { q: "Do you support HUBZone or WOSB subcontracting goals?", a: "Yes. Gretna is an SBA HUBZone-certified, Woman-Owned Small Business and minority-owned business in Houston." },
      { q: "How does aerospace packaging work?", a: "Parts are protected, marked and packed to your specification before shipment. [Client to Provide: Packaging Spec & Labeling Requirements]." },
    ],
    relatedServices: ["5-axis-cnc-machining", "cnc-milling", "wire-edm-machining"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining", "aluminum-alloy-steel-machining"],
  },
  {
    slug: "defense-itar-machining",
    name: "Defense & Government Contracting",
    navLabel: "Defense & ITAR",
    h1: "ITAR-Registered, HUBZone & WOSB Defense Machine Shop in Texas",
    metaTitle: "ITAR Defense CNC Machining Texas | HUBZone WOSB Shop",
    metaDescription:
      "ITAR-registered defense CNC machining in Houston, TX. HUBZone, WOSB, minority-owned, CAGE 0AXC7, seven NAICS codes and AS9100 Rev D quality.",
    heroIntro:
      "A procurement-ready supplier for primes and government buyers: ITAR registered, HUBZone certified, woman- and minority-owned, with CAGE 0AXC7 and seven NAICS codes.",
    heroImage: img.defenseJet,
    heroUsps: [
      "ITAR registered, SAM registered, CAGE 0AXC7",
      "SBA HUBZone / WOSB / WBENC / Minority-Owned",
      "NAICS 336411, 336413, 336419, 332710 and more",
    ],
    badges: ["ITAR Registered", "CAGE 0AXC7", "HUBZone", "SBA WOSB"],
    components: [
      { title: "Guided Missile & Space Vehicle Parts", body: "NAICS 336419 hardware machined under ITAR controls with documented traceability.", image: img.defenseJet },
      { title: "Aircraft Parts & Auxiliary Equipment", body: "NAICS 336413 structural and auxiliary components in aluminum, titanium and steel.", image: img.aerospaceEngine },
      { title: "Precision Turned Products", body: "NAICS 332721 turned hardware for defense assemblies and ground systems.", image: img.lathe },
      { title: "Valve & Pipe Fitting Hardware", body: "NAICS 332912 pressure components for shipboard and base infrastructure.", image: img.pipelines },
      { title: "Hardware & Machine Shop Products", body: "NAICS 332510 and 332710 hardware, mounts and fixtures for sustainment programs.", image: img.milling },
      { title: "Aircraft Manufacturing Support", body: "NAICS 336411 assemblies and detail parts supporting airframe programs.", image: img.fiveAxis },
    ],
    machineGroups: ["5-axis", "4-axis", "mill-turn", "edm"],
    complianceTitle: "Federal Procurement & Compliance Data",
    compliance: [
      { title: "Registered Identifiers", body: "DUNS 054633755, CAGE 0AXC7, SAM registered. ITAR registration on file for controlled programs." },
      { title: "Socioeconomic Status", body: "SBA HUBZone certified, SBA Woman-Owned Small Business, WBENC certified, minority-owned business." },
      { title: "NAICS Footprint", body: "332510, 332710, 332721, 332912, 336411, 336413, 336419 — covering hardware through space vehicle parts." },
      { title: "Controlled Data Handling", body: "ITAR-controlled prints are routed through a restricted workflow. [Client to Provide: ITAR Secure Transfer Method & Facility Clearance Status]." },
    ],
    proof: [
      { stat: "0AXC7", label: "CAGE code" },
      { stat: "054633755", label: "DUNS number" },
      { stat: "7", label: "Federal NAICS codes" },
      { stat: "HUBZone", label: "SBA certified Houston location" },
    ],
    faqs: [
      { q: "Is Gretna Machine Shop ITAR registered?", a: "Yes. Gretna is ITAR registered and SAM registered, with CAGE code 0AXC7 and DUNS 054633755." },
      { q: "What are your NAICS codes?", a: "332510, 332710, 332721, 332912, 336411, 336413 and 336419." },
      { q: "Are you a HUBZone and WOSB business?", a: "Yes. The 3450 Lang Rd. Houston facility is SBA HUBZone certified, and Gretna is a Woman-Owned Small Business, WBENC certified and minority-owned." },
      { q: "Can you support set-aside and subcontracting goals?", a: "Yes. Our HUBZone, WOSB and MOB designations support prime subcontracting plans and small business set-asides." },
      { q: "How is controlled technical data handled?", a: "Do not email controlled drawings through open channels. Mark the request ITAR controlled and our team will provide the approved transfer route. [Client to Provide: ITAR Secure Transfer Method]." },
      { q: "What documentation can you provide for a PO?", a: "Material certs, inspection data, certificates of conformance and FAIR support. [Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C, PPAP]." },
    ],
    relatedServices: ["5-axis-cnc-machining", "wire-edm-machining", "laser-engraving-part-marking"],
    relatedMaterials: ["titanium-stainless-steel-machining", "inconel-superalloy-machining"],
  },
  {
    slug: "oil-and-gas-machining-houston",
    name: "Oil & Gas Machining",
    navLabel: "Oil & Gas",
    h1: "Oil & Gas, Subsea & Downhole CNC Machining in Houston",
    metaTitle: "Oil & Gas CNC Machining Houston TX | Subsea & Downhole",
    metaDescription:
      'Houston oil and gas CNC machining: Inconel and 13% chrome, 120" long-bed turning, 7.12" bore, Gagemaker thread gaging. Subsea, downhole and compression components.',
    heroIntro:
      "Built for the Gulf Coast energy corridor: large-bore turning, exotic alloy capability, thread metrology and expedited support for subsea, downhole and compression programs.",
    heroImage: img.oilGas,
    heroUsps: [
      'Puma 480 XL up to 120" turn length and 22" diameter',
      '7.12" hollow spindle for large-bore bar work',
      "Inconel, 13% chrome, 17-4 PH and duplex stainless expertise",
    ],
    badges: ["Subsea", "Downhole", "Inconel & Chrome", "Houston HUBZone"],
    components: [
      { title: "Subsea Components", body: "Valve bodies, subs, hubs and structural parts in super duplex and 17-4 PH.", image: img.oilGas },
      { title: "Downhole Tool Bodies", body: "Long, large-diameter mandrels, sleeves and housings with steady-rest support.", image: img.lathe },
      { title: "Wellhead & Pressure Hardware", body: "Pressure-containing bodies and adapters with gaged threads and documented records.", image: img.pipelines },
      { title: "Pump & Compression Parts", body: "Shafts, impellers and manifolds for gas compression and production equipment.", image: img.cncCloseup },
      { title: "Valve & Flow Control", body: "Bonnets, seats, stems and trim in corrosion-resistant alloys.", image: img.millingDetail },
      { title: "Well Service Tooling", body: "Wear parts, fixtures and quick-turn replacement components for field service.", image: img.millingWorker },
    ],
    machineGroups: ["lathes", "mill-turn", "5-axis", "4-axis"],
    complianceTitle: "Energy Quality & Material Control",
    compliance: [
      { title: "Material Traceability", body: "Mill certifications retained against heat and lot numbers for every energy component we ship." },
      { title: "Thread & Connection Gaging", body: "Gagemaker MIC trac MT-3000 verifies thread form and pitch diameter before release." },
      { title: "Corrosion-Resistant Alloys", body: "13% chrome, 22% chrome, S410 duplex, 17-4 PH and Inconel machining experience." },
      { title: "Standards Alignment", body: "Work performed to your specification, with NACE/API requirements identified at RFQ. [Client to Provide: NACE MR0175 / API Compliance Details]." },
    ],
    proof: [
      { stat: '120"', label: "Maximum turn length" },
      { stat: '7.12"', label: "Thru-bore capacity" },
      { stat: "Inconel", label: "625 / 718 / 925 routinely machined" },
      { stat: "Houston", label: "Same-region support for Gulf Coast buyers" },
    ],
    faqs: [
      { q: "Can you machine Inconel and 13% chrome?", a: "Yes. Inconel 625/718/925, 13% chrome, 22% chrome, S410 duplex, 17-4 PH and Monel K-500 are standard materials." },
      { q: "What is your largest turning capability?", a: 'Up to 22" diameter and 120" turn length on the Puma 480 XL, with a 7.12" thru-bore on the Puma 400 L.' },
      { q: "Do you machine subsea components?", a: "Yes — Oceaneering is a named client, and subsea valve, hub and structural components are routine work." },
      { q: "Do you meet NACE or API requirements?", a: "We machine to customer specifications and identify compliance requirements at RFQ. [Client to Provide: NACE MR0175 / API Compliance Details]." },
      { q: "Can you expedite field breakdown work?", a: "We support urgent requirements where capacity allows. [Client to Provide: Standard vs. Expedite Lead Times]." },
      { q: "Do you supply material and outside processing?", a: "Yes, we can source mill-certified alloy stock and coordinate approved heat treat and coating suppliers. [Client to Provide: Approved Outside Processing / Nadcap Partners]." },
    ],
    relatedServices: ["cnc-turning", "multi-axis-mill-turn", "cnc-milling"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining", "aluminum-alloy-steel-machining"],
  },
  {
    slug: "geothermal-energy-machining",
    name: "Geothermal Energy",
    navLabel: "Geothermal",
    h1: "Geothermal Energy Superalloy CNC Machining in Texas",
    metaTitle: "Geothermal Energy CNC Machining Texas | Superalloys",
    metaDescription:
      "Geothermal and energy transition CNC machining in Houston, TX. Inconel, duplex and titanium components for high-temperature, corrosive service. AS9100D quality.",
    heroIntro:
      "High-temperature, corrosive-service hardware for geothermal and energy transition programs — machined from superalloys with the documentation your engineers need.",
    heroImage: img.facility,
    heroUsps: [
      "Inconel, duplex, titanium and MP35N for aggressive service",
      "Large-bore turning and mill-turn for drilling and surface equipment",
      "AS9100 Rev D documentation and CMM verification",
    ],
    badges: ["Geothermal", "Superalloys", "Energy Transition"],
    components: [
      { title: "Drilling & Wellbore Hardware", body: "Bodies, stabilizers and tool components for high-temperature wellbore service.", image: img.lathe },
      { title: "Heat Exchanger Components", body: "Corrosion-resistant tubesheets, flanges and fittings for thermal loops.", image: img.pipelines },
      { title: "Pump & Turbine Parts", body: "Impellers, shafts and housings machined from heat-resistant alloys.", image: img.turbine },
      { title: "Valve & Flow Control", body: "High-temperature valve bodies, seats and trim with gaged threads.", image: img.oilGas },
      { title: "Surface Equipment", body: "Manifolds, skid components and structural hardware for plant balance-of-plant.", image: img.facilityFloor },
      { title: "Fasteners & Precision Hardware", body: "Superalloy fasteners and turned hardware for elevated-temperature joints.", image: img.metalBars },
    ],
    machineGroups: ["lathes", "mill-turn", "5-axis"],
    complianceTitle: "Materials & Quality for Harsh Service",
    compliance: [
      { title: "High-Temperature Alloys", body: "Inconel 625/718, Waspaloy, Hastelloy and MP35N machined with controlled heat and tooling." },
      { title: "Corrosion-Resistant Stainless", body: "Duplex S410, 13% chrome, 17-4 PH and 300-series stainless for geothermal brine service." },
      { title: "Inspection Discipline", body: "CMM and Keyence verification of critical bores, faces and true position on large components." },
      { title: "Documentation", body: "Material certifications and dimensional records support plant engineering and audit requirements. [Client to Provide: Documentation Requirements]." },
    ],
    proof: [
      { stat: "Inconel", label: "625 / 718 / 925 capability" },
      { stat: "Titanium", label: "Ti and MP35N machining" },
      { stat: "AS9100D", label: "Aerospace-grade quality system" },
      { stat: "Houston", label: "Gulf Coast energy supply chain" },
    ],
    faqs: [
      { q: "Do you machine geothermal-specific alloys?", a: "Yes — Inconel, Hastelloy, duplex stainless, titanium and MP35N are all machined regularly for energy applications." },
      { q: "Can you handle large geothermal components?", a: 'Our large-capacity turning reaches 22" diameter and 120" length, with milling envelopes up to 80.7" X travel.' },
      { q: "Do you provide material certifications?", a: "Yes, we retain and supply mill certifications with the shipment. [Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C]." },
      { q: "What quality system is used?", a: "The same AS9100 Rev. D / ISO 9001:2015 system used for aerospace flight hardware." },
      { q: "Can you support prototype geothermal hardware?", a: "Yes, prototypes and low-volume builds are welcome. [Client to Provide: Production Volume Sweet Spot / MOQ]." },
      { q: "How do I start an RFQ?", a: "Submit prints and CAD through our RFQ page or email quotes@gretnamachine.com with quantities, material and required delivery." },
    ],
    relatedServices: ["cnc-turning", "cnc-machining-houston-tx", "engineering-cad-cam-assembly"],
    relatedMaterials: ["inconel-superalloy-machining", "titanium-stainless-steel-machining"],
  },
];

export const industryBySlug = (slug: string) => industries.find((i) => i.slug === slug);
export const industryNav = industries.map((i) => ({ slug: i.slug, label: i.navLabel }));
