import { img } from "./images";

export type MaterialContent = {
  slug: string;
  name: string;
  navLabel: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  heroIntro: string;
  heroImage: string;
  heroUsps: string[];
  badges: string[];
  grades: { grade: string; family: string; machinability: string; applications: string }[];
  advantages: { title: string; body: string }[];
  industriesUsing: string[];
  dfmTips: { title: string; body: string }[];
  faqs: { q: string; a: string }[];
  relatedServices: string[];
  equipmentGroups: string[];
};

export const materials: MaterialContent[] = [
  {
    slug: "inconel-superalloy-machining",
    name: "Inconel & Superalloys",
    navLabel: "Inconel & Superalloys",
    h1: "Inconel 718, 625 & Superalloy CNC Machining in Houston",
    metaTitle: "Inconel 718 & 625 CNC Machining Houston TX | Superalloys",
    metaDescription:
      "Inconel 718, 625, 925, Monel K-500, Hastelloy, Waspaloy and MP35N CNC machining in Houston, TX. Rigid Okuma machines, 5-axis and Wire EDM support.",
    heroIntro:
      "Nickel and cobalt superalloys are our home turf. Rigid Okuma and Doosan platforms, controlled heat input and the tooling strategy required to hit tolerance in work-hardening alloys.",
    heroImage: img.turbine,
    heroUsps: [
      "Inconel 625 / 718 / 925, Monel K-500, Hastelloy, Waspaloy, MP35N",
      "True 5-axis and Wire EDM support for hardened and complex features",
      "Aerospace and energy experience with documented material traceability",
    ],
    badges: ["Inconel 718", "Inconel 625", "Hastelloy", "MP35N"],
    grades: [
      { grade: "Inconel 718", family: "Nickel superalloy", machinability: "Difficult — work-hardens, low thermal conductivity", applications: "Aerospace brackets, turbine hardware, downhole tools" },
      { grade: "Inconel 625", family: "Nickel superalloy", machinability: "Difficult — gummy, high strength at temperature", applications: "Subsea components, exhaust systems, corrosion service" },
      { grade: "Inconel 925", family: "Nickel superalloy", machinability: "Moderate to difficult", applications: "Oilfield tubulars and pressure hardware" },
      { grade: "Monel K-500", family: "Nickel-copper alloy", machinability: "Moderate — abrasive", applications: "Marine and pump shafts, valve trim" },
      { grade: "Hastelloy", family: "Nickel-molybdenum", machinability: "Difficult — severe work hardening", applications: "Chemical and corrosive-service flow components" },
      { grade: "Waspaloy", family: "Nickel superalloy", machinability: "Difficult — heat treated strength", applications: "Aerospace turbine and engine hardware" },
      { grade: "MP35N", family: "Cobalt-nickel alloy", machinability: "Very difficult", applications: "Medical, aerospace and high-strength fasteners" },
    ],
    advantages: [
      { title: "Rigid, Modern Platforms", body: "Okuma MU5000V-L, M460V-5AX and MB-5000H give the stiffness needed to hold tolerance in Inconel without chatter." },
      { title: "Heat & Tooling Discipline", body: "High-pressure coolant, conservative radial engagement and fresh tooling prevent the work hardening that ruins superalloy parts." },
      { title: "Wire EDM for Hardened Features", body: "Our ONA wire EDM cuts sharp internal corners and post-heat-treat features that milling struggles to produce." },
      { title: "Inspection Confidence", body: "Hexagon CMM and Keyence inspection verify critical features in alloys where rework is expensive." },
    ],
    industriesUsing: ["Aerospace", "Defense", "Oil & Gas", "Geothermal"],
    dfmTips: [
      { title: "Allow enough stock", body: "Leave material for a clean-up pass; superalloys need a fresh edge and consistent radial engagement." },
      { title: "Avoid thin unsupported walls", body: "Nickel alloys resist cutting, so thin walls deflect and chatter. Increase thickness or add supporting geometry." },
      { title: "Standard hole sizes only", body: "Special sizes mean extra tools in material that wears tools quickly." },
      { title: "Plan heat treat", body: "Decide whether features are cut before or after heat treatment to avoid distortion." },
      { title: "Specify finish realistically", body: "Inconel surface finishes are achievable but costly; call out Ra only on sealing and bearing features." },
      { title: "Send the model", body: "3D geometry lets our programmers simulate tool engagement before cutting high-value material." },
    ],
    faqs: [
      { q: "Do you machine Inconel 718 and 625?", a: "Yes. Inconel 625, 718 and 925, plus Waspaloy, Hastelloy, Monel K-500 and MP35N are regularly machined." },
      { q: "What machines do you run superalloys on?", a: "Okuma MU5000V-L, Okuma M460V-5AX, HAAS UMC-1000, Okuma MB-5000H and Doosan turning centers, plus ONA wire EDM." },
      { q: "Can you hold tight tolerances in Inconel?", a: "Yes, with correct tooling and inspection. [Client to Provide: Standard & Tightest Tolerances]." },
      { q: "Do you source Inconel material?", a: "We can supply mill-certified stock or machine customer-supplied material. [Client to Provide: Material Sourcing Preferences]." },
      { q: "Can you machine Inconel after heat treatment?", a: "Yes, and wire EDM is often the best route for post-heat-treat features." },
      { q: "What documentation comes with superalloy parts?", a: "Mill certifications and dimensional inspection records are standard. [Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C]." },
    ],
    relatedServices: ["5-axis-cnc-machining", "cnc-turning", "wire-edm-machining"],
    equipmentGroups: ["5-axis", "4-axis", "lathes", "edm"],
  },
  {
    slug: "titanium-stainless-steel-machining",
    name: "Titanium & Stainless Steel",
    navLabel: "Titanium & Stainless",
    h1: "Titanium, 17-4 PH & 13% Chrome CNC Machining in Texas",
    metaTitle: "Titanium & 17-4 PH Stainless CNC Machining Texas | Gretna",
    metaDescription:
      "Titanium, 17-4 PH, 13-8, 300-series, 13% chrome, 22% chrome and S410 duplex CNC machining in Houston, TX. AS9100D, ITAR and 5-axis capability.",
    heroIntro:
      "Corrosion-resistant and high-strength alloys for aerospace, subsea and pressure service — machined, inspected and documented in one Houston facility.",
    heroImage: img.metalBars,
    heroUsps: [
      "Titanium alloys, 13-8, 17-4 PH and 300-series stainless",
      "13% / 22% / Super 13% chrome, 9% chrome and S410 duplex",
      "Large-bore turning and 5-axis milling in one shop",
    ],
    badges: ["Titanium", "17-4 PH", "13% Chrome", "Duplex"],
    grades: [
      { grade: "Titanium alloys", family: "Reactive metal", machinability: "Difficult — low conductivity, galling risk", applications: "Aerospace structures, subsea hardware, weight-critical parts" },
      { grade: "17-4 PH stainless", family: "Precipitation-hardening", machinability: "Moderate — condition dependent", applications: "Valve bodies, shafts, high-strength fittings" },
      { grade: "13-8 stainless", family: "Precipitation-hardening", machinability: "Moderate", applications: "Aerospace and high-strength corrosion service" },
      { grade: "300-series stainless", family: "Austenitic", machinability: "Moderate — gummy", applications: "General corrosion-resistant machined components" },
      { grade: "13% chrome", family: "Martensitic stainless", machinability: "Moderate", applications: "Oilfield flow control and pressure components" },
      { grade: "22% / Super 13% chrome", family: "Duplex / super duplex", machinability: "Difficult", applications: "Subsea manifolds and high-chloride service" },
      { grade: "S410 duplex", family: "Duplex stainless", machinability: "Difficult", applications: "Pump and valve components in corrosive brine" },
    ],
    advantages: [
      { title: "5-Axis in Titanium", body: "True 5-axis capability finishes compound aerospace geometry with fewer set-ups and less re-fixturing." },
      { title: "Thread & Bore Expertise", body: "Gagemaker MIC trac MT-3000 thread verification for stainless pressure connections and oilfield threads." },
      { title: "Large Diameter Turning", body: 'Puma 480 XL and 400 L handle up to 22" diameter and 120" length with a 7.12" thru-bore.' },
      { title: "Documented Traceability", body: "Material certifications, CMM data and marking records follow the part through shipment." },
    ],
    industriesUsing: ["Aerospace", "Defense", "Oil & Gas", "Geothermal"],
    dfmTips: [
      { title: "Control heat in titanium", body: "Titanium galls and work-hardens; generous coolant and sharp tools are essential — avoid dwelling." },
      { title: "Avoid sharp corners", body: "Radii reduce stress concentration and tool wear in stainless and duplex alloys." },
      { title: "Specify the condition", body: "17-4 PH in H1150 versus H900 machines very differently — state the heat-treat condition." },
      { title: "Plan passivation", body: "If passivation or pickling is required, note it so finishing is sequenced before final inspection." },
      { title: "Watch duplex machining", body: "Duplex stainless requires slower speeds and higher feed pressure; plan cycle time accordingly." },
      { title: "Call out threads", body: "Provide thread class and whether gauging is required before shipment." },
    ],
    faqs: [
      { q: "Can you machine titanium?", a: "Yes. Titanium is machined regularly for aerospace and subsea work using the correct tooling and coolant strategy." },
      { q: "Which stainless grades do you machine?", a: "13-8, 17-4 PH, 300 series, 410, 420 modified, 13% chrome, 22% chrome, super 13% chrome, 9% chrome and S410 duplex." },
      { q: "Do you machine 17-4 PH in the heat-treated condition?", a: "Yes, but the condition must be stated on the RFQ. Machinability varies significantly by heat treat." },
      { q: "Can you hold concentricity on long parts?", a: "Yes, with pass-through steady rests and documented runout checks on long-bed lathes." },
      { q: "Do you passivate or pickle parts?", a: "We coordinate approved finishing suppliers. [Client to Provide: Approved Outside Processing / Nadcap Partners]." },
      { q: "Do you supply material certifications?", a: "Yes, mill certifications are retained and supplied with the shipment." },
    ],
    relatedServices: ["cnc-milling", "cnc-turning", "multi-axis-mill-turn"],
    equipmentGroups: ["lathes", "mill-turn", "5-axis"],
  },
  {
    slug: "aluminum-alloy-steel-machining",
    name: "Aluminum & Alloy Steel",
    navLabel: "Aluminum & Alloy Steel",
    h1: "7075 Aluminum & 4140 Alloy Steel CNC Machining in Texas",
    metaTitle: "7075 Aluminum & 4140 Alloy Steel CNC Machining TX | Gretna",
    metaDescription:
      "4140, 4340, 4130, 8620 alloy steel and 6061/7075 aluminum CNC machining in Houston, TX. Large-envelope milling, turning and assembly under AS9100D.",
    heroIntro:
      "High-volume and large-envelope work in aluminum and alloy steels — from 7075 aerospace plates to 4140/4340 oilfield bodies machined on Okuma and Doosan equipment.",
    heroImage: img.milling,
    heroUsps: [
      "2011, 2024, 6061 and 7075 aluminum",
      "4130, 4140–4145, 4340, 1018–1026 and 8620 alloy steel",
      'Milling envelopes to 80.7" X travel and 5,551 lb table loads',
    ],
    badges: ["7075 Aluminum", "4140 / 4340", "Large Envelope"],
    grades: [
      { grade: "7075 aluminum", family: "Aluminum alloy", machinability: "Excellent", applications: "Aerospace structures, fixtures, high-strength plates" },
      { grade: "6061 aluminum", family: "Aluminum alloy", machinability: "Excellent", applications: "Housings, manifolds, general machined components" },
      { grade: "2024 aluminum", family: "Aluminum alloy", machinability: "Good", applications: "Aerospace skins and structural parts" },
      { grade: "2011 aluminum", family: "Aluminum alloy", machinability: "Excellent — free machining", applications: "Precision turned fittings and hardware" },
      { grade: "4140 / 4145 steel", family: "Alloy steel", machinability: "Moderate", applications: "Oilfield bodies, shafts, pressure components" },
      { grade: "4340 steel", family: "Alloy steel", machinability: "Moderate — tough", applications: "High-strength shafts and structural hardware" },
      { grade: "4130 / 8620 steel", family: "Alloy steel", machinability: "Moderate", applications: "Weldments, gears, mounts and general machine parts" },
    ],
    advantages: [
      { title: "Large Aluminum Envelopes", body: "Okuma Millac 1052V II and Doosan DNM 6700 handle large plates and housings with less fixturing." },
      { title: "Production Volume", body: "Pallet-changing horizontals and multiple VMCs support repeat and blanket order quantities." },
      { title: "Turning Large Steel Bodies", body: 'Puma 480 XL turns 22" diameter, 120" long 4140 and 4340 components.' },
      { title: "One-Stop Finishing", body: "Laser marking, assembly and packaging complete the order without a second supplier." },
    ],
    industriesUsing: ["Aerospace", "Defense", "Oil & Gas", "Industrial OEM"],
    dfmTips: [
      { title: "Allow for stress relief", body: "Aluminum plate and 4340 can move after heavy stock removal; note if stress relief is required." },
      { title: "Use standard thicknesses", body: "Sizing parts from standard plate thickness reduces material cost and lead time." },
      { title: "Specify anodize sequence", body: "Anodizing changes dimensions slightly — decide whether critical features are masked." },
      { title: "Avoid thin aluminum walls", body: "Thin walls vibrate at high spindle speeds; add ribs or increase thickness." },
      { title: "Consider steel heat treat", body: "4140 pre-hard versus annealed changes both machinability and distortion." },
      { title: "List hardware", body: "Include inserts and fasteners so assembly can be quoted with the machining." },
    ],
    faqs: [
      { q: "Can you machine 7075 aluminum?", a: "Yes, along with 2011, 2024 and 6061 aluminum in plate, bar and billet form." },
      { q: "What is your largest aluminum milling envelope?", a: '80.7" × 41.7" × 31.5" travels on the Okuma Millac 1052V II with a 5,551 lb table capacity.' },
      { q: "Do you machine 4140 and 4340?", a: "Yes. 4130, 4140–4145, 4340, 1018–1026, 8620, castings, forgings, casing and cast iron are all machined." },
      { q: "Can you heat treat and finish alloy steel parts?", a: "We coordinate approved heat treat and finishing suppliers. [Client to Provide: Approved Outside Processing / Nadcap Partners]." },
      { q: "Do you do high-volume aluminum work?", a: "Yes, with pallet-changing HMCs and multiple VMCs. [Client to Provide: Production Volume Sweet Spot / MOQ]." },
      { q: "Can you supply the material?", a: "Yes, we can source certified aluminum and alloy steel stock with mill certs." },
    ],
    relatedServices: ["cnc-milling", "cnc-machining-houston-tx", "engineering-cad-cam-assembly"],
    equipmentGroups: ["4-axis", "5-axis", "lathes"],
  },
  {
    slug: "engineering-plastics-machining",
    name: "Engineering Plastics",
    navLabel: "Engineering Plastics",
    h1: "PEEK, Delrin & Acetal CNC Plastic Machining in Houston",
    metaTitle: "PEEK Delrin Acetal CNC Plastic Machining Houston TX",
    metaDescription:
      "PEEK, Delrin, Acetal and HDPE CNC machining in Houston, TX. Precision plastic components for energy, medical and industrial applications. Fast RFQ review.",
    heroIntro:
      "Precision polymer components machined on the same CNC platforms as our metal work — for sealing, insulation, wear and low-friction applications.",
    heroImage: img.millingDetail,
    heroUsps: [
      "PEEK, Delrin, Acetal and HDPE machining",
      "Tight-tolerance plastic parts for energy and industrial use",
      "Same AS9100D inspection discipline applied to polymers",
    ],
    badges: ["PEEK", "Delrin", "Acetal", "HDPE"],
    grades: [
      { grade: "PEEK", family: "High-performance thermoplastic", machinability: "Moderate — abrasive, stress sensitive", applications: "Seals, insulators, high-temperature wear parts" },
      { grade: "Delrin (acetal homopolymer)", family: "Engineering thermoplastic", machinability: "Excellent", applications: "Bushings, spacers, precision mechanical parts" },
      { grade: "Acetal copolymer", family: "Engineering thermoplastic", machinability: "Excellent", applications: "Wear strips, guides, fluid handling parts" },
      { grade: "HDPE", family: "Polyolefin", machinability: "Excellent", applications: "Chemical-resistant blocks, liners and chutes" },
    ],
    advantages: [
      { title: "Sharp, Clean Tooling", body: "Polished tooling and controlled feeds prevent melting and leave machined plastic with clean edges." },
      { title: "Stress Control", body: "Proper stock removal and support strategy keep close-tolerance plastic parts flat and stable." },
      { title: "Prototype to Production", body: "The same CNC platforms produce one-off prototypes and repeat plastic component runs." },
      { title: "In-House Inspection", body: "Optical and CMM inspection suitable for non-conductive, delicate polymer parts." },
    ],
    industriesUsing: ["Oil & Gas", "Industrial OEM", "Medical & Instrumentation", "Semiconductor"],
    dfmTips: [
      { title: "Avoid sharp internal corners", body: "Plastic stress-cracks at sharp corners; add radii wherever possible." },
      { title: "Allow for thermal expansion", body: "Plastics move more than metals with temperature — define the inspection temperature." },
      { title: "Design for clamping", body: "Soft materials deform under clamping pressure; generous flats help hold tolerance." },
      { title: "Skip unnecessary finishes", body: "Machined plastic often needs no secondary finishing; specify only functional surfaces." },
      { title: "Specify the grade", body: "Virgin, reprocessed and glass-filled versions machine and perform very differently." },
      { title: "Plan deburring", body: "State whether edges need hand deburring or a radius to prevent crack initiation." },
    ],
    faqs: [
      { q: "What plastics do you machine?", a: "PEEK, Delrin, Acetal and HDPE are standard. Contact us about other polymers." },
      { q: "Can you hold tight tolerances in plastic?", a: "Yes, with the right stock, tooling and temperature control. [Client to Provide: Plastic Tolerances & Inspection Conditions]." },
      { q: "Do you machine PEEK for energy applications?", a: "Yes — PEEK seals, insulators and wear components for oilfield and industrial equipment are routine." },
      { q: "Can plastic parts be laser marked?", a: "Some polymers mark well and others do not. Send the material and marking requirement for review." },
      { q: "Do you supply the plastic stock?", a: "We can source standard shapes or machine customer-supplied material." },
      { q: "What quantities do you run?", a: "Prototypes through production runs. Send quantity and annual usage with the RFQ." },
    ],
    relatedServices: ["cnc-milling", "cnc-turning", "engineering-cad-cam-assembly"],
    equipmentGroups: ["4-axis", "lathes"],
  },
];

export const materialBySlug = (slug: string) => materials.find((m) => m.slug === slug);
export const materialNav = materials.map((m) => ({ slug: m.slug, label: m.navLabel }));

export const materialFamilies = [
  { name: "Inconel & Superalloys", grades: "625, 718, 925, Waspaloy, Hastelloy, MP35N", slug: "inconel-superalloy-machining" },
  { name: "Titanium", grades: "Commercially pure and alloy grades", slug: "titanium-stainless-steel-machining" },
  { name: "Stainless & Chrome", grades: "13-8, 17-4 PH, 300 series, 410, 420 mod, 13%/22% chrome, S410 duplex", slug: "titanium-stainless-steel-machining" },
  { name: "Alloy & Carbon Steel", grades: "4130, 4140–4145, 4340, 1018–1026, 8620", slug: "aluminum-alloy-steel-machining" },
  { name: "Aluminum", grades: "2011, 2024, 6061, 7075", slug: "aluminum-alloy-steel-machining" },
  { name: "Copper, Brass & Bronze", grades: "Copper alloys and bearing bronzes", slug: "aluminum-alloy-steel-machining" },
  { name: "Castings & Forgings", grades: "Iron, steel and alloy castings/forgings", slug: "aluminum-alloy-steel-machining" },
  { name: "Engineering Plastics", grades: "PEEK, Delrin, Acetal, HDPE", slug: "engineering-plastics-machining" },
];
