import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { img } from "@/lib/images";
import { caseStudies } from "@/lib/site";
import { buildMetadata } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "Aerospace & Oilfield CNC Machining Case Studies | Texas",
  description:
    "Gretna Machine Shop case studies: NASA Orion secondary structure brackets, subsea superalloy valve components and ITAR-controlled instrumentation housings from Houston, TX.",
  path: "/case-studies",
});

export default function CaseStudiesPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Case Studies", href: "/case-studies" }]}
        eyebrow="Proof • Houston, TX"
        h1="Aerospace & Oilfield CNC Machining Case Studies"
        intro="Verified program experience and the process detail behind it. Anonymized part case studies with dimensions and photos are being prepared for publication."
        usps={[
          "NASA Orion Project secondary structure brackets and assembly parts",
          "Subsea superalloy components with thread metrology",
          "ITAR-controlled housings with UID laser marking",
        ]}
        badges={["NASA Orion", "Subsea", "ITAR", "AS9100D"]}
        image={img.aerospaceEngine}
        imageAlt="Aerospace engine hardware machined by Gretna Machine Shop in Houston, TX"
        secondary={{ href: "/industries/aerospace-cnc-machining", label: "Aerospace Capability" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Featured Work"
            title="Programs, Processes & Documentation"
            subtitle="Each entry lists what we controlled — material, process, inspection and compliance — not just a logo."
          />
          <div className="space-y-6">
            {caseStudies.map((cs, i) => (
              <article
                key={cs.slug}
                className="grid overflow-hidden rounded-sm border border-line bg-white lg:grid-cols-[0.42fr_0.58fr]"
              >
                <div className={`relative min-h-[240px] ${i % 2 === 1 ? "lg:order-2" : ""}`}>
                  <Image src={cs.image} alt={cs.title} fill sizes="(max-width: 1024px) 100vw, 42vw" className="object-cover" />
                  <span className="absolute left-3 top-3 rounded-sm bg-brand-blue-dark/90 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white">
                    {cs.industry}
                  </span>
                </div>
                <div className="p-5 lg:p-7">
                  <h2 className="text-[20px] font-extrabold leading-tight text-ink">{cs.title}</h2>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-slate-body">{cs.summary}</p>
                  <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-line bg-line">
                    {cs.specs.map((s) => (
                      <div key={s.label} className="bg-white px-3 py-2.5">
                        <dt className="text-[9.5px] font-bold uppercase tracking-[0.12em] text-slate-400">{s.label}</dt>
                        <dd className="mt-0.5 text-[12px] font-semibold text-ink">{s.value}</dd>
                      </div>
                    ))}
                  </dl>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button href="/request-a-quote" variant="outline">
                      Quote a similar part
                    </Button>
                    <Link href="/quality-assurance-inspection" className="inline-flex items-center px-2 text-[11.5px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:text-brand-red">
                      Quality detail →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12">
        <Container>
          <div className="rounded-sm border border-dashed border-amber-500/70 bg-amber-50/60 p-6">
            <h2 className="text-[17px] font-extrabold text-ink">Additional Part Case Studies</h2>
            <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-slate-body">
              To help procurement engineers validate capability, we are publishing 3–6 anonymized
              part studies that include material, dimensions, tolerance held, machine used, and the
              commercial outcome. Each will link to the relevant service page.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <ClientTag>[Client to Provide: 3-6 Real Part Case Studies with Dimensions &amp; Photos]</ClientTag>
              <ClientTag>[Client to Provide: Customer Quotes or Permission to Name Programs]</ClientTag>
              <ClientTag>[Client to Provide: OTD % &amp; Quality Acceptance Rate per Program]</ClientTag>
            </div>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Have a Comparable Part?"
        body="Send the print or model with material, quantity and delivery target. We will confirm process, machine and inspection approach."
      />

      <RelatedLinks
        title="Related Pages"
        links={[
          { label: "Aerospace Machining", href: "/industries/aerospace-cnc-machining" },
          { label: "Oil & Gas Machining", href: "/industries/oil-and-gas-machining-houston" },
          { label: "5-Axis CNC Machining", href: "/services/5-axis-cnc-machining" },
          { label: "CNC Turning", href: "/services/cnc-turning" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />
    </>
  );
}
