import type { Metadata } from "next";
import Link from "next/link";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata } from "@/lib/seo";
import { ContactForm } from "@/components/lead-forms";
import { Button, CertStrip, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "Contact Gretna Machine Shop | Houston, TX CNC Machining",
  description:
    "Contact Gretna Machine Shop at 3450 Lang Rd., Houston, TX 77092. Call 713-690-7328, email quotes@gretnamachine.com, or send a message. Mon–Fri 7:00 AM – 4:30 PM CST.",
  path: "/contact",
});

export default function ContactPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Contact", href: "/contact" }]}
        eyebrow="Contact • Houston, TX"
        h1="Contact Gretna Machine Shop in Houston, TX"
        intro="Talk with real machinists and engineers — not a call center. Send a message, call the shop, or stop by our 50,000 sq. ft. facility on Lang Road."
        usps={[
          "Phone 713-690-7328 • Fax 713-690-7350",
          "quotes@gretnamachine.com for RFQs and pricing",
          "3450 Lang Rd., Houston, TX 77092 — Mon–Fri, 7:00 AM – 4:30 PM CST",
        ]}
        badges={["Houston HUBZone", "AS9100 Rev D", "ITAR", "WOSB"]}
        image={img.facility}
        imageAlt="Gretna Machine Shop capabilities statement cover"
        primary={{ href: "/request-a-quote", label: "Request a Quote" }}
        secondary={{ href: `tel:${company.phoneHref}`, label: `Call ${company.phone}` }}
        microTrust="Same-day response during business hours • ITAR-aware RFQ workflow"
      />

      <section className="py-12 lg:py-16">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[0.6fr_0.4fr] lg:gap-10">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Send a Message"
                title="How Can We Help?"
                subtitle="For drawings and CAD files, use the RFQ form so our engineering team can review the package properly."
              />
              <ContactForm />
              <p className="mt-4 text-[12px] text-slate-500">
                Sending prints?{" "}
                <Link href="/request-a-quote" className="font-bold text-brand-red hover:underline">
                  Use the RFQ workflow instead →
                </Link>
              </p>
            </div>

            <div className="space-y-4">
              <div className="rounded-sm border border-line bg-white p-5">
                <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">Direct Contact</h2>
                <dl className="mt-3 space-y-2.5 text-[12.5px]">
                  <div>
                    <dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Address</dt>
                    <dd className="text-ink">
                      <a
                        href="https://maps.google.com/?q=3450+Lang+Rd,+Houston,+TX+77092"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-brand-red"
                      >
                        {company.address.street}
                        <br />
                        {company.address.city}, {company.address.state} {company.address.zip}
                      </a>
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Phone / Fax</dt>
                    <dd className="text-ink">
                      <a href={`tel:${company.phoneHref}`} className="font-bold hover:text-brand-red">{company.phone}</a>
                      <br />
                      Fax {company.fax}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Hours</dt>
                    <dd className="text-ink">{company.hours}</dd>
                  </div>
                </dl>
              </div>

              <div className="rounded-sm border border-line bg-white p-5">
                <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">Email Directory</h2>
                <ul className="mt-3 space-y-2 text-[12.5px]">
                  {[
                    { label: "RFQs & Sales", value: company.emails.quotes },
                    { label: "General Info", value: company.emails.info },
                    { label: "Alex Barreneche, Director of Sales & Marketing", value: company.emails.sales },
                    { label: "Careers / HR", value: company.emails.hr },
                  ].map((e) => (
                    <li key={e.value}>
                      <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">{e.label}</p>
                      <a href={`mailto:${e.value}`} className="break-all font-semibold text-ink hover:text-brand-red">
                        {e.value}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-sm border border-line bg-paper p-5">
                <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">Procurement Identifiers</h2>
                <p className="mt-2 text-[12.5px] text-slate-body">
                  DUNS {company.identifiers.duns} • CAGE {company.identifiers.cage} • SAM registered
                </p>
                <div className="mt-3">
                  <CertStrip />
                </div>
                <div className="mt-3 grid gap-2">
                  <Button href="/gretna-capabilities-statement.pdf" variant="outline" target="_blank" className="w-full">
                    Capabilities Statement PDF
                  </Button>
                  <Button href="/certifications" variant="outline" className="w-full">
                    Certifications
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12">
        <Container>
          <div className="grid gap-6 lg:grid-cols-[1fr_1fr] lg:items-center">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Facility Visits"
                title="Come See the Shop"
                subtitle="Supplier audits, capability reviews and first-article kickoffs can be scheduled at our Houston facility."
              />
              <ul className="space-y-2 text-[13.5px] text-slate-body">
                {[
                  "3450 Lang Rd., Houston, TX 77092 — Houston industrial corridor (HUBZone)",
                  "50,000 sq. ft. air-conditioned lean manufacturing facility",
                  "Bring your print package; our engineering team can review on site",
                  "ITAR-controlled visits coordinated in advance",
                ].map((i) => (
                  <li key={i} className="flex gap-2.5">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-sm border border-line bg-white p-5">
              <h2 className="text-[15px] font-extrabold text-ink">Sales & Engineering Contacts</h2>
              <div className="mt-3 space-y-3">
                {[
                  { name: company.salesContact.name, title: company.salesContact.title },
                  { name: "Nubia A. Pérez", title: "CEO & Part-Owner" },
                  { name: "Nancy Pérez", title: "Head of Strategic Partnerships & Part-Owner" },
                ].map((p) => (
                  <div key={p.name} className="border-b border-line pb-2.5 last:border-0 last:pb-0">
                    <p className="text-[13px] font-bold text-ink">{p.name}</p>
                    <p className="text-[11.5px] text-slate-500">{p.title}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      <CtaBand title="Need a Quote Instead?" body="Upload CAD and prints to the RFQ workflow for an engineering-reviewed response." />

      <RelatedLinks
        title="Helpful Pages"
        links={[
          { label: "Request a Quote", href: "/request-a-quote" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Certifications", href: "/certifications" },
          { label: "About Gretna", href: "/about" },
          { label: "Careers", href: "/careers" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
        ]}
      />
    </>
  );
}
