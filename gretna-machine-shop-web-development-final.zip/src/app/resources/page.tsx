import type { Metadata } from "next";
import Link from "next/link";
import { img } from "@/lib/images";
import { procurementGaps, resources } from "@/lib/site";
import { buildMetadata } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "CNC Machining DFM Guides & Procurement Resources | Texas",
  description:
    "DFM tolerance guides, Inconel machining notes, long-bed turning design rules and aerospace RFQ checklists from Gretna Machine Shop in Houston, Texas.",
  path: "/resources",
});

export default function ResourcesPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Resources", href: "/resources" }]}
        eyebrow="Resources • DFM & Procurement"
        h1="CNC Machining DFM Guides & Procurement Resources"
        intro="Practical content for engineers and buyers: tolerance strategy, material behavior, long-part design rules and what to include in an RFQ. No gated PDFs, no dead blog categories."
        usps={[
          "Written by machinist-programmers and manufacturing engineers",
          "Focused on aerospace, defense and energy part families",
          "Every guide links to the applicable service and material page",
        ]}
        badges={["DFM Guides", "Material Notes", "RFQ Checklists"]}
        image={img.cad}
        imageAlt="Gretna engineer reviewing CAD geometry for manufacturability"
        secondary={{ href: "/contact", label: "Ask Our Engineers" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Guides"
            title="Read Before You Send Prints"
            subtitle="Short, practical articles that shorten quote cycles and reduce rework."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {resources.map((r) => (
              <article key={r.slug} className="flex flex-col rounded-sm border border-line bg-white p-5">
                <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand-red">{r.category}</p>
                <h2 className="mt-2 text-[16px] font-extrabold leading-snug text-ink">{r.title}</h2>
                <p className="mt-2 flex-1 text-[12.5px] leading-relaxed text-slate-body">{r.excerpt}</p>
                <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400">{r.readTime}</span>
                  <Link href="/request-a-quote" className="text-[11px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:text-brand-red">
                    Discuss with us →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <p className="mt-5 rounded-sm border border-line bg-brand-blue-light/40 px-4 py-3 text-[12px] text-slate-body">
            Full article bodies are being migrated from the legacy blog (6 posts since 2019) into
            this resource hub. Each guide above is live as a summary and links to engineering
            support. <ClientTag>[Client to Provide: Final Article Copy &amp; Approvals]</ClientTag>
          </p>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Procurement Data Sheet"
            title="The Specs Buyers Ask For — Published Honestly"
            subtitle="Where Gretna has not yet published a verified figure, the gap is flagged rather than filled with a guess."
          />
          <div className="overflow-hidden rounded-sm border border-line bg-white">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-brand-blue-light/60 text-[10.5px] uppercase tracking-[0.12em] text-brand-blue">
                  <th className="px-4 py-3 font-bold">Decision Item</th>
                  <th className="px-4 py-3 font-bold">Status</th>
                </tr>
              </thead>
              <tbody>
                {procurementGaps.map((g) => (
                  <tr key={g.label} className="border-t border-line/70 text-[13px]">
                    <td className="px-4 py-3 font-bold text-ink">{g.label}</td>
                    <td className="px-4 py-3 text-slate-body">{g.spec}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[12px] text-slate-500">
            Verified and available now: AS9100 Rev D / ISO 9001:2015, ITAR, HUBZone, WOSB, WBENC,
            SAM, DUNS 054633755, CAGE 0AXC7, 7 NAICS codes, full machine list and metrology inventory.
          </p>
        </Container>
      </section>

      <CtaBand
        title="Download the Capabilities Statement"
        body="One-page summary of facility, machine fleet, materials, certifications and identifiers — ready to forward to your sourcing team."
        primary={{ href: "/gretna-capabilities-statement.pdf", label: "Download PDF" }}
        secondary={{ href: "/request-a-quote", label: "Request a Quote" }}
      />

      <RelatedLinks
        title="Browse Capability Pages"
        links={[
          { label: "Precision CNC Machining", href: "/services/cnc-machining-houston-tx" },
          { label: "Materials Hub", href: "/materials" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Certifications", href: "/certifications" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
        ]}
      />
    </>
  );
}
