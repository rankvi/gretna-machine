import Link from "next/link";
import { Button, Container } from "@/components/ui";

export default function NotFound() {
  return (
    <section className="bg-paper py-20">
      <Container>
        <div className="mx-auto max-w-xl rounded-sm border border-line bg-white p-8 text-center">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-brand-red">404 • Page not found</p>
          <h1 className="mt-2 text-3xl font-extrabold text-ink">That page has been re-machined.</h1>
          <p className="mt-3 text-[13.5px] leading-relaxed text-slate-body">
            The old backup and duplicate URLs from the previous website now redirect to current,
            indexable capability pages. Use the links below to find what you need.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <Button href="/">Back to home</Button>
            <Button href="/request-a-quote" variant="outline">Request a Quote</Button>
          </div>
          <div className="mt-6 grid gap-2 text-left text-[13px] sm:grid-cols-2">
            {[
              { label: "Precision CNC Machining", href: "/services/cnc-machining-houston-tx" },
              { label: "Equipment List", href: "/equipment-list" },
              { label: "Materials", href: "/materials" },
              { label: "Certifications", href: "/certifications" },
              { label: "Case Studies", href: "/case-studies" },
              { label: "Contact", href: "/contact" },
            ].map((l) => (
              <Link key={l.href} href={l.href} className="rounded-sm border border-line px-3 py-2 font-semibold text-brand-blue hover:border-brand-red hover:text-brand-red">
                {l.label} →
              </Link>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
