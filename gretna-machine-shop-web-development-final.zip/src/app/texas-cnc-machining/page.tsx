import type { Metadata } from "next";
import Image from "next/image";
import { industries } from "@/lib/industries";
import { img } from "@/lib/images";
import { buildMetadata, faqJsonLd } from "@/lib/seo";
import { FaqList } from "@/components/faq";
import { Button, CheckList, Container, CtaBand, PageHero, SectionHeading, StatRow } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "Precision CNC Machining in Texas | Houston, DFW, Austin",
  description:
    "Texas precision CNC machining from Houston: 5-axis, large-bore turning and exotic alloys serving Houston, DFW, Austin, San Antonio, Corpus Christi and the Gulf Coast.",
  path: "/texas-cnc-machining",
});

const texasFaqs = [
  {
    q: "Do you serve customers outside Houston?",
    a: "Yes. We ship across Texas — Dallas-Fort Worth, Austin, San Antonio, Corpus Christi, Beaumont and the Gulf Coast — plus nationwide delivery from Houston.",
  },
  {
    q: "Can we visit the Houston facility before awarding a PO?",
    a: "Yes. Supplier audits and facility visits can be scheduled at 3450 Lang Rd., Houston, TX 77092. Contact our sales team to arrange a date.",
  },
  {
    q: "How do Texas customers receive parts?",
    a: "Houston-area pickup is available, and we ship nationally with protected packaging. [Client to Provide: Texas Shipping & Pickup Terms].",
  },
  {
    q: "Is Gretna in a HUBZone?",
    a: "Yes — the 3450 Lang Rd. Houston facility is SBA HUBZone certified, in addition to being a Woman-Owned Small Business.",
  },
  {
    q: "Which Texas industries do you support?",
    a: "Aerospace and defense procurement in DFW and Austin/San Antonio, oil and gas across the Gulf Coast, and geothermal and energy transition programs statewide.",
  },
  {
    q: "What if our plant is outside Texas?",
    a: "We support national programs from the same Houston shop — geography does not limit quoting, only shipping logistics.",
  },
];

const regions = [
  {
    city: "Houston & Gulf Coast",
    body: "Our home market. Same-day conversations, local pickup, and direct support for subsea, downhole, compression and refining equipment suppliers.",
    tags: ["Local pickup", "Energy corridor", "Subsea & downhole"],
  },
  {
    city: "Dallas–Fort Worth",
    body: "Aerospace and defense primes and Tier 1 suppliers needing AS9100D machining, FAIR support and ITAR-registered capacity.",
    tags: ["Aerospace", "Defense primes", "AS9100D"],
  },
  {
    city: "Austin & San Antonio",
    body: "Instrumentation, aerospace and defense programs requiring tight-tolerance 5-axis work and documented inspection data.",
    tags: ["5-axis", "Instrumentation", "ITAR"],
  },
  {
    city: "Corpus Christi & Beaumont",
    body: "Refining, petrochemical and energy-transition suppliers needing corrosion-resistant alloy components and quick-turn replacement parts.",
    tags: ["Chrome & duplex", "Turnaround", "Repair parts"],
  },
];

export default function TexasPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Texas CNC Machining", href: "/texas-cnc-machining" }]}
        eyebrow="Regional Landing • Texas Statewide"
        h1="Precision CNC Machining Across Texas — Houston, DFW, Austin & San Antonio"
        intro="One AS9100 Rev D and ITAR-registered shop in Houston, serving Texas aerospace, defense and energy buyers with 5-axis milling, long-bed turning and exotic alloy expertise."
        usps={[
          "Houston-based manufacturing with statewide and nationwide shipping",
          "Aerospace, defense and oil & gas program experience",
          "HUBZone, WOSB and minority-owned supplier credit for primes",
        ]}
        badges={["Houston, TX", "Serving All Texas", "AS9100D", "HUBZone", "WOSB"]}
        image={img.houston}
        imageAlt="Houston, Texas skyline — home of Gretna Machine Shop's precision CNC facility"
        secondary={{ href: "/contact", label: "Schedule a Facility Visit" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Regional Coverage"
            title="Texas Markets We Support"
            subtitle="The same shop, the same quality system and the same engineering review — regardless of where your plant sits."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            {regions.map((r) => (
              <div key={r.city} className="rounded-sm border border-line bg-white p-5">
                <h3 className="text-[16px] font-extrabold text-ink">{r.city}</h3>
                <p className="mt-1.5 text-[13px] leading-relaxed text-slate-body">{r.body}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {r.tags.map((t) => (
                    <span key={t} className="rounded-sm border border-brand-blue/15 bg-brand-blue-light/50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.08em] text-brand-blue">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <div className="grid items-center gap-8 lg:grid-cols-2">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Why a Texas Shop Matters"
                title="Local Accountability, National Capability"
                subtitle="When aerospace or energy production slips, distance costs days. Gretna is in your region — and the shop is the one that answers the phone."
              />
              <CheckList
                items={[
                  "Direct engineering contact in Central Houston, no broker chain",
                  "Texas pickup available; protected packaging with documented shipment",
                  "Machine capacity that handles 80\" milling and 120\" turning in-state",
                  "HUBZone and WOSB designations supporting Texas prime subcontracting goals",
                ]}
              />
              <div className="mt-5 flex flex-wrap gap-3">
                <Button href="/request-a-quote">Request a Texas RFQ</Button>
                <Button href="/equipment-list" variant="outline">
                  Equipment &amp; envelopes
                </Button>
              </div>
            </div>
            <div className="relative min-h-[280px] overflow-hidden rounded-sm border border-line">
              <Image
                src={img.facilityFloor}
                alt="Gretna Machine Shop Houston manufacturing floor supporting Texas CNC customers"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
          </div>
        </Container>
      </section>

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Industries" title="Texas Industries Served" subtitle="Dedicated pages for each market, with compliance and machine detail." />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {industries.map((i) => (
              <Button key={i.slug} href={`/industries/${i.slug}`} variant="outline">
                {i.navLabel}
              </Button>
            ))}
          </div>
          <div className="mt-8">
            <StatRow
              items={[
                { stat: "45+ yrs", label: "Operating in Houston" },
                { stat: "50,000 sq. ft.", label: "Air-conditioned facility" },
                { stat: "120\"", label: "Max turning length" },
                { stat: "7", label: "Federal NAICS codes" },
              ]}
            />
          </div>
        </Container>
      </section>

      <CtaBand
        title="Texas Buyer? Start With a Print."
        body="Upload CAD or PDF prints for engineering review. Include your plant location and required delivery date."
      />

      <section className="border-t border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="FAQ" title="Texas Coverage & Supplier Questions" subtitle="Straight answers for regional procurement teams." />
          <FaqList faqs={texasFaqs} columns={2} />
        </Container>
      </section>

      <RelatedLinks
        title="Explore the Shop"
        links={[
          { label: "About Gretna", href: "/about" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Aerospace Machining", href: "/industries/aerospace-cnc-machining" },
          { label: "Oil & Gas Machining", href: "/industries/oil-and-gas-machining-houston" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd(texasFaqs)) }}
      />
    </>
  );
}
