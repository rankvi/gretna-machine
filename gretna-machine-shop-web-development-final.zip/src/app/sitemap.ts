import type { MetadataRoute } from "next";
import { services } from "@/lib/services";
import { industries } from "@/lib/industries";
import { materials } from "@/lib/materials";
import { siteUrl } from "@/lib/seo";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const core: MetadataRoute.Sitemap = [
    { url: `${siteUrl}/`, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${siteUrl}/request-a-quote/`, lastModified: now, changeFrequency: "monthly", priority: 0.95 },
    { url: `${siteUrl}/equipment-list/`, lastModified: now, changeFrequency: "monthly", priority: 0.85 },
    { url: `${siteUrl}/quality-assurance-inspection/`, lastModified: now, changeFrequency: "monthly", priority: 0.85 },
    { url: `${siteUrl}/certifications/`, lastModified: now, changeFrequency: "monthly", priority: 0.85 },
    { url: `${siteUrl}/texas-cnc-machining/`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${siteUrl}/about/`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
    { url: `${siteUrl}/case-studies/`, lastModified: now, changeFrequency: "monthly", priority: 0.75 },
    { url: `${siteUrl}/materials/`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${siteUrl}/resources/`, lastModified: now, changeFrequency: "monthly", priority: 0.6 },
    { url: `${siteUrl}/contact/`, lastModified: now, changeFrequency: "yearly", priority: 0.7 },
    { url: `${siteUrl}/careers/`, lastModified: now, changeFrequency: "monthly", priority: 0.55 },
  ];

  const serviceUrls: MetadataRoute.Sitemap = services.map((s) => ({
    url: `${siteUrl}/services/${s.slug}/`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: s.pillar ? 0.95 : 0.9,
  }));

  const industryUrls: MetadataRoute.Sitemap = industries.map((i) => ({
    url: `${siteUrl}/industries/${i.slug}/`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.85,
  }));

  const materialUrls: MetadataRoute.Sitemap = materials.map((m) => ({
    url: `${siteUrl}/materials/${m.slug}/`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.8,
  }));

  return [...core, ...serviceUrls, ...industryUrls, ...materialUrls];
}
