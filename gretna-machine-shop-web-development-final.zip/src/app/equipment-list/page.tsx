import type { Metadata } from "next";
import Image from "next/image";
import { machineGroups, metrology } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata, breadcrumbJsonLd } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { AnchorBar, RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "Houston CNC Machine Shop Equipment List | Okuma & Doosan",
  description:
    "Gretna Machine Shop equipment list: Okuma MU5000V-L and M460V-5AX 5-axis, HAAS UMC-1000, Okuma Millac, Puma 480 XL 120\" lathe, DNX 2100SB mill-turn, ONA wire EDM.",
  path: "/equipment-list",
});

const images: Record<string, string> = {
  "5-axis": img.fiveAxis,
  "4-axis": img.milling,
  lathes: img.lathe,
  "mill-turn": img.cncCloseup,
  edm: img.edm,
  laser: img.laser,
};

export default function EquipmentListPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Equipment & Quality", href: "/equipment-list" }, { name: "Equipment List", href: "/equipment-list" }]}
        eyebrow="Equipment & Capacity • Houston, TX"
        h1="Houston CNC Machine Shop Equipment List"
        intro="Every platform below runs in our 50,000 sq. ft. air-conditioned Houston facility — with published travels, spindle speeds and load limits so engineers can verify fit before quoting."
        usps={[
          "12 CNC milling, turning and mill-turn platforms plus wire EDM and laser marking",
          "True 5-axis with dynamic work coordinate system (TCPC)",
          '25.5\"/41.4" 5-axis travels; 120" long-bed turning with 7.12" thru-bore',
        ]}
        badges={["Okuma", "Doosan", "HAAS", "ONA EDM", "Raycus Laser"]}
        image={img.fiveAxis}
        imageAlt="Okuma 5-axis CNC machining center at Gretna Machine Shop in Houston, TX"
        secondary={{ href: "/quality-assurance-inspection", label: "Inspection & Metrology" }}
      />

      <AnchorBar
        items={[
          ...machineGroups.map((g) => ({ label: g.short, href: `#${g.id}` })),
          { label: "Metrology", href: "#metrology" },
        ]}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Machine Fleet"
            title="The Equipment Behind the Tolerances"
            subtitle="Exact machine models and envelopes — no vague 'large capacity' claims."
          />
          <div className="space-y-10">
            {machineGroups.map((group) => (
              <div key={group.id} id={group.id} className="scroll-mt-40 overflow-hidden rounded-sm border border-line bg-white">
                <div className="grid lg:grid-cols-[0.38fr_0.62fr]">
                  <div className="relative min-h-[220px]">
                    <Image
                      src={images[group.id] ?? img.fiveAxis}
                      alt={`${group.label} at Gretna Machine Shop in Houston, TX`}
                      fill
                      sizes="(max-width: 1024px) 100vw, 38vw"
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/85 via-transparent to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-white/20" />
                    <p className="absolute inset-x-0 bottom-0 p-4 text-[12px] font-bold uppercase tracking-[0.12em] text-white lg:hidden">
                      {group.label}
                    </p>
                  </div>
                  <div className="p-5">
                    <h2 className="text-[19px] font-extrabold leading-tight text-ink">{group.label}</h2>
                    <p className="mt-1.5 text-[13px] leading-relaxed text-slate-body">{group.summary}</p>
                    <div className="mt-4 overflow-x-auto">
                      <table className="w-full min-w-[560px] border-collapse text-left">
                        <thead>
                          <tr className="bg-brand-blue-light/60 text-[10px] uppercase tracking-[0.12em] text-brand-blue">
                            <th className="px-3 py-2 font-bold">Model</th>
                            <th className="px-3 py-2 font-bold">Spindle / Control</th>
                            <th className="px-3 py-2 font-bold">Travels / Capacity</th>
                          </tr>
                        </thead>
                        <tbody>
                          {group.rows.map((row) => (
                            <tr key={row.model} className="border-t border-line/70 align-top text-[12.5px]">
                              <td className="px-3 py-2.5 font-bold text-ink">
                                {row.model}
                                {row.note && <span className="mt-0.5 block text-[11px] font-normal text-slate-500">{row.note}</span>}
                              </td>
                              <td className="px-3 py-2.5 text-slate-body">{row.spindle}</td>
                              <td className="px-3 py-2.5 text-slate-body">
                                {row.travels}
                                {row.capacity && <span className="mt-0.5 block text-[11px] text-slate-500">{row.capacity}</span>}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Total Machine Count &amp; Current Headcount]</ClientTag>
            <ClientTag>[Client to Provide: Standard &amp; Tightest Tolerances]</ClientTag>
          </div>
        </Container>
      </section>

      <section id="metrology" className="scroll-mt-40 border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Inspection & Metrology"
            title="Measurement Equipment In-House"
            subtitle="Dimensional results are generated against the model and retained in our quality management system."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {metrology.map((m) => (
              <div key={m.name} className="rounded-sm border border-line bg-white p-4">
                <p className="text-[13px] font-bold leading-snug text-ink">{m.name}</p>
                <p className="mt-1.5 text-[12px] leading-relaxed text-slate-500">{m.purpose}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/quality-assurance-inspection" variant="outline">
              Quality system detail
            </Button>
            <Button href="/request-a-quote">Request a Quote</Button>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Confirm Your Part Fits Our Envelope"
        body="Send the part envelope, material and quantity — our engineering team confirms machine fit before quoting."
        image={img.facilityFloor}
      />

      <RelatedLinks
        title="Next: Quality, Materials & Services"
        links={[
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Certifications", href: "/certifications" },
          { label: "Materials Hub", href: "/materials" },
          { label: "5-Axis CNC Machining", href: "/services/5-axis-cnc-machining" },
          { label: "CNC Turning", href: "/services/cnc-turning" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Equipment List", path: "/equipment-list" }])),
        }}
      />
    </>
  );
}
