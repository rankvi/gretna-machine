import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata } from "@/lib/seo";
import { Button, Container, CtaBand, PageHero, SectionHeading, StatRow } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "About Gretna Machine Shop | Women-Owned Houston Manufacturer",
  description:
    "Gretna Machine Shop is a 100% women-owned and minority-owned precision manufacturer in Houston, TX. Founded 1980, 50+ employees, 50,000 sq. ft. air-conditioned facility.",
  path: "/about",
});

export default function AboutPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "About", href: "/about" }]}
        eyebrow="About Gretna • Houston, TX since 1980"
        h1="A Houston Family Legacy in Precision Manufacturing"
        intro="Founded in 1980 by Jose Benjamin “Benny” Pérez and Ninfa G. Pérez, Gretna Machine Shop is a 100% women-owned and minority-owned manufacturer serving aerospace, defense and energy programs from a 50,000 sq. ft. Houston facility."
        usps={[
          "45+ years of continuous operation in Houston, Texas",
          "Women-owned, minority-owned, HUBZone and WOSB certified",
          "50+ employees with an in-house certified Professional Engineer",
        ]}
        badges={["Since 1980", "100% Women-Owned", "Minority-Owned", "HUBZone"]}
        image={img.team}
        imageAlt="Gretna Machine Shop team in the Houston manufacturing facility"
        secondary={{ href: "/careers", label: "Careers at Gretna" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <div className="grid items-start gap-8 lg:grid-cols-2 lg:gap-12">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand-red">Our Story</p>
              <h2 className="mt-2 text-3xl font-extrabold leading-tight text-ink">
                “If it can be imagined, it can be made” — backed by 45 years of execution
              </h2>
              <div className="mt-4 space-y-3.5 text-[14px] leading-relaxed text-slate-body">
                <p>
                  Gretna began as a Houston machine shop with a simple promise: take on the parts
                  other shops turn away. That promise grew into a 50,000 square foot,
                  air-conditioned lean manufacturing facility equipped with Okuma 5-axis machining
                  centers, Doosan turning and mill-turn platforms, ONA wire EDM and in-house laser
                  marking.
                </p>
                <p>
                  Our team of 50+ machinists, programmers, inspectors and engineers produces
                  secondary structure brackets and assembly parts for NASA&apos;s Orion project and
                  components for Boeing, Lockheed Martin, Honeywell and Oceaneering programs — along
                  with subsea, downhole and compression hardware for the Gulf Coast energy corridor.
                </p>
                <p>
                  We are proud to be 100% women-owned and minority-owned, a family business now led
                  by the next generation of the Pérez family alongside the founders.
                </p>
              </div>
              <div className="mt-5 flex flex-wrap gap-2 text-[11px] font-semibold uppercase tracking-[0.08em] text-brand-blue">
                {company.memberships.map((m) => (
                  <span key={m} className="rounded-sm border border-line bg-white px-2.5 py-1.5">
                    {m}
                  </span>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <div className="relative min-h-[260px] overflow-hidden rounded-sm border border-line">
                <Image src={img.facility} alt="Gretna Machine Shop 50,000 sq. ft. facility in Houston, TX" fill sizes="(max-width: 1024px) 100vw, 50vw" className="object-cover" />
                <div className="absolute inset-x-0 bottom-0 bg-brand-blue-dark/85 p-3">
                  <p className="text-[12px] font-semibold text-white">
                    3450 Lang Rd., Houston, TX 77092 — air-conditioned, HUBZone facility
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="relative min-h-[150px] overflow-hidden rounded-sm border border-line">
                  <Image src={img.millingWorker} alt="Machinist operating a CNC mill at Gretna" fill sizes="240px" className="object-cover" />
                </div>
                <div className="relative min-h-[150px] overflow-hidden rounded-sm border border-line">
                  <Image src={img.laser} alt="Raycus fiber laser part marking at Gretna Machine Shop" fill sizes="240px" className="object-cover" />
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Our Values" title="Five Values That Show Up on the Floor" subtitle="Posted on the wall, used in reviews, and measured every quarter." />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {company.values.map((v, i) => (
              <div key={v.name} className="rounded-sm border border-line bg-white p-4">
                <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-red">
                  0{i + 1}
                </p>
                <h3 className="mt-1 text-[14.5px] font-extrabold text-ink">{v.name}</h3>
                <p className="mt-1.5 text-[12px] leading-relaxed text-slate-body">{v.body}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Leadership" title="Executive Leadership" subtitle="A family legacy with hands-on operational leadership." />
          <div className="grid gap-4 sm:grid-cols-3">
            {company.leadership.map((l) => (
              <div key={l.name} className="rounded-sm border border-line bg-white p-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-blue-light text-[13px] font-black text-brand-blue">
                  {l.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <h3 className="mt-3 text-[15px] font-extrabold text-ink">{l.name}</h3>
                <p className="text-[12.5px] text-brand-red">{l.title}</p>
                <p className="mt-1 text-[11.5px] text-slate-500">{l.tenure} with Gretna</p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-center text-[12px] text-slate-500">
            Co-founders: {company.founder} • Sales contact: {company.salesContact.name},{" "}
            {company.salesContact.title}
          </p>
          <div className="mt-8">
            <StatRow
              items={[
                { stat: "1980", label: "Founded in Houston" },
                { stat: "50+", label: "Employees" },
                { stat: "50,000 sq. ft.", label: "Air-conditioned facility" },
                { stat: "100%", label: "Women & minority owned" },
              ]}
            />
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12">
        <Container>
          <SectionHeading eyebrow="Clients & Programs" title="Who We Build For" subtitle="Verified program experience — no logos used without permission." />
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {company.clients.map((c) => (
              <div key={c} className="flex min-h-[76px] items-center justify-center rounded-sm border border-line bg-white px-3 py-4 text-center text-[12.5px] font-bold uppercase tracking-[0.08em] text-slate-600">
                {c}
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/case-studies">Read case studies</Button>
            <Link href="/gretna-capabilities-statement.pdf" target="_blank" className="inline-flex items-center rounded-sm border border-brand-blue/40 px-5 py-3 text-[13px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:bg-brand-blue-light">
              Capabilities statement PDF
            </Link>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Work With a Houston Manufacturer That Owns the Hard Parts"
        body="Send prints for engineering review, or schedule a facility visit at 3450 Lang Rd., Houston, TX 77092."
        image={img.facilityFloor}
      />

      <RelatedLinks
        title="Learn More About Gretna"
        links={[
          { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
          { label: "Certifications", href: "/certifications" },
          { label: "Case Studies", href: "/case-studies" },
          { label: "Careers", href: "/careers" },
          { label: "Contact", href: "/contact" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />
    </>
  );
}
