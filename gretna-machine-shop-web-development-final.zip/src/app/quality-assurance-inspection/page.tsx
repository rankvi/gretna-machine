import type { Metadata } from "next";
import Image from "next/image";
import { metrology } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, ProcessCards, SectionHeading } from "@/components/ui";
import { AnchorBar, RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "AS9100 CMM Inspection & Quality Assurance | Houston TX",
  description:
    "AS9100 Rev D quality assurance in Houston, TX. Hexagon CMM, IMX Keyence, Gagemaker MIC trac, Mitutoyo PH35C and Tesa M900 metrology with documented inspection records.",
  path: "/quality-assurance-inspection",
});

export default function QualityPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[
          { name: "Equipment & Quality", href: "/equipment-list" },
          { name: "Quality & Inspection", href: "/quality-assurance-inspection" },
        ]}
        eyebrow="AS9100 Rev D • ITAR • Houston, TX"
        h1="Quality Assurance & CMM Inspection in Houston, TX"
        intro="An AS9100 Rev D quality management system backed by Hexagon CMM programming, Keyence vision measurement and thread metrology — with records that survive a supplier audit."
        usps={[
          "AS9100 Rev. D / ISO 9001:2015 registered quality system",
          "Hexagon CMM, IMX Keyence, Gagemaker MIC trac MT-3000 in-house",
          "Calibration control, nonconformance and corrective action in TQM",
        ]}
        badges={["AS9100 Rev D", "ISO 9001:2015", "CMM Inspection", "FAIR Support"]}
        image={img.caliper}
        imageAlt="Quality inspector measuring a machined part with a digital caliper at Gretna Machine Shop"
        secondary={{ href: "/certifications", label: "Certifications" }}
      />

      <AnchorBar
        items={[
          { label: "Metrology", href: "#metrology" },
          { label: "Inspection Flow", href: "#flow" },
          { label: "Documentation", href: "#documentation" },
          { label: "Supplier Audits", href: "#audits" },
        ]}
      />

      <section id="metrology" className="scroll-mt-40 py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Metrology"
            title="Measurement Equipment & Purpose"
            subtitle="The right instrument for each feature — optical, contact or thread-specific."
          />
          <div className="overflow-hidden rounded-sm border border-line bg-white">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-brand-blue-light/60 text-[10.5px] uppercase tracking-[0.12em] text-brand-blue">
                  <th className="px-4 py-3 font-bold">Equipment</th>
                  <th className="px-4 py-3 font-bold">Primary Use</th>
                </tr>
              </thead>
              <tbody>
                {metrology.map((m) => (
                  <tr key={m.name} className="border-t border-line/70 align-top text-[13px]">
                    <td className="px-4 py-3 font-bold text-ink">{m.name}</td>
                    <td className="px-4 py-3 text-slate-body">{m.purpose}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Calibration Interval &amp; Traceability Statement]</ClientTag>
            <ClientTag>[Client to Provide: Standard &amp; Tightest Tolerances]</ClientTag>
          </div>
        </Container>
      </section>

      <section id="flow" className="scroll-mt-40 border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Inspection Flow"
            title="How a Part Moves Through Quality"
            subtitle="Inspection is planned at the same time as the process — not bolted on at the end."
          />
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="relative min-h-[280px] overflow-hidden rounded-sm border border-line">
              <Image
                src={img.facility}
                alt="Gretna Machine Shop air-conditioned inspection and manufacturing floor in Houston"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 bg-brand-blue-dark/85 p-4">
                <p className="text-[12px] font-semibold text-white">
                  Climate-controlled inspection environment for stable measurement.
                </p>
              </div>
            </div>
            <div className="grid gap-3">
              {[
                { t: "1. Process planning", b: "The PE and programmers define critical features, datums and the inspection method before machining." },
                { t: "2. In-process checks", b: "Operators verify features against the print at defined intervals with calibrated hand tools and probing." },
                { t: "3. CMM layout", b: "The Hexagon CMM verifies GD&T and generates dimensional data for critical characteristics." },
                { t: "4. Final review & release", b: "Documentation is assembled, laser marking confirmed, and the part is packed to your specification." },
              ].map((s) => (
                <div key={s.t} className="rounded-sm border border-line bg-white p-4">
                  <p className="text-[13.5px] font-bold text-ink">{s.t}</p>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-slate-body">{s.b}</p>
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <section id="documentation" className="scroll-mt-40 py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Documentation"
            title="What Ships With Your Parts"
            subtitle="Documentation scope is confirmed at quote so there are no surprises at receiving."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { t: "Material Certifications", b: "Mill certifications retained against heat and lot number for traceability." },
              { t: "Inspection Reports", b: "Dimensional results for critical characteristics from CMM and hand tools." },
              { t: "Certificate of Conformance", b: "[Client to Provide: C of C Template & Signatory]" },
              { t: "First Article Inspection", b: "[Client to Provide: AS9102 FAIR Capability & Lead Time]" },
            ].map((d) => (
              <div key={d.t} className="rounded-sm border border-line bg-white p-4">
                <p className="text-[13px] font-bold text-ink">{d.t}</p>
                <p className="mt-1.5 text-[12px] leading-relaxed text-slate-500">{d.b}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Quality Documentation — AS9102 FAIR, MTRs, C of C, PPAP]</ClientTag>
            <ClientTag>[Client to Provide: Approved Outside Processing / Nadcap Partners]</ClientTag>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Auditing a New Houston Supplier?"
        body="We will share our certifications, scope, calibration approach and documentation samples before you release a PO."
        secondary={{ href: "/contact", label: "Contact Quality" }}
        image={img.measuringTools}
      />

      <section id="audits" className="scroll-mt-40 py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Supplier Onboarding" title="What Your Audit Will Cover" subtitle="Procurement-ready information, published instead of hidden." />
          <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="rounded-sm border border-line bg-white p-5">
              <h3 className="text-[15px] font-extrabold text-ink">Registrations & Identifiers</h3>
              <ul className="mt-3 space-y-2 text-[13px] text-slate-body">
                {[
                  "AS9100 Rev. D / AS9100:2016 and ISO 9001:2015 — Platinum Registration, Inc.",
                  "ITAR registered; UL-certified CNC machines; BBB A+ accredited",
                  "DUNS 054633755 • CAGE 0AXC7 • SAM registered",
                  "SBA HUBZone, SBA WOSB, WBENC certified, minority-owned business",
                  "NAICS 332510, 332710, 332721, 332912, 336411, 336413, 336419",
                ].map((li) => (
                  <li key={li} className="flex gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />
                    {li}
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button href="/certifications" variant="outline">
                  Certifications & codes
                </Button>
                <Button href="/equipment-list" variant="outline">
                  Equipment list
                </Button>
              </div>
            </div>
            <div className="rounded-sm border border-line bg-brand-blue-light/40 p-5">
              <h3 className="text-[15px] font-extrabold text-ink">Still Being Published</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-body">
                These metrics are intentionally flagged rather than invented:
              </p>
              <div className="mt-3 space-y-2">
                <ClientTag>[Client to Provide: OTD % &amp; Quality Acceptance Rate]</ClientTag>
                <ClientTag>[Client to Provide: Scrap / Rework Rates]</ClientTag>
                <ClientTag>[Client to Provide: Audit History &amp; Customer Scorecards]</ClientTag>
              </div>
            </div>
          </div>
          <div className="mt-10">
            <SectionHeading eyebrow="Process" title="RFQ to Delivered Part" />
            <ProcessCards />
          </div>
        </Container>
      </section>

      <RelatedLinks
        title="Quality-Adjacent Pages"
        links={[
          { label: "Certifications", href: "/certifications" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Materials Hub", href: "/materials" },
          { label: "Aerospace Machining", href: "/industries/aerospace-cnc-machining" },
          { label: "Defense & ITAR", href: "/industries/defense-itar-machining" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />
    </>
  );
}
