import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { industries } from "@/lib/industries";
import { caseStudies, homeFaqs } from "@/lib/site";
import { services } from "@/lib/services";
import { faqJsonLd, serviceJsonLd, siteUrl } from "@/lib/seo";
import {
  Button,
  CertStrip,
  CheckList,
  ClientTag,
  Container,
  CtaBand,
  ProcessCards,
  SectionHeading,
  StatRow,
} from "@/components/ui";
import { FaqList } from "@/components/faq";

export const metadata: Metadata = {
  title: "AS9100 & ITAR CNC Machine Shop Houston TX | Gretna Machine Shop",
  description:
    "Precision CNC machining in Houston, TX since 1980. AS9100 Rev D, ITAR, HUBZone and WOSB. True 5-axis milling, 120\" turning, Inconel and titanium. Request a quote.",
  alternates: { canonical: siteUrl + "/" },
};

const homeServices = services.filter((s) =>
  [
    "5-axis-cnc-machining",
    "cnc-milling",
    "cnc-turning",
    "multi-axis-mill-turn",
    "wire-edm-machining",
    "engineering-cad-cam-assembly",
  ].includes(s.slug),
);

export default function HomePage() {
  return (
    <>
      {/* 2. SPLIT-FADE HERO */}
      <section className="relative overflow-hidden border-b border-line bg-paper">
        <Container>
          <div className="grid items-center gap-9 py-10 lg:grid-cols-2 lg:gap-12 lg:py-14">
            <div>
              <p className="inline-flex flex-wrap items-center gap-x-2 gap-y-1 text-[10.5px] font-bold uppercase tracking-[0.16em] text-brand-red">
                <span>Houston, TX</span>
                <span className="text-slate-300">•</span>
                <span>AS9100 Rev D</span>
                <span className="text-slate-300">•</span>
                <span>ITAR</span>
                <span className="text-slate-300">•</span>
                <span>HUBZone</span>
                <span className="text-slate-300">•</span>
                <span>WOSB</span>
              </p>
              <h1 className="mt-4 text-[2.1rem] font-extrabold leading-[1.05] text-ink sm:text-[2.7rem] lg:text-[3.05rem]">
                Precision CNC Machining in Houston, TX —{" "}
                <span className="text-brand-red">From Subsea to Mars</span>
              </h1>
              <p className="mt-4 max-w-xl text-[15.5px] leading-relaxed text-slate-body">
                Gretna Machine Shop manufactures flight-hardware, subsea and defense components
                from Inconel, titanium and exotic alloys — with AS9100 Rev D documentation and an
                in-house certified Professional Engineer.
              </p>

              <div className="mt-6">
                <CheckList
                  items={[
                    'True 5-Axis Milling & 120" Long-Bed CNC Turning',
                    "Exotic Superalloys: Inconel, Titanium, MP35N & Hastelloy",
                    "50,000 sq. ft. Air-Conditioned Facility • In-House PE & Hexagon CMM",
                  ]}
                />
              </div>

              <div className="mt-7 flex flex-wrap gap-3">
                <Button href="/request-a-quote">Request a Quote</Button>
                <Button href="/gretna-capabilities-statement.pdf" variant="outline" target="_blank">
                  Capabilities Statement PDF
                </Button>
              </div>

              <p className="mt-4 text-[11.5px] font-semibold uppercase tracking-[0.1em] text-slate-500">
                <ClientTag>[Client to Provide: Quote Turnaround Time]</ClientTag>
                <span className="ml-2 align-middle">ITAR Compliant • CAGE {company.identifiers.cage}</span>
              </p>
            </div>

            <div className="relative">
              <div className="relative min-h-[300px] overflow-hidden rounded-sm border border-line shadow-2xl sm:min-h-[400px] lg:min-h-[460px]">
                <Image
                  src={img.heroShop}
                  alt="Gretna machinists setting up precision CNC work at the Houston, TX machine shop"
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 48vw"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-paper via-transparent to-transparent lg:from-paper/95 lg:via-paper/10" />
                <div className="absolute inset-x-0 bottom-0 border-t border-white/20 bg-brand-blue-dark/90 p-4 backdrop-blur">
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/55">
                    50,000 sq. ft. Air-Conditioned Facility
                  </p>
                  <p className="mt-1 text-[13px] font-semibold text-white">
                    True 5-axis • Mill-turn • Wire EDM • Laser marking • CMM inspection
                  </p>
                </div>
              </div>
              <div className="absolute right-3 top-3 rounded-sm bg-brand-red px-3 py-2 text-center text-white shadow-lg">
                <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-white/80">Since</p>
                <p className="text-lg font-black leading-none">1980</p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* Trust/credential marquee */}
      <div className="border-b border-line bg-white">
        <Container className="flex flex-wrap items-center justify-between gap-4 py-4">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-slate-400">
            Trusted by aerospace & energy programs
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            {company.clients.map((c) => (
              <span key={c} className="text-[12px] font-bold uppercase tracking-[0.08em] text-slate-500">
                {c}
              </span>
            ))}
          </div>
        </Container>
      </div>

      {/* 3. CORE SERVICES 3x2 */}
      <section className="py-14 lg:py-16" id="services">
        <Container>
          <SectionHeading
            eyebrow="Core Capabilities"
            title="One Houston Shop, Complete CNC Capability"
            subtitle="Every process below runs in-house under the same AS9100 Rev D quality system — no brokered work, no tolerance lost between suppliers."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {homeServices.map((s) => (
              <Link
                key={s.slug}
                href={`/services/${s.slug}`}
                className="group flex flex-col overflow-hidden rounded-sm border border-line bg-white transition-all hover:-translate-y-0.5 hover:border-brand-red/40 hover:shadow-lg"
              >
                <div className="relative h-44 overflow-hidden">
                  <Image
                    src={s.heroImage}
                    alt={`${s.name} at Gretna Machine Shop in Houston, TX`}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/80 via-brand-blue-dark/10 to-transparent" />
                  <p className="absolute inset-x-0 bottom-0 px-4 py-3 text-[13px] font-bold uppercase tracking-[0.08em] text-white">
                    {s.name}
                  </p>
                </div>
                <div className="flex flex-1 flex-col p-4">
                  <p className="text-[13px] leading-relaxed text-slate-body">{s.heroIntro.split(".")[0]}.</p>
                  <p className="mt-3 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.1em] text-brand-red">
                    {s.navLabel} capability
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="transition-transform group-hover:translate-x-1">
                      <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </p>
                </div>
              </Link>
            ))}
          </div>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-5 text-[12px] font-semibold text-slate-500">
            <span>Also in-house:</span>
            <Link href="/services/laser-engraving-part-marking" className="text-brand-blue underline decoration-brand-red/40 underline-offset-4 hover:text-brand-red">
              Laser marking & UID
            </Link>
            <Link href="/equipment-list" className="text-brand-blue underline decoration-brand-red/40 underline-offset-4 hover:text-brand-red">
              Full equipment list
            </Link>
            <Link href="/quality-assurance-inspection" className="text-brand-blue underline decoration-brand-red/40 underline-offset-4 hover:text-brand-red">
              Inspection & metrology
            </Link>
          </div>
        </Container>
      </section>

      {/* 4. FEATURED CASE STUDIES Z-PATTERN */}
      <section className="border-y border-line bg-paper py-14 lg:py-16" id="case-studies">
        <Container>
          <SectionHeading
            eyebrow="Proof of Capability"
            title="Programs We Have Machined"
            subtitle="Aerospace flight hardware, subsea superalloy components, and ITAR-controlled instrument housings — produced in Houston and documented for audit."
          />
          <div className="space-y-8">
            {caseStudies.slice(0, 2).map((cs, i) => (
              <div
                key={cs.slug}
                className={`grid items-center gap-6 rounded-sm border border-line bg-white p-4 lg:grid-cols-2 lg:gap-8 lg:p-6 ${
                  i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
                }`}
              >
                <div className="relative min-h-[240px] overflow-hidden rounded-sm lg:min-h-[280px]">
                  <Image
                    src={cs.image}
                    alt={`${cs.title} — ${cs.industry} machining at Gretna Machine Shop`}
                    fill
                    sizes="(max-width: 1024px) 100vw, 48vw"
                    className="object-cover"
                  />
                  <span className="absolute left-3 top-3 rounded-sm bg-brand-blue-dark/90 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white">
                    {cs.industry}
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-extrabold leading-tight text-ink">{cs.title}</h3>
                  <p className="mt-2 text-[14px] leading-relaxed text-slate-body">{cs.summary}</p>
                  <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-line bg-line">
                    {cs.specs.map((sp) => (
                      <div key={sp.label} className="bg-white px-3 py-2.5">
                        <dt className="text-[9.5px] font-bold uppercase tracking-[0.12em] text-slate-400">
                          {sp.label}
                        </dt>
                        <dd className="mt-0.5 text-[12px] font-semibold text-ink">{sp.value}</dd>
                      </div>
                    ))}
                  </dl>
                  <div className="mt-4">
                    <Button href="/case-studies" variant="outline">
                      All case studies
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">
              More anonymized part examples:
            </span>
            <ClientTag>[Client to Provide: 3-6 Real Part Case Studies with Dimensions &amp; Photos]</ClientTag>
          </div>
        </Container>
      </section>

      {/* 5. INDUSTRIES 2x2 */}
      <section className="py-14 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Industries Served"
            title="Built for Aerospace, Defense & Energy Procurement"
            subtitle="Each market has its own compliance, material and documentation requirements. We publish the specifics rather than burying them in a PDF."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            {industries.map((ind) => (
              <Link
                key={ind.slug}
                href={`/industries/${ind.slug}`}
                className="group flex items-start gap-4 rounded-sm border border-line bg-brand-blue-light/30 p-5 transition-colors hover:border-brand-blue/40 hover:bg-brand-blue-light/60"
              >
                <div className="relative hidden h-24 w-32 shrink-0 overflow-hidden rounded-sm sm:block">
                  <Image src={ind.heroImage} alt={`${ind.name} CNC machining`} fill sizes="128px" className="object-cover" />
                </div>
                <div>
                  <h3 className="text-[16px] font-extrabold text-ink group-hover:text-brand-blue">
                    {ind.name}
                  </h3>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-body">
                    {ind.heroIntro.split(".")[0]}.
                  </p>
                  <div className="mt-2.5 flex flex-wrap gap-1">
                    {ind.badges.slice(0, 3).map((b) => (
                      <span key={b} className="rounded-sm border border-brand-blue/15 bg-white px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-[0.08em] text-brand-blue">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      {/* 6. DUAL-PATH CONVERSION BREATHER */}
      <section className="relative overflow-hidden bg-brand-blue-dark">
        <div className="absolute inset-0 rule-grid opacity-40" aria-hidden="true" />
        <Container className="relative">
          <div className="grid items-center gap-8 py-12 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-[10.5px] font-bold uppercase tracking-[0.2em] text-white/55">
                Two ways to get started
              </p>
              <h2 className="mt-2 text-3xl font-extrabold leading-tight text-white">
                Send Prints, or Talk to an Engineer First
              </h2>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <Link
                  href="/request-a-quote"
                  className="group rounded-sm border border-white/20 bg-white/5 p-4 transition-colors hover:border-brand-red hover:bg-white/10"
                >
                  <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-red">
                    Path 01
                  </p>
                  <p className="mt-1 text-[15px] font-bold text-white">Submit Prints for a Quote</p>
                  <p className="mt-1 text-[12.5px] text-white/65">
                    Upload STEP/IGES/PDF, materials and quantities for engineering review.
                  </p>
                  <span className="mt-2 inline-flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-[0.08em] text-white/85 group-hover:text-white">
                    Open RFQ form →
                  </span>
                </Link>
                <Link
                  href="/contact"
                  className="group rounded-sm border border-white/20 bg-white/5 p-4 transition-colors hover:border-white/50 hover:bg-white/10"
                >
                  <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/50">
                    Path 02
                  </p>
                  <p className="mt-1 text-[15px] font-bold text-white">Speak With Our Team</p>
                  <p className="mt-1 text-[12.5px] text-white/65">
                    Call {company.phone} or reach Alex Barreneche, Director of Sales &amp; Marketing.
                  </p>
                  <span className="mt-2 inline-flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-[0.08em] text-white/85 group-hover:text-white">
                    Contact sales →
                  </span>
                </Link>
              </div>
            </div>
            <div className="relative min-h-[220px] overflow-hidden rounded-sm border border-white/20">
              <Image
                src={img.cadWoman}
                alt="Gretna engineer reviewing CAD geometry and RFQ drawings in Houston"
                fill
                sizes="(max-width: 1024px) 100vw, 44vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/90 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4">
                <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/60">
                  Engineering & sales support
                </p>
                <p className="mt-1 text-[13px] font-semibold text-white">
                  quotes@gretnamachine.com • {company.hours}
                </p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* 7. ABOUT + VIDEO STORY */}
      <section className="py-14 lg:py-16">
        <Container>
          <div className="grid items-center gap-8 lg:grid-cols-2 lg:gap-12">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand-red">
                About Gretna Machine Shop
              </p>
              <h2 className="mt-2 text-3xl font-extrabold leading-tight text-ink sm:text-[2.35rem]">
                A Houston Family Legacy Since 1980 — 100% Women- &amp; Minority-Owned
              </h2>
              <p className="mt-4 text-[14.5px] leading-relaxed text-slate-body">
                Founded by Jose Benjamin “Benny” Pérez and Ninfa G. Pérez, Gretna has grown from a
                machine shop into a 50,000 sq. ft. climate-controlled lean manufacturing facility in
                Houston&apos;s industrial corridor. Today an Okuma-centered shop of 50+ people
                produces components for NASA&apos;s Orion project, Boeing, Lockheed Martin,
                Honeywell and Oceaneering programs.
              </p>
              <ul className="mt-5 space-y-2.5">
                {[
                  "50,000 sq. ft. air-conditioned facility in Houston's HUBZone",
                  "CAD/CAM programmed by Class-A machinist supervisors",
                  "In-house certified Professional Engineer (PE) and Hexagon CMM metrology",
                  "ERP barcode tracking with real-time order visibility",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-[13.5px] text-slate-body">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button href="/about" variant="outline">
                  Our story &amp; leadership
                </Button>
                <Button href="/certifications" variant="outline">
                  Certifications
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="relative min-h-[300px] overflow-hidden rounded-sm border border-line lg:min-h-[360px]">
                <Image
                  src={img.team}
                  alt="Gretna Machine Shop leadership and machinists reviewing a production plan in Houston"
                  fill
                  sizes="(max-width: 1024px) 100vw, 48vw"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/70 to-transparent" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="flex h-16 w-16 items-center justify-center rounded-full border border-white/50 bg-brand-blue-dark/60 backdrop-blur transition-transform hover:scale-105">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="white" aria-hidden="true">
                      <path d="M8 5v14l11-7L8 5Z" />
                    </svg>
                  </span>
                </div>
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <p className="text-[13px] font-bold text-white">Inside the Houston shop</p>
                  <p className="text-[11px] text-white/70">
                    [Client to Provide: Shop Tour Video or Okuma Partnership Video URL]
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* 8. FULL-BLEED FACILITY BANNER */}
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src={img.facility}
            alt="Gretna Machine Shop 50,000 sq. ft. air-conditioned CNC manufacturing facility in Houston, TX"
            fill
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-brand-blue-dark/80" />
        </div>
        <Container className="relative py-16 text-center lg:py-20">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-white/60">
            Houston, Texas
          </p>
          <h2 className="mx-auto mt-3 max-w-3xl text-3xl font-extrabold leading-tight text-white sm:text-[2.5rem]">
            50,000 Sq. Ft. Climate-Controlled Precision Facility
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-[14.5px] leading-relaxed text-white/75">
            Air-conditioned machining environment for stable tolerances, lean material flow, ERP
            barcode tracking at every operation, and a dedicated inspection area with Hexagon CMM
            and Keyence metrology.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/equipment-list" variant="white">
              Explore equipment list
            </Button>
            <Button href="/request-a-quote" variant="ghost">
              Request a quote
            </Button>
          </div>
        </Container>
      </section>

      {/* 9. PROCESS */}
      <section className="py-14 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="RFQ to Delivery"
            title="A Documented Path From Print to Packed Part"
            subtitle="Four steps, one ERP record, and a named engineering contact — so procurement always knows where the job stands."
          />
          <ProcessCards />
          <div className="mt-8 flex justify-center">
            <Button href="/request-a-quote">Start Your RFQ</Button>
          </div>
        </Container>
      </section>

      {/* 10. KPIs + AUTHORITY */}
      <section className="border-y border-line bg-paper py-14 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Trust & Procurement Authority"
            title="The Numbers Procurement Teams Ask For"
            subtitle="Verified facility and ownership data — with open placeholders where Gretna's own KPIs still need to be published."
          />
          <StatRow
            items={[
              { stat: "45+ Years", label: "Operating since 1980", note: "Houston, TX" },
              { stat: "50,000 sq. ft.", label: "Air-conditioned facility", note: "Lean manufacturing" },
              { stat: "OTD %", label: "[Client to Provide]", note: "On-time delivery rate" },
              { stat: "100%", label: "Women & minority owned", note: "HUBZone • WOSB" },
            ]}
          />
          <div className="mt-8 grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="rounded-sm border border-line bg-white p-5">
              <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-slate-400">
                Registrations & Designations
              </p>
              <div className="mt-3">
                <CertStrip />
              </div>
              <p className="mt-3 text-[12px] leading-relaxed text-slate-500">
                DUNS {company.identifiers.duns} • CAGE {company.identifiers.cage} • SAM Registered •
                ITAR Registered • UL-certified CNC machines • BBB A+ accredited
              </p>
            </div>
            <div className="rounded-sm border border-line bg-white p-5">
              <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-slate-400">
                Federal NAICS Codes
              </p>
              <div className="mt-3 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
                {company.naics.map((n) => (
                  <p key={n.code} className="text-[12.5px] text-slate-body">
                    <span className="font-bold text-brand-blue">{n.code}</span> — {n.label}
                  </p>
                ))}
              </div>
              <p className="mt-3 text-[12px] text-slate-500">
                Client programs: NASA Orion, Boeing, Lockheed Martin, Honeywell, Oceaneering.
              </p>
            </div>
          </div>
        </Container>
      </section>

      {/* 11. FAQ */}
      <section className="border-b border-line py-14 lg:py-16">
        <Container>
          <div className="grid gap-9 lg:grid-cols-[0.32fr_0.68fr]">
            <div>
              <div className="relative mb-5 hidden min-h-[320px] overflow-hidden rounded-sm border border-line lg:block">
                <Image
                  src={img.caliper}
                  alt="Gretna quality inspector measuring a machined aerospace component with precision metrology equipment"
                  fill
                  sizes="32vw"
                  className="object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-brand-blue-dark/90 p-4">
                  <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-white/55">
                    Inspection first
                  </p>
                  <p className="mt-1 text-[13px] font-semibold text-white">
                    Hexagon CMM • Keyence IMX • Gagemaker • Tesa
                  </p>
                </div>
              </div>
              <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand-red">
                Buyer Questions
              </p>
              <h2 className="mt-2 text-3xl font-extrabold leading-tight text-ink">
                What Procurement Engineers Ask Us
              </h2>
              <p className="mt-3 text-[14px] leading-relaxed text-slate-body">
                Tolerances, ITAR handling, set-aside status, part envelopes and Texas shipping —
                answered here, not hidden behind a form.
              </p>
              <div className="mt-4">
                <Button href="/contact" variant="outline">
                  Ask a direct question
                </Button>
              </div>
            </div>
            <FaqList faqs={homeFaqs} />
          </div>
        </Container>
      </section>

      <CtaBand
        title="Ready to Quote Your Houston CNC Project?"
        body="Upload CAD and prints for engineering review, or call and speak with our sales team. Texas pickup available; domestic shipping nationwide."
        image={img.cncCloseup}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd(homeFaqs)) }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            homeServices.map((s) =>
              serviceJsonLd({
                name: s.name,
                description: s.metaDescription,
                path: `/services/${s.slug}`,
              }),
            ),
          ),
        }}
      />
    </>
  );
}
