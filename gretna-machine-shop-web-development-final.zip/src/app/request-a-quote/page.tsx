import type { Metadata } from "next";
import Link from "next/link";
import { company } from "@/lib/company";
import { buildMetadata } from "@/lib/seo";
import { RfqForm } from "@/components/rfq-form";
import { Button, CertStrip, CheckList, ClientTag, Container, SectionHeading } from "@/components/ui";

export const metadata: Metadata = buildMetadata({
  title: "Request a CNC Machining Quote | Houston, TX | Gretna",
  description:
    "Request a CNC machining quote from Gretna Machine Shop in Houston, TX. Upload STEP, IGES, SolidWorks or PDF prints, specify material and quantity, and reach our engineering team.",
  path: "/request-a-quote",
});

export default function RequestQuotePage() {
  return (
    <>
      <section className="border-b border-line bg-brand-blue-dark">
        <Container className="py-8 lg:py-10">
          <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-2 text-[11.5px] text-white/60">
            <Link href="/" className="hover:text-white">Home</Link>
            <span>/</span>
            <span className="font-semibold text-white">Request a Quote</span>
          </nav>
          <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr] lg:items-end">
            <div>
              <p className="inline-flex items-center gap-2 rounded-sm bg-white/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-white">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-red" />
                RFQ • Houston, TX • AS9100 Rev D • ITAR
              </p>
              <h1 className="mt-3 text-[2rem] font-extrabold leading-[1.08] text-white sm:text-[2.6rem]">
                Request a CNC Machining Quote
              </h1>
              <p className="mt-3 max-w-2xl text-[14.5px] leading-relaxed text-white/75">
                Upload CAD and prints for manufacturability review. Tell us the material, quantity
                and quality clauses — our engineering team returns pricing with process notes, not
                an automated estimate.
              </p>
            </div>
            <div className="grid gap-2 text-[12.5px] text-white/80">
              <a href={`tel:${company.phoneHref}`} className="font-bold text-white hover:text-brand-red">
                {company.phone}
              </a>
              <a href={`mailto:${company.emails.quotes}`} className="hover:text-white">
                {company.emails.quotes}
              </a>
              <p>{company.hours}</p>
              <p className="text-white/55">
                {company.address.full} • CAGE {company.identifiers.cage}
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="py-10 lg:py-14">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[0.65fr_0.35fr] lg:gap-10">
            <div>
              <div className="mb-5 flex flex-wrap items-center gap-2">
                <ClientTag>[Client to Provide: Accepted CAD Formats &amp; ITAR Secure Upload Details]</ClientTag>
                <ClientTag>[Client to Provide: Quote Turnaround Time]</ClientTag>
              </div>
              <RfqForm />
            </div>

            <aside className="space-y-4">
              <div className="lg:sticky lg:top-[120px] lg:space-y-4">
                <div className="rounded-sm border border-line bg-white p-5">
                  <h2 className="text-[15px] font-extrabold text-ink">What Happens Next?</h2>
                  <ol className="mt-3 space-y-3">
                    {[
                      { n: "01", t: "Engineering review", b: "A machinist-programmer and our PE review the print for process, fixturing and tolerance risk." },
                      { n: "02", t: "Quote & DFM notes", b: "You receive pricing, lead time and any manufacturability recommendations." },
                      { n: "03", t: "PO to packed part", b: "ERP-tracked machining, CMM inspection, marking and protected packaging." },
                    ].map((s) => (
                      <li key={s.n} className="flex gap-3">
                        <span className="text-[13px] font-black text-brand-red/40">{s.n}</span>
                        <span>
                          <span className="block text-[12.5px] font-bold text-ink">{s.t}</span>
                          <span className="block text-[11.5px] leading-relaxed text-slate-500">{s.b}</span>
                        </span>
                      </li>
                    ))}
                  </ol>
                </div>

                <div className="rounded-sm border border-brand-blue/20 bg-brand-blue-light/50 p-5">
                  <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">
                    Direct Contact
                  </h2>
                  <div className="mt-2 space-y-1.5 text-[12.5px] text-slate-body">
                    <p>
                      <span className="font-bold text-ink">Phone:</span>{" "}
                      <a href={`tel:${company.phoneHref}`} className="hover:text-brand-red">{company.phone}</a>
                    </p>
                    <p>
                      <span className="font-bold text-ink">Quotes:</span>{" "}
                      <a href={`mailto:${company.emails.quotes}`} className="hover:text-brand-red">{company.emails.quotes}</a>
                    </p>
                    <p>
                      <span className="font-bold text-ink">Sales:</span>{" "}
                      {company.salesContact.name}, {company.salesContact.title}
                    </p>
                    <p>
                      <span className="font-bold text-ink">CAGE:</span> {company.identifiers.cage} •{" "}
                      <span className="font-bold text-ink">DUNS:</span> {company.identifiers.duns}
                    </p>
                  </div>
                  <div className="mt-3">
                    <CertStrip />
                  </div>
                </div>

                <div className="rounded-sm border border-line bg-white p-5">
                  <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">
                    Procurement Assets
                  </h2>
                  <div className="mt-3 space-y-2">
                    <Button href="/gretna-capabilities-statement.pdf" variant="outline" target="_blank" className="w-full">
                      Capabilities Statement PDF
                    </Button>
                    <Button href="/equipment-list" variant="outline" className="w-full">
                      Equipment List
                    </Button>
                    <Button href="/certifications" variant="outline" className="w-full">
                      Certifications &amp; Codes
                    </Button>
                  </div>
                </div>

                <div className="rounded-sm border border-amber-500/50 bg-amber-50/70 p-4">
                  <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-amber-900">
                    ITAR / Controlled Data Notice
                  </p>
                  <p className="mt-1.5 text-[11.5px] leading-relaxed text-amber-900/80">
                    Gretna is ITAR registered. Do not upload classified information. If your data is
                    export-controlled, mark the RFQ accordingly and our team will confirm the secure
                    transfer method before you attach files.
                  </p>
                </div>

                <div className="rounded-sm border border-line bg-paper p-4">
                  <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-500">
                    Prefer talking first?
                  </p>
                  <div className="mt-2">
                    <CheckList
                      items={[
                        "Engineering-led quote review",
                        "Houston facility visits by appointment",
                        "Texas pickup and nationwide shipping",
                      ]}
                    />
                  </div>
                  <Link href="/contact" className="mt-3 inline-block text-[11.5px] font-bold uppercase tracking-[0.08em] text-brand-red hover:underline">
                    Contact the team →
                  </Link>
                </div>
              </div>
            </aside>
          </div>
        </Container>
      </section>

      <section className="border-t border-line bg-paper py-10">
        <Container>
          <SectionHeading
            eyebrow="Helpful Before You Submit"
            title="Include These Details for a Faster Quote"
            subtitle="The more complete the RFQ, the fewer rounds of questions before pricing."
          />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { t: "Revision-controlled prints", b: "Include the revision letter and a PDF plus 3D model where possible." },
              { t: "Material & condition", b: "Grade and heat-treat condition (e.g., 17-4 PH H1150) change cost and process." },
              { t: "Quantities", b: "First-article, prototype, production and annual usage help us price the right routing." },
              { t: "Quality clauses", b: "FAIR, MTRs, C of C, PPAP or ITAR handling — state them up front." },
            ].map((c) => (
              <div key={c.t} className="rounded-sm border border-line bg-white p-4">
                <p className="text-[13px] font-bold text-ink">{c.t}</p>
                <p className="mt-1 text-[12px] leading-relaxed text-slate-500">{c.b}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>
    </>
  );
}
