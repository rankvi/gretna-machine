import { NextResponse } from "next/server";
import { db } from "@/db";
import { rfqs } from "@/db/schema";

const ALLOWED_EXT = new Set([
  ".step",
  ".stp",
  ".iges",
  ".igs",
  ".sldprt",
  ".sldasm",
  ".dxf",
  ".dwg",
  ".pdf",
  ".zip",
]);
const MAX_FILES = 5;
const MAX_FILE_BYTES = 25 * 1024 * 1024;

function makeReference() {
  const stamp = Date.now().toString(36).toUpperCase().slice(-5);
  const rand = Math.random().toString(36).toUpperCase().slice(2, 5);
  return `GMS-${stamp}${rand}`;
}

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") ?? "";
    if (!contentType.includes("multipart/form-data") && !contentType.includes("application/json")) {
      return NextResponse.json({ ok: false, error: "Unsupported content type." }, { status: 415 });
    }

    let firstName = "";
    let lastName = "";
    let email = "";
    let phone = "";
    let company = "";
    let industry = "";
    let material = "";
    let quantity = "";
    let targetDelivery = "";
    let notes = "";
    let itarControlled = false;
    let serviceList: string[] = [];
    let qualityDocs: string[] = [];
    let fileNames: string[] = [];

    if (contentType.includes("multipart/form-data")) {
      const fd = await request.formData();
      const str = (k: string) => (fd.get(k)?.toString() ?? "").trim();
      firstName = str("firstName");
      lastName = str("lastName");
      email = str("email");
      phone = str("phone");
      company = str("company");
      industry = str("industry");
      material = str("material");
      quantity = str("quantity");
      targetDelivery = str("targetDelivery");
      notes = str("notes");
      itarControlled = fd.get("itarControlled") !== null;
      serviceList = fd.getAll("services").map((s) => s.toString()).filter(Boolean);
      qualityDocs = fd.getAll("qualityDocs").map((s) => s.toString()).filter(Boolean);

      const incoming = fd.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
      if (incoming.length > MAX_FILES) {
        return NextResponse.json(
          { ok: false, error: `Up to ${MAX_FILES} files may be attached. Please combine into a ZIP.` },
          { status: 400 },
        );
      }
      for (const file of incoming) {
        const ext = "." + (file.name.split(".").pop() ?? "").toLowerCase();
        if (!ALLOWED_EXT.has(ext)) {
          return NextResponse.json(
            { ok: false, error: `File type not accepted: ${file.name}. Use STEP, IGES, SolidWorks, DXF, DWG, PDF or ZIP.` },
            { status: 400 },
          );
        }
        if (file.size > MAX_FILE_BYTES) {
          return NextResponse.json(
            { ok: false, error: `${file.name} exceeds the 25 MB per-file limit.` },
            { status: 400 },
          );
        }
      }
      fileNames = incoming.map((f) => `${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB)`);
    } else {
      const body = (await request.json()) as Record<string, unknown>;
      firstName = String(body.firstName ?? "").trim();
      lastName = String(body.lastName ?? "").trim();
      email = String(body.email ?? "").trim();
      phone = String(body.phone ?? "").trim();
      company = String(body.company ?? "").trim();
      industry = String(body.industry ?? "").trim();
      material = String(body.material ?? "").trim();
      quantity = String(body.quantity ?? "").trim();
      targetDelivery = String(body.targetDelivery ?? "").trim();
      notes = String(body.notes ?? "").trim();
      itarControlled = Boolean(body.itarControlled);
      serviceList = Array.isArray(body.services) ? body.services.map(String) : [];
      qualityDocs = Array.isArray(body.qualityDocs) ? body.qualityDocs.map(String) : [];
      fileNames = Array.isArray(body.fileNames) ? body.fileNames.map(String) : [];
    }

    if (!firstName || !lastName || !company) {
      return NextResponse.json({ ok: false, error: "First name, last name and company are required." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return NextResponse.json({ ok: false, error: "Please provide a valid work email address." }, { status: 400 });
    }

    const reference = makeReference();
    await db.insert(rfqs).values({
      reference,
      firstName: firstName.slice(0, 120),
      lastName: lastName.slice(0, 120),
      email: email.slice(0, 200),
      phone: phone.slice(0, 60) || null,
      company: company.slice(0, 200),
      industry: industry.slice(0, 120) || null,
      services: serviceList,
      material: material.slice(0, 200) || null,
      quantity: quantity.slice(0, 120) || null,
      targetDelivery: targetDelivery.slice(0, 120) || null,
      qualityDocs,
      itarControlled,
      notes: notes || null,
      fileNames,
    });

    return NextResponse.json({ ok: true, reference });
  } catch (error) {
    console.error("RFQ submission failed", error);
    return NextResponse.json(
      { ok: false, error: "We could not save your RFQ. Please call 713-690-7328 or email quotes@gretnamachine.com." },
      { status: 500 },
    );
  }
}
