import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

const RESUME_EXT = new Set([".pdf", ".doc", ".docx"]);

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") ?? "";
    if (!contentType.includes("multipart/form-data") && !contentType.includes("application/json")) {
      return NextResponse.json({ ok: false, error: "Unsupported content type." }, { status: 415 });
    }

    let kind = "contact";
    let name = "";
    let email = "";
    let phone = "";
    let role = "";
    let subject = "";
    let message = "";
    let resumeName: string | null = null;

    if (contentType.includes("multipart/form-data")) {
      const fd = await request.formData();
      const str = (k: string) => (fd.get(k)?.toString() ?? "").trim();
      kind = str("kind") || "contact";
      name = str("name");
      email = str("email");
      phone = str("phone");
      role = str("role");
      subject = str("subject");
      message = str("message");
      const resume = fd.get("resume");
      if (resume instanceof File && resume.size > 0) {
        const ext = "." + (resume.name.split(".").pop() ?? "").toLowerCase();
        if (!RESUME_EXT.has(ext)) {
          return NextResponse.json({ ok: false, error: "Resume must be a PDF or DOCX file." }, { status: 400 });
        }
        if (resume.size > 10 * 1024 * 1024) {
          return NextResponse.json({ ok: false, error: "Resume must be 10 MB or smaller." }, { status: 400 });
        }
        resumeName = resume.name.slice(0, 240);
      }
    } else {
      const body = (await request.json()) as Record<string, unknown>;
      kind = String(body.kind ?? "contact");
      name = String(body.name ?? "").trim();
      email = String(body.email ?? "").trim();
      phone = String(body.phone ?? "").trim();
      role = String(body.role ?? "").trim();
      subject = String(body.subject ?? "").trim();
      message = String(body.message ?? "").trim();
    }

    if (!name || !message) {
      return NextResponse.json({ ok: false, error: "Name and message are required." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return NextResponse.json({ ok: false, error: "Please provide a valid email address." }, { status: 400 });
    }

    await db.insert(contactMessages).values({
      kind: kind.slice(0, 40),
      name: name.slice(0, 160),
      email: email.slice(0, 200),
      phone: phone.slice(0, 60) || null,
      role: role.slice(0, 120) || null,
      subject: subject.slice(0, 200) || null,
      message,
      resumeName,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Contact submission failed", error);
    return NextResponse.json(
      { ok: false, error: "We could not send your message. Please call 713-690-7328." },
      { status: 500 },
    );
  }
}
