import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { MaterialPage } from "@/components/material-page";
import { materialBySlug, materials } from "@/lib/materials";
import { buildMetadata } from "@/lib/seo";

export function generateStaticParams() {
  return materials.map((m) => ({ slug: m.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const material = materialBySlug(slug);
  if (!material) return { title: "Material Not Found | Gretna Machine Shop" };
  return buildMetadata({
    title: material.metaTitle,
    description: material.metaDescription,
    path: `/materials/${material.slug}`,
  });
}

export default async function MaterialRoute({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const material = materialBySlug(slug);
  if (!material) notFound();
  return <MaterialPage material={material} />;
}
