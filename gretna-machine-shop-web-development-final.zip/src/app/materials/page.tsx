import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { img } from "@/lib/images";
import { materials } from "@/lib/materials";
import { buildMetadata } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "Metals & Exotic Alloy CNC Machining Materials | Texas",
  description:
    "Materials machined by Gretna Machine Shop in Houston, TX: Inconel, Monel, Hastelloy, Waspaloy, MP35N, titanium, 17-4 PH, 13% chrome, 4140, 7075 aluminum, PEEK and more.",
  path: "/materials",
});

export default function MaterialsHubPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Materials", href: "/materials" }]}
        eyebrow="Material Capability • Houston, TX"
        h1="Exotic Alloy & Metal CNC Machining Materials"
        intro="From Inconel 718 and MP35N to 13% chrome, 4140 and PEEK — compare grades, machining behavior and the equipment we use for each family."
        usps={[
          "Nickel superalloys, titanium, stainless, chrome and alloy steel",
          "Large-bore turning, 5-axis milling, mill-turn and wire EDM support",
          "Mill-certified material sourcing and documented traceability",
        ]}
        badges={["Inconel", "Titanium", "13% Chrome", "MP35N", "PEEK"]}
        image={img.metalBars}
        imageAlt="Certified alloy bar stock for CNC machining at Gretna Machine Shop"
        secondary={{ href: "/equipment-list", label: "Equipment List" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Material Guides"
            title="Choose a Material Family"
            subtitle="Each guide lists the exact grades we machine, the DFM considerations, and the machines best suited to that alloy."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            {materials.map((m) => (
              <Link
                key={m.slug}
                href={`/materials/${m.slug}`}
                className="group overflow-hidden rounded-sm border border-line bg-white transition-all hover:-translate-y-0.5 hover:border-brand-red/40 hover:shadow-lg"
              >
                <div className="relative h-40">
                  <Image src={m.heroImage} alt={`${m.name} machining`} fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/85 to-transparent" />
                  <p className="absolute inset-x-0 bottom-0 p-4 text-[15px] font-extrabold text-white">{m.name}</p>
                </div>
                <div className="p-4">
                  <p className="text-[12.5px] leading-relaxed text-slate-body">{m.heroIntro.split(".")[0]}.</p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {m.badges.slice(0, 4).map((b) => (
                      <span key={b} className="rounded-sm border border-brand-blue/15 px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-[0.08em] text-brand-blue">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12">
        <Container>
          <SectionHeading
            eyebrow="Full Grade List"
            title="Every Material Family We Machine"
            subtitle="If the specification is not listed, send it — capability is confirmed before a quote is issued."
          />
          <div className="overflow-hidden rounded-sm border border-line bg-white">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-brand-blue-light/60 text-[10.5px] uppercase tracking-[0.12em] text-brand-blue">
                  <th className="px-4 py-3 font-bold">Family</th>
                  <th className="px-4 py-3 font-bold">Grades</th>
                  <th className="px-4 py-3 font-bold">Guide</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { f: "Nickel & high-temp superalloys", g: "Inconel 625, 718, 925; Monel K-500; Hastelloy; Waspaloy; MP35N", s: "inconel-superalloy-machining" },
                  { f: "Titanium & corrosion-resistant steel", g: "Titanium; 13-8, 17-4 PH, 300 series, 410, 420 mod; 22%/13%/Super 13%/9% chrome; S410 duplex", s: "titanium-stainless-steel-machining" },
                  { f: "Carbon & alloy steel", g: "4130, 4140–4145, 4340, 1018–1026, 8620, castings, forgings, casing, cast iron", s: "aluminum-alloy-steel-machining" },
                  { f: "Non-ferrous", g: "Aluminum 2011, 2024, 6061, 7075; brass; bronze; copper alloys", s: "aluminum-alloy-steel-machining" },
                  { f: "Engineering plastics", g: "PEEK, Delrin, Acetal, HDPE", s: "engineering-plastics-machining" },
                ].map((row) => (
                  <tr key={row.f} className="border-t border-line/70 text-[13px]">
                    <td className="px-4 py-3 font-bold text-ink">{row.f}</td>
                    <td className="px-4 py-3 text-slate-body">{row.g}</td>
                    <td className="px-4 py-3">
                      <Link href={`/materials/${row.s}`} className="text-[12px] font-bold uppercase tracking-[0.06em] text-brand-red hover:underline">
                        View guide →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Material Sourcing &amp; Certification Policy]</ClientTag>
            <ClientTag>[Client to Provide: Approved Outside Processing / Nadcap Partners]</ClientTag>
          </div>
          <div className="mt-6 flex justify-center">
            <Button href="/request-a-quote">Request a Material Quote</Button>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Not Sure Which Alloy Fits?"
        body="Send the functional requirements — corrosion, temperature, strength or weight — and our engineering team will review the machining implications with you."
        image={img.metalStock}
      />

      <RelatedLinks
        title="Materials, Meet Process"
        intro="Every material page connects to the machining process best suited to it."
        links={[
          { label: "5-Axis CNC Machining", href: "/services/5-axis-cnc-machining" },
          { label: "CNC Turning", href: "/services/cnc-turning" },
          { label: "Wire EDM Machining", href: "/services/wire-edm-machining" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />
    </>
  );
}
