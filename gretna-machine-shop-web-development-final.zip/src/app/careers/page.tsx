import type { Metadata } from "next";
import Image from "next/image";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata } from "@/lib/seo";
import { CareerForm } from "@/components/lead-forms";
import { ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "CNC Machinist Jobs in Houston, TX | Gretna Machine Shop",
  description:
    "CNC machinist, programmer and quality inspector careers at Gretna Machine Shop in Houston, TX. Okuma and Doosan equipment, air-conditioned shop, AS9100 aerospace work.",
  path: "/careers",
});

const roles = [
  {
    title: "CNC Machinist — Mills",
    type: "Full-time • Houston, TX",
    body: "Set up and run Okuma and Doosan vertical/horizontal mills on aerospace and energy part families. Experience with Inconel, titanium and stainless preferred.",
  },
  {
    title: "CNC Machinist — Lathes / Mill-Turn",
    type: "Full-time • Houston, TX",
    body: "Operate large-bore turning and dual-spindle mill-turn equipment. Steady-rest and long-part experience is a strong plus.",
  },
  {
    title: "CNC Programmer (CAD/CAM)",
    type: "Full-time • Houston, TX",
    body: "Program 5-axis and mill-turn work, design fixtures, and support first-article prove-outs alongside our in-house PE.",
  },
  {
    title: "Quality Inspector (CMM)",
    type: "Full-time • Houston, TX",
    body: "Program and operate Hexagon CMM, perform in-process inspections, and assemble AS9100 documentation packages.",
  },
];

export default function CareersPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Careers", href: "/careers" }]}
        eyebrow="Careers • Houston, TX"
        h1="CNC Machinist & Manufacturing Careers in Houston"
        intro="Join a 45-year Houston manufacturer that runs modern Okuma, Doosan and HAAS equipment in an air-conditioned shop — with real aerospace and energy work on the floor."
        usps={[
          "Air-conditioned 50,000 sq. ft. facility in Houston, TX",
          "Okuma, Doosan, HAAS, ONA EDM and Raycus laser equipment",
          "Training, cross-training and long-term career paths",
        ]}
        badges={["Houston, TX", "Full-Time", "Okuma & Doosan", "Family-Owned"]}
        image={img.millingWorker}
        imageAlt="CNC machinist working at Gretna Machine Shop in Houston, Texas"
        primary={{ href: "#apply", label: "Apply Now" }}
        secondary={{ href: "#roles", label: "Open Roles" }}
        microTrust="Email resumes to Hr@gretnamachine.com"
      />

      <section id="roles" className="scroll-mt-32 py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Open Positions"
            title="Build Precision Parts With Us"
            subtitle="Roles below are representative of our hiring needs. If your skills are adjacent, apply anyway — we train the right people."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            {roles.map((r) => (
              <div key={r.title} className="rounded-sm border border-line bg-white p-5">
                <h3 className="text-[15.5px] font-extrabold text-ink">{r.title}</h3>
                <p className="mt-0.5 text-[11px] font-bold uppercase tracking-[0.1em] text-brand-red">{r.type}</p>
                <p className="mt-2 text-[12.5px] leading-relaxed text-slate-body">{r.body}</p>
                <a href="#apply" className="mt-3 inline-block text-[11.5px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:text-brand-red">
                  Apply for this role →
                </a>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Current Openings, Shift Schedules &amp; Pay Ranges]</ClientTag>
            <ClientTag>[Client to Provide: Benefits Summary]</ClientTag>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <div className="grid items-center gap-8 lg:grid-cols-2">
            <div className="relative min-h-[280px] overflow-hidden rounded-sm border border-line">
              <Image src={img.workerWoman} alt="Gretna Machine Shop machinist in the Houston facility" fill sizes="(max-width: 1024px) 100vw, 50vw" className="object-cover" />
            </div>
            <div>
              <SectionHeading
                align="left"
                eyebrow="Working at Gretna"
                title="Mindful Manufacturing, Real Craftsmanship"
                subtitle="Our five values — Love It, Be Helpful, Be Lean, Grow Gray Matter, Raise The Bar — describe how the shop actually runs."
              />
              <ul className="space-y-2 text-[13.5px] text-slate-body">
                {[
                  "Climate-controlled shop that protects both parts and people",
                  "Aerospace, defense and energy work with genuine technical challenge",
                  "In-house engineering and inspection support on the floor",
                  "Family-owned, women- and minority-owned culture since 1980",
                  "Houston location with convenient access to the Lang Road industrial corridor",
                ].map((i) => (
                  <li key={i} className="flex gap-2.5">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Container>
      </section>

      <section id="apply" className="scroll-mt-32 py-12 lg:py-16">
        <Container>
          <div className="grid gap-8 lg:grid-cols-[0.6fr_0.4fr] lg:gap-10">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Apply"
                title="Submit Your Application"
                subtitle="Send your experience summary and resume. Our HR team reviews every application."
              />
              <CareerForm />
            </div>
            <div className="space-y-4">
              <div className="rounded-sm border border-line bg-white p-5">
                <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">Apply Directly</h2>
                <p className="mt-2 text-[12.5px] leading-relaxed text-slate-body">
                  Email your resume to{" "}
                  <a href={`mailto:${company.emails.hr}`} className="font-bold text-brand-red hover:underline">
                    {company.emails.hr}
                  </a>{" "}
                  or call{" "}
                  <a href={`tel:${company.phoneHref}`} className="font-bold text-brand-red hover:underline">
                    {company.phone}
                  </a>
                  .
                </p>
                <p className="mt-2 text-[12px] text-slate-500">
                  {company.address.full}
                  <br />
                  {company.hours}
                </p>
              </div>
              <div className="rounded-sm border border-line bg-brand-blue-light/50 p-5">
                <h2 className="text-[13px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">Equal Opportunity</h2>
                <p className="mt-2 text-[12px] leading-relaxed text-slate-body">
                  Gretna Machine Shop is a 100% women-owned, minority-owned business and an equal
                  opportunity employer. All qualified applicants are considered without regard to
                  race, color, religion, sex, national origin, disability or veteran status.
                </p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Not Applying — But Need Parts?"
        body="Send your prints to our engineering team for a manufacturing review and quote."
        secondary={{ href: "/about", label: "About Gretna" }}
        image={img.millingWorker}
      />

      <RelatedLinks
        title="Explore Gretna"
        links={[
          { label: "About Gretna", href: "/about" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Contact", href: "/contact" },
          { label: "Request a Quote", href: "/request-a-quote" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
        ]}
      />
    </>
  );
}
