import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { organizationJsonLd, siteUrl, websiteJsonLd } from "@/lib/seo";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "AS9100 & ITAR CNC Machine Shop Houston TX | Gretna Machine Shop",
    template: "%s",
  },
  description:
    "Gretna Machine Shop is an AS9100 Rev D and ITAR registered precision CNC machine shop in Houston, TX. True 5-axis machining, 120\" turning, Inconel and titanium, HUBZone and WOSB certified.",
  applicationName: "Gretna Machine Shop, Inc.",
  authors: [{ name: company.name }],
  keywords: [
    "CNC machine shop Houston TX",
    "AS9100 machining Houston",
    "ITAR machine shop Texas",
    "5-axis CNC machining Houston",
    "Inconel machining Texas",
    "oil and gas CNC machining Houston",
    "HUBZone machine shop",
    "WOSB manufacturer Texas",
  ],
  robots: { index: true, follow: true },
  icons: [{ rel: "icon", url: "/icon.svg", type: "image/svg+xml" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: company.name,
    title: "AS9100 & ITAR CNC Machine Shop Houston TX | Gretna Machine Shop",
    description:
      "True 5-axis CNC machining, 120\" turning, Inconel and titanium capability from a 50,000 sq. ft. AS9100 Rev D, ITAR, HUBZone and WOSB facility in Houston, TX.",
    url: siteUrl,
    images: [
      {
        url: img.facility,
        width: 1200,
        height: 630,
        alt: "Gretna Machine Shop 50,000 sq. ft. CNC manufacturing facility in Houston, TX",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "AS9100 & ITAR CNC Machine Shop Houston TX | Gretna Machine Shop",
    description:
      "Precision 5-axis CNC machining, large-bore turning and exotic alloys from Houston, TX. AS9100 Rev D, ITAR, HUBZone, WOSB.",
    images: [img.facility],
  },
};

export const viewport: Viewport = {
  themeColor: "#16496b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-white text-ink antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-[100] focus:rounded-sm focus:bg-brand-red focus:px-4 focus:py-2 focus:text-white"
        >
          Skip to content
        </a>
        <SiteHeader />
        <main id="main">{children}</main>
        <SiteFooter />
        <script
          type="application/ld+json"
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
        />
        <script
          type="application/ld+json"
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
      </body>
    </html>
  );
}
