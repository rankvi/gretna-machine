import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { contactMessages, rfqs } from "@/db/schema";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "RFQ Inbox | Gretna Machine Shop (Internal)",
  robots: { index: false, follow: false },
};

const statuses = ["new", "reviewing", "quoted", "won", "closed"];

async function setStatus(formData: FormData) {
  "use server";
  const id = Number(formData.get("id"));
  const status = String(formData.get("status") ?? "new");
  if (!Number.isFinite(id) || !statuses.includes(status)) return;
  await db.update(rfqs).set({ status }).where(eq(rfqs.id, id));
  revalidatePath("/admin/rfqs");
}

export default async function RfqInboxPage() {
  let quoteRequests: (typeof rfqs.$inferSelect)[] = [];
  let messages: (typeof contactMessages.$inferSelect)[] = [];
  let dbError: string | null = null;

  try {
    quoteRequests = await db.select().from(rfqs).orderBy(desc(rfqs.createdAt)).limit(50);
    messages = await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)).limit(25);
  } catch (error) {
    dbError = error instanceof Error ? error.message : "Unknown database error";
  }

  const newCount = quoteRequests.filter((r) => r.status === "new").length;

  return (
    <div className="bg-paper">
      <div className="container-x py-10">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-5">
          <div>
            <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-brand-red">
              Internal • Sales &amp; Engineering
            </p>
            <h1 className="mt-1 text-3xl font-extrabold text-ink">RFQ Inbox</h1>
            <p className="mt-1 text-[12.5px] text-slate-body">
              Submissions captured by the website RFQ workflow and contact forms.
            </p>
          </div>
          <div className="text-right">
            <p className="text-[28px] font-black leading-none text-brand-blue">{quoteRequests.length}</p>
            <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-500">
              total RFQs • {newCount} new
            </p>
          </div>
        </div>

        {dbError && (
          <p className="mt-5 rounded-sm border border-brand-red/30 bg-brand-red/5 px-4 py-3 text-[12.5px] font-semibold text-brand-red">
            Database unavailable: {dbError}
          </p>
        )}

        <section className="mt-6">
          <h2 className="text-[15px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">
            Quote Requests
          </h2>
          {quoteRequests.length === 0 && !dbError && (
            <p className="mt-3 rounded-sm border border-line bg-white px-4 py-5 text-[13px] text-slate-body">
              No RFQs yet. Submit one from the public{" "}
              <a href="/request-a-quote" className="font-bold text-brand-red">Request a Quote</a> page to
              see it appear here.
            </p>
          )}
          <div className="mt-3 space-y-3">
            {quoteRequests.map((r) => (
              <article key={r.id} className="rounded-sm border border-line bg-white p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-sm bg-brand-blue-dark px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-white">
                        {r.reference}
                      </span>
                      {r.itarControlled && (
                        <span className="rounded-sm bg-amber-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-amber-900">
                          ITAR Controlled
                        </span>
                      )}
                      <span className="rounded-sm border border-line px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-slate-500">
                        {r.status}
                      </span>
                    </div>
                    <p className="mt-2 text-[14px] font-extrabold text-ink">
                      {r.company} — {r.firstName} {r.lastName}
                    </p>
                    <p className="text-[12px] text-slate-body">
                      <a href={`mailto:${r.email}`} className="hover:text-brand-red">{r.email}</a>
                      {r.phone ? ` • ${r.phone}` : ""} {r.industry ? `• ${r.industry}` : ""}
                    </p>
                  </div>
                  <form action={setStatus} className="flex items-center gap-2">
                    <input type="hidden" name="id" value={r.id} />
                    <select
                      name="status"
                      defaultValue={r.status}
                      className="rounded-sm border border-line bg-white px-2 py-1.5 text-[11.5px] font-semibold text-ink"
                    >
                      {statuses.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    <button
                      type="submit"
                      className="rounded-sm bg-brand-red px-2.5 py-1.5 text-[10.5px] font-bold uppercase tracking-[0.08em] text-white hover:bg-brand-red-dark"
                    >
                      Update
                    </button>
                  </form>
                </div>
                <dl className="mt-3 grid gap-2 border-t border-line pt-3 text-[12px] sm:grid-cols-2 lg:grid-cols-4">
                  <div>
                    <dt className="text-[9.5px] font-bold uppercase tracking-[0.1em] text-slate-400">Services</dt>
                    <dd className="text-slate-body">{r.services.length ? r.services.join(", ") : "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-[9.5px] font-bold uppercase tracking-[0.1em] text-slate-400">Material / Qty</dt>
                    <dd className="text-slate-body">
                      {r.material ?? "—"} {r.quantity ? `• ${r.quantity}` : ""}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[9.5px] font-bold uppercase tracking-[0.1em] text-slate-400">Target / Docs</dt>
                    <dd className="text-slate-body">
                      {r.targetDelivery ?? "—"} {r.qualityDocs.length ? `• ${r.qualityDocs.join(", ")}` : ""}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[9.5px] font-bold uppercase tracking-[0.1em] text-slate-400">Files</dt>
                    <dd className="break-words text-slate-body">{r.fileNames.length ? r.fileNames.join(", ") : "—"}</dd>
                  </div>
                </dl>
                {r.notes && (
                  <p className="mt-2 rounded-sm bg-paper px-3 py-2 text-[12px] leading-relaxed text-slate-body">
                    {r.notes}
                  </p>
                )}
                <p className="mt-2 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-slate-400">
                  Received {new Date(r.createdAt).toLocaleString("en-US", { timeZone: "America/Chicago" })} CST
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="mt-10">
          <h2 className="text-[15px] font-extrabold uppercase tracking-[0.08em] text-brand-blue">
            Contact &amp; Careers Messages
          </h2>
          {messages.length === 0 && !dbError && (
            <p className="mt-3 rounded-sm border border-line bg-white px-4 py-5 text-[13px] text-slate-body">
              No messages yet.
            </p>
          )}
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            {messages.map((m) => (
              <article key={m.id} className="rounded-sm border border-line bg-white p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[13px] font-bold text-ink">{m.name}</p>
                  <span className="rounded-sm border border-line px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-slate-500">
                    {m.kind}
                  </span>
                </div>
                <p className="text-[11.5px] text-slate-body">
                  <a href={`mailto:${m.email}`} className="hover:text-brand-red">{m.email}</a>
                  {m.phone ? ` • ${m.phone}` : ""}
                </p>
                {m.role && <p className="text-[11.5px] text-slate-500">{m.role}</p>}
                {m.subject && <p className="mt-1 text-[11.5px] font-semibold text-brand-blue">{m.subject}</p>}
                <p className="mt-2 text-[12px] leading-relaxed text-slate-body">{m.message}</p>
                {m.resumeName && (
                  <p className="mt-2 text-[11px] text-slate-500">Resume attached: {m.resumeName}</p>
                )}
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
