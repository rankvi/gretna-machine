import type { Metadata } from "next";
import Image from "next/image";
import { company } from "@/lib/company";
import { img } from "@/lib/images";
import { buildMetadata } from "@/lib/seo";
import { Button, ClientTag, Container, CtaBand, PageHero, SectionHeading } from "@/components/ui";
import { RelatedLinks } from "@/components/blocks";

export const metadata: Metadata = buildMetadata({
  title: "AS9100 Rev D, ITAR, HUBZone & WOSB Certifications | Texas",
  description:
    "Gretna Machine Shop certifications: AS9100 Rev D, ISO 9001:2015, ITAR registered, SBA HUBZone, SBA WOSB, WBENC, minority-owned, SAM registered, DUNS 054633755, CAGE 0AXC7.",
  path: "/certifications",
});

export default function CertificationsPage() {
  return (
    <>
      <PageHero
        breadcrumbs={[{ name: "Certifications", href: "/certifications" }]}
        eyebrow="Compliance • Houston, TX"
        h1="Certifications, Federal Codes & Procurement Designations"
        intro="Everything a supplier-onboarding team needs to verify Gretna Machine Shop: quality registrations, defense registrations, socioeconomic designations, DUNS, CAGE and NAICS codes."
        usps={[
          "AS9100 Rev. D and ISO 9001:2015 registered (Platinum Registration, Inc.)",
          "ITAR registered, SAM registered, UL-certified CNC machines, BBB A+ accredited",
          "SBA HUBZone, SBA WOSB, WBENC certified, minority-owned business",
        ]}
        badges={["AS9100D", "ITAR", "HUBZone", "WOSB", "WBENC", "SAM"]}
        image={img.controlRoom}
        imageAlt="Gretna Machine Shop quality and compliance team in Houston, Texas"
        secondary={{ href: "/quality-assurance-inspection", label: "Inspection & Quality" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Quality & Defense"
            title="Registrations on File"
            subtitle="Certificates are available on request during supplier onboarding."
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {company.certifications.map((c) => (
              <div key={c.name} className="rounded-sm border border-line bg-white p-5">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-sm bg-brand-blue text-white">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <path d="M12 3l7 3v5c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-3Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
                      <path d="m8.5 12 2.5 2.5L16 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  <div>
                    <h3 className="text-[14.5px] font-extrabold text-ink">{c.name}</h3>
                    <p className="mt-1 text-[12.5px] leading-relaxed text-slate-body">{c.detail}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-sm border border-line bg-white p-5">
              <h2 className="text-[17px] font-extrabold text-ink">Federal Identifiers</h2>
              <dl className="mt-3 divide-y divide-line">
                {[
                  { k: "DUNS Number", v: company.identifiers.duns },
                  { k: "CAGE Code", v: company.identifiers.cage },
                  { k: "SAM Registration", v: "Active" },
                  { k: "ITAR", v: "Registered" },
                  { k: "Business Type", v: "Woman-Owned Small Business (WOSB), minority-owned" },
                  { k: "HUBZone", v: "SBA certified — Houston, TX facility" },
                ].map((row) => (
                  <div key={row.k} className="flex items-baseline justify-between gap-4 py-2.5">
                    <dt className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-500">{row.k}</dt>
                    <dd className="text-right text-[13px] font-semibold text-ink">{row.v}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="rounded-sm border border-line bg-white p-5">
              <h2 className="text-[17px] font-extrabold text-ink">NAICS Codes</h2>
              <div className="mt-3 divide-y divide-line">
                {company.naics.map((n) => (
                  <div key={n.code} className="flex items-baseline justify-between gap-4 py-2.5">
                    <span className="text-[13px] font-bold text-brand-blue">{n.code}</span>
                    <span className="text-right text-[12.5px] text-slate-body">{n.label}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] text-slate-500">
                NAICS coverage spans hardware and machine shop work through guided missile and space
                vehicle parts.
              </p>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Certificate Copies &amp; Expiration Dates]</ClientTag>
            <ClientTag>[Client to Provide: ITAR Secure Transfer Method &amp; Facility Clearance Status]</ClientTag>
            <ClientTag>[Client to Provide: Insurance &amp; W-9 for Onboarding]</ClientTag>
          </div>
        </Container>
      </section>

      <section className="py-12 lg:py-16">
        <Container>
          <div className="grid items-center gap-8 lg:grid-cols-2">
            <div>
              <SectionHeading
                align="left"
                eyebrow="Socioeconomic Advantage"
                title="HUBZone, WOSB & Minority-Owned Value for Primes"
                subtitle="Designations that support small business subcontracting plans, set-aside eligibility and supplier diversity goals."
              />
              <ul className="space-y-2.5 text-[13.5px] text-slate-body">
                {[
                  "Located in a designated Houston HUBZone at 3450 Lang Rd.",
                  "SBA Woman-Owned Small Business and WBENC certified",
                  "Minority-owned business with 40+ years of continuous operation",
                  "Members of GHMA, Women In Manufacturing and NTMA",
                ].map((i) => (
                  <li key={i} className="flex gap-2.5">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-red" />
                    {i}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex flex-wrap gap-3">
                <Button href="/industries/defense-itar-machining" variant="outline">
                  Defense capability
                </Button>
                <Button href="/about" variant="outline">
                  Ownership &amp; leadership
                </Button>
              </div>
            </div>
            <div className="relative min-h-[280px] overflow-hidden rounded-sm border border-line">
              <Image
                src={img.team}
                alt="Gretna Machine Shop team in Houston — a 100% women-owned and minority-owned manufacturer"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/80 to-transparent" />
              <p className="absolute inset-x-0 bottom-0 p-4 text-[12.5px] font-semibold text-white">
                Founded in 1980 by Benny and Ninfa Pérez — family-owned and operated in Houston.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <CtaBand
        title="Need Certificates for Supplier Onboarding?"
        body="Request our certificates, W-9, insurance and capabilities statement. Our team responds during Houston business hours."
        secondary={{ href: `mailto:${company.emails.quotes}`, label: "Email quotes" }}
        image={img.measuringTools}
      />

      <RelatedLinks
        title="Compliance-Adjacent Pages"
        links={[
          { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
          { label: "Equipment List", href: "/equipment-list" },
          { label: "Defense & ITAR Machining", href: "/industries/defense-itar-machining" },
          { label: "Aerospace Machining", href: "/industries/aerospace-cnc-machining" },
          { label: "About Gretna", href: "/about" },
          { label: "Request a Quote", href: "/request-a-quote" },
        ]}
      />
    </>
  );
}
