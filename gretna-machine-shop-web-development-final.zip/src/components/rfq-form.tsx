"use client";

import { useRef, useState } from "react";

const serviceOptions = [
  "5-Axis CNC Machining",
  "4-Axis CNC Milling",
  "CNC Turning (long bed / large bore)",
  "Multi-Axis Mill-Turn",
  "Wire EDM",
  "Laser Marking / UID",
  "Engineering, CAD/CAM & Assembly",
  "Not sure — please advise",
];

const industryOptions = [
  "Aerospace",
  "Defense / ITAR",
  "Oil & Gas / Energy",
  "Geothermal / Energy Transition",
  "Industrial OEM",
  "Other",
];

const qualityOptions = [
  "AS9102 First Article (FAIR)",
  "Material Test Reports (MTRs)",
  "Certificate of Conformance (C of C)",
  "PPAP",
  "Full material & dimensional data package",
];

const ACCEPT = ".step,.stp,.iges,.igs,.sldprt,.sldasm,.dxf,.dwg,.pdf,.zip";

const inputClass =
  "w-full rounded-sm border border-line bg-white px-3 py-2.5 text-[13.5px] text-ink outline-none transition-colors placeholder:text-slate-400 focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15";
const labelClass = "mb-1.5 block text-[11px] font-bold uppercase tracking-[0.1em] text-slate-500";

export function RfqForm() {
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [reference, setReference] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  function addFiles(incoming: FileList | null) {
    if (!incoming) return;
    setError(null);
    const next = [...files];
    Array.from(incoming).forEach((f) => {
      const ext = "." + (f.name.split(".").pop() ?? "").toLowerCase();
      if (!ACCEPT.split(",").includes(ext)) {
        setError(`Unsupported file type: ${f.name}. Accepted: STEP, IGES, SolidWorks, DXF, DWG, PDF, ZIP.`);
        return;
      }
      if (f.size > 25 * 1024 * 1024) {
        setError(`${f.name} exceeds the 25 MB limit per file.`);
        return;
      }
      if (next.length >= 5) {
        setError("Up to 5 files per submission. Combine large packages into a ZIP.");
        return;
      }
      if (!next.some((n) => n.name === f.name && n.size === f.size)) next.push(f);
    });
    setFiles(next);
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = e.currentTarget;
    const fd = new FormData(form);
    files.forEach((f) => fd.append("files", f));
    setSubmitting(true);
    try {
      const res = await fetch("/api/rfq", { method: "POST", body: fd });
      const data = (await res.json()) as { ok: boolean; reference?: string; error?: string };
      if (!res.ok || !data.ok) {
        setError(data.error ?? "Something went wrong. Please call 713-690-7328 or email quotes@gretnamachine.com.");
      } else {
        setReference(data.reference ?? "GMS-RFQ");
        setFiles([]);
        form.reset();
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    } catch {
      setError("Network error. Please call 713-690-7328 or email quotes@gretnamachine.com.");
    } finally {
      setSubmitting(false);
    }
  }

  if (reference) {
    return (
      <div className="rounded-sm border border-brand-blue/30 bg-brand-blue-light/40 p-6">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-brand-blue text-white">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="m5 13 4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
        <h2 className="mt-3 text-2xl font-extrabold text-ink">RFQ received — thank you.</h2>
        <p className="mt-2 text-[13.5px] leading-relaxed text-slate-body">
          Your submission is logged as <span className="font-bold text-ink">{reference}</span>. Our
          engineering and sales team reviews the print package and responds during Houston business
          hours (Mon–Fri, 7:00 AM – 4:30 PM CST).
        </p>
        <div className="mt-4 rounded-sm border border-line bg-white p-4">
          <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">Need it faster?</p>
          <p className="mt-1 text-[13px] text-slate-body">
            Call <a href="tel:+17136907328" className="font-bold text-brand-red">713-690-7328</a> and
            reference {reference}, or email{" "}
            <a href="mailto:quotes@gretnamachine.com" className="font-bold text-brand-red">quotes@gretnamachine.com</a>.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setReference(null)}
          className="mt-4 rounded-sm border border-brand-blue/40 px-4 py-2.5 text-[12px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:bg-white"
        >
          Submit another RFQ
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6" noValidate>
      <fieldset className="space-y-3">
        <legend className="mb-1 text-[14px] font-extrabold text-ink">1. Contact Information</legend>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className={labelClass} htmlFor="firstName">First name *</label>
            <input id="firstName" name="firstName" required className={inputClass} placeholder="Jordan" autoComplete="given-name" />
          </div>
          <div>
            <label className={labelClass} htmlFor="lastName">Last name *</label>
            <input id="lastName" name="lastName" required className={inputClass} placeholder="Reyes" autoComplete="family-name" />
          </div>
          <div>
            <label className={labelClass} htmlFor="email">Work email *</label>
            <input id="email" name="email" type="email" required className={inputClass} placeholder="you@company.com" autoComplete="email" />
          </div>
          <div>
            <label className={labelClass} htmlFor="phone">Phone</label>
            <input id="phone" name="phone" type="tel" className={inputClass} placeholder="713-555-0100" autoComplete="tel" />
          </div>
          <div>
            <label className={labelClass} htmlFor="company">Company *</label>
            <input id="company" name="company" required className={inputClass} placeholder="Company name" autoComplete="organization" />
          </div>
          <div>
            <label className={labelClass} htmlFor="industry">Industry</label>
            <select id="industry" name="industry" className={inputClass} defaultValue="">
              <option value="">Select industry</option>
              {industryOptions.map((i) => (
                <option key={i} value={i}>{i}</option>
              ))}
            </select>
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-[14px] font-extrabold text-ink">2. Required Services</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {serviceOptions.map((s) => (
            <label key={s} className="flex items-start gap-2 rounded-sm border border-line bg-white px-3 py-2 text-[12.5px] text-slate-body hover:border-brand-blue/40">
              <input type="checkbox" name="services" value={s} className="mt-0.5 h-3.5 w-3.5 accent-[#ad1f2b]" />
              {s}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="space-y-3">
        <legend className="mb-1 text-[14px] font-extrabold text-ink">3. Part Details</legend>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className={labelClass} htmlFor="material">Material / grade</label>
            <input id="material" name="material" className={inputClass} placeholder="Inconel 718, 17-4 PH, 4140…" />
          </div>
          <div>
            <label className={labelClass} htmlFor="quantity">Quantity / annual volume</label>
            <input id="quantity" name="quantity" className={inputClass} placeholder="e.g. 25 pcs, 500/yr" />
          </div>
          <div>
            <label className={labelClass} htmlFor="targetDelivery">Target delivery date</label>
            <input id="targetDelivery" name="targetDelivery" type="date" className={inputClass} />
          </div>
          <div>
            <label className={labelClass} htmlFor="contactPreference">Preferred contact</label>
            <select id="contactPreference" name="contactPreference" className={inputClass} defaultValue="Email">
              <option>Email</option>
              <option>Phone</option>
              <option>Either</option>
            </select>
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-[14px] font-extrabold text-ink">4. Quality Requirements</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {qualityOptions.map((q) => (
            <label key={q} className="flex items-start gap-2 text-[12.5px] text-slate-body">
              <input type="checkbox" name="qualityDocs" value={q} className="mt-0.5 h-3.5 w-3.5 accent-[#ad1f2b]" />
              {q}
            </label>
          ))}
        </div>
        <label className="mt-3 flex items-start gap-2 rounded-sm border border-amber-500/50 bg-amber-50/60 px-3 py-2.5 text-[12px] font-semibold text-amber-900">
          <input type="checkbox" name="itarControlled" value="true" className="mt-0.5 h-3.5 w-3.5 accent-[#ad1f2b]" />
          This RFQ contains ITAR-controlled or export-restricted technical data.
        </label>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-[14px] font-extrabold text-ink">5. CAD &amp; Print Upload</legend>
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            addFiles(e.dataTransfer.files);
          }}
          className={`rounded-sm border-2 border-dashed px-4 py-7 text-center transition-colors ${
            dragging ? "border-brand-red bg-brand-red/5" : "border-line bg-paper"
          }`}
        >
          <p className="text-[13.5px] font-bold text-ink">Drag &amp; drop CAD, prints or a ZIP package</p>
          <p className="mt-1 text-[11.5px] text-slate-500">
            STEP, STP, IGES, SolidWorks, DXF, DWG, PDF, ZIP • up to 5 files, 25 MB each
          </p>
          <button
            type="button"
            onClick={() => fileInput.current?.click()}
            className="mt-3 rounded-sm border border-brand-blue/40 bg-white px-4 py-2 text-[11.5px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:border-brand-blue"
          >
            Browse files
          </button>
          <input
            ref={fileInput}
            id="files"
            type="file"
            multiple
            accept={ACCEPT}
            onChange={(e) => addFiles(e.target.files)}
            className="hidden"
          />
        </div>
        {files.length > 0 && (
          <ul className="mt-2 space-y-1.5">
            {files.map((f) => (
              <li key={f.name} className="flex items-center justify-between gap-3 rounded-sm border border-line bg-white px-3 py-2 text-[12px]">
                <span className="truncate font-medium text-ink">{f.name}</span>
                <span className="flex items-center gap-3 text-slate-500">
                  {(f.size / 1024 / 1024).toFixed(2)} MB
                  <button
                    type="button"
                    onClick={() => setFiles(files.filter((x) => x !== f))}
                    className="font-bold text-brand-red hover:underline"
                  >
                    Remove
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
          File metadata is logged with your RFQ for follow-up. Do not upload classified data.
          Controlled packages should be confirmed with our team before transfer.
        </p>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-[14px] font-extrabold text-ink">6. Project Notes</legend>
        <textarea
          id="notes"
          name="notes"
          rows={5}
          className={inputClass}
          placeholder="Tolerances, finishes, outside processes, inspection requirements, delivery constraints…"
        />
      </fieldset>

      {error && (
        <p role="alert" className="rounded-sm border border-brand-red/30 bg-brand-red/5 px-3 py-2 text-[12.5px] font-semibold text-brand-red">
          {error}
        </p>
      )}

      <div className="flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={submitting}
          className="inline-flex items-center justify-center rounded-sm bg-brand-red px-6 py-3 text-[13px] font-bold uppercase tracking-[0.08em] text-white shadow-sm transition-colors hover:bg-brand-red-dark disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? "Submitting RFQ…" : "Submit RFQ"}
        </button>
        <p className="text-[11px] text-slate-500">
          Required fields marked *. We reply during Houston business hours.
        </p>
      </div>
    </form>
  );
}
