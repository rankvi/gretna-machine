import Link from "next/link";

function SpiralMark({ className = "h-9 w-9" }: { className?: string }) {
  const rings = [
    { rx: 47, ry: 26, rot: 18 },
    { rx: 44, ry: 40, rot: 52 },
    { rx: 40, ry: 47, rot: 96 },
    { rx: 31, ry: 47, rot: 140 },
    { rx: 20, ry: 40, rot: 178 },
    { rx: 12, ry: 27, rot: 210 },
  ];
  return (
    <svg
      viewBox="0 0 100 100"
      aria-hidden="true"
      className={className}
      role="presentation"
    >
      <defs>
        <linearGradient id="gretna-mark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2d7fa8" />
          <stop offset="55%" stopColor="#16496b" />
          <stop offset="100%" stopColor="#8fb6cd" />
        </linearGradient>
      </defs>
      <g fill="none" stroke="url(#gretna-mark)" strokeLinecap="round">
        {rings.map((r, i) => (
          <ellipse
            key={i}
            cx="50"
            cy="50"
            rx={r.rx}
            ry={r.ry}
            strokeWidth={i % 2 === 0 ? 3.4 : 2.2}
            opacity={0.55 + i * 0.07}
            transform={`rotate(${r.rot} 50 50)`}
          />
        ))}
        <ellipse
          cx="50"
          cy="50"
          rx="34"
          ry="34"
          strokeWidth="2"
          opacity="0.45"
          stroke="#0c2d43"
        />
      </g>
    </svg>
  );
}

export function Logo({
  variant = "dark",
  showTagline = true,
  className = "",
}: {
  variant?: "dark" | "light";
  showTagline?: boolean;
  className?: string;
}) {
  const wordColor = variant === "light" ? "text-white" : "text-brand-red";
  const shopColor = variant === "light" ? "text-white/70" : "text-slate-500";
  const tagColor = variant === "light" ? "text-white/80" : "text-brand-blue";

  return (
    <Link
      href="/"
      aria-label="Gretna Machine Shop, Inc. — home"
      className={`group flex items-center gap-2.5 ${className}`}
    >
      <SpiralMark className="h-10 w-10 shrink-0 transition-transform duration-500 group-hover:rotate-12" />
      <span className="flex flex-col leading-none">
        <span
          className={`text-[30px] font-black lowercase leading-[0.85] tracking-[-0.045em] ${wordColor}`}
          style={{ fontFamily: 'var(--font-display)', fontWeight: 800 }}
        >
          gretna
        </span>
        <span
          className={`mt-1 text-[9.5px] font-semibold uppercase leading-none tracking-[0.34em] ${shopColor}`}
        >
          machine shop
        </span>
      </span>
      {showTagline && (
        <span className="ml-2 hidden flex-col border-l border-slate-300 pl-3 xl:flex">
          <span
            className={`text-[8px] font-bold uppercase leading-relaxed tracking-[0.24em] ${tagColor}`}
          >
            The Pinnacle
            <br />
            of Precision
          </span>
        </span>
      )}
    </Link>
  );
}

export { SpiralMark };
