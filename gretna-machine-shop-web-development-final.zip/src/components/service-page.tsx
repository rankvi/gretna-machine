import Link from "next/link";
import { company } from "@/lib/company";
import { industries } from "@/lib/industries";
import { materials } from "@/lib/materials";
import { breadcrumbJsonLd, faqJsonLd, serviceJsonLd } from "@/lib/seo";
import type { ServiceContent } from "@/lib/services";
import { FaqList } from "./faq";
import {
  AnchorBar,
  DfmGrid,
  InspectionBlock,
  PhotoCardGrid,
  RelatedLinks,
  SectionCta,
  ValueGrid,
} from "./blocks";
import {
  Button,
  ClientTag,
  Container,
  CtaBand,
  MachineSpecTable,
  MaterialMatrix,
  PageHero,
  ProcessCards,
  SectionHeading,
} from "./ui";

export function ServicePage({ service }: { service: ServiceContent }) {
  const path = `/services/${service.slug}`;
  const anchors = [
    { label: "Capabilities", href: "#capabilities" },
    { label: "Equipment", href: "#equipment" },
    { label: "Materials", href: "#materials" },
    { label: "Quality", href: "#quality" },
    { label: "Applications", href: "#applications" },
    { label: "FAQ", href: "#faq" },
  ];
  const relatedIndustryLinks = industries
    .filter((i) => service.relatedIndustries.includes(i.slug))
    .map((i) => ({ label: `${i.name} machining`, href: `/industries/${i.slug}`, desc: i.badges.slice(0, 3).join(" • ") }));
  const relatedMaterialLinks = materials
    .filter((m) => service.relatedMaterials.includes(m.slug))
    .map((m) => ({ label: m.name, href: `/materials/${m.slug}`, desc: m.grades.map((g) => g.grade).slice(0, 3).join(", ") }));

  return (
    <>
      <PageHero
        breadcrumbs={[
          { name: "Services", href: "/services/cnc-machining-houston-tx" },
          { name: service.navLabel, href: path },
        ]}
        eyebrow={`${service.navLabel} • Houston, TX`}
        h1={service.h1}
        intro={service.heroIntro}
        usps={service.heroUsps}
        badges={service.badges}
        image={service.heroImage}
        imageAlt={`${service.name} at Gretna Machine Shop in Houston, Texas`}
        secondary={{ href: "/equipment-list", label: "Equipment List" }}
      />

      <AnchorBar items={anchors} />

      {/* CAPABILITIES */}
      <section id="capabilities" className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Process Capability"
            title={`${service.name} Capability at Gretna`}
            subtitle="Machines, people and quality controls that all live under one Houston roof and one AS9100 Rev D system."
          />
          <PhotoCardGrid cards={service.capabilities} />
          <div className="mt-6 rounded-sm border border-brand-blue/20 bg-brand-blue-light/50 p-5">
            <p className="text-[13.5px] leading-relaxed text-slate-body">
              <span className="font-bold text-ink">Why it matters: </span>
              {service.callout}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <Button href="/request-a-quote">Request a Quote</Button>
              <Link href="/quality-assurance-inspection" className="text-[12px] font-bold uppercase tracking-[0.08em] text-brand-blue underline decoration-brand-red/40 underline-offset-4 hover:text-brand-red">
                Quality &amp; inspection approach
              </Link>
            </div>
          </div>
        </Container>
      </section>

      {/* EQUIPMENT */}
      <section id="equipment" className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Equipment & Capacity"
            title="Machine Specifications & Working Envelopes"
            subtitle="Exact platforms, travels and load limits so engineers can confirm fit before requesting a quote."
          />
          <MachineSpecTable groupIds={service.machineGroups} />
          <div className="mt-5 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Standard &amp; Tightest Tolerances]</ClientTag>
            <ClientTag>[Client to Provide: Production Volume Sweet Spot / MOQ]</ClientTag>
          </div>
        </Container>
      </section>

      {/* MATERIALS */}
      <section id="materials" className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Materials"
            title="Alloys We Machine Every Week"
            subtitle="Superalloys, titanium, stainless and chrome grades, alloy steel and engineering plastics — machined and documented in-house."
          />
          <MaterialMatrix />
          <div className="mt-4 flex justify-center">
            <Button href="/materials" variant="outline">
              View all materials
            </Button>
          </div>
        </Container>
      </section>

      <CtaBand
        title={`Need ${service.name} in Texas?`}
        body={`Send CAD, prints and quantities for engineering review. Talk directly with our team at ${company.phone} or ${company.emails.quotes}.`}
      />

      {/* QUALITY */}
      <section id="quality" className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Quality Control"
            title="Inspection & Metrology Behind Every Part"
            subtitle="Critical features are measured, recorded and traceable — not eyeballed. Documentation supports AS9100D supplier audits."
          />
          <InspectionBlock />
        </Container>
      </section>

      {/* APPLICATIONS */}
      <section id="applications" className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Applications"
            title="Where This Capability Earns Its Keep"
            subtitle="Representative part families across aerospace, defense and energy programs."
          />
          <PhotoCardGrid cards={service.applications} />
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">
              Part photography:
            </span>
            <ClientTag>[Client to Provide: Part Photos for Gallery]</ClientTag>
            <Link href="/case-studies" className="text-[12px] font-bold uppercase tracking-[0.08em] text-brand-blue hover:text-brand-red">
              See case studies →
            </Link>
          </div>
        </Container>
      </section>

      {/* VALUE PROPS */}
      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Why Gretna"
            title="Four Reasons Buyers Award Us the PO"
            subtitle="Compliance, exotic material capability, real-time visibility and a single accountable supplier."
          />
          <ValueGrid items={service.valueProps} />
        </Container>
      </section>

      {/* DFM */}
      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Engineer-to-Engineer"
            title={service.dfmTitle}
            subtitle="Small drawing changes reduce cost and lead time on this process. These are the items our programmers flag most often."
          />
          <DfmGrid tips={service.dfmTips} />
        </Container>
      </section>

      {/* PROCESS */}
      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="How It Works"
            title="RFQ to Delivery in Four Steps"
            subtitle="One ERP record, one engineering contact, and documentation at every stage."
          />
          <ProcessCards />
          <div className="mt-7">
            <SectionCta
              title="Have prints ready?"
              body="Upload STEP, IGES, SolidWorks, DXF or a PDF print. Mark ITAR-controlled submissions and we will route them securely."
            />
          </div>
        </Container>
      </section>

      {/* FAQ */}
      <section id="faq" className="border-t border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Technical FAQ"
            title="Buyer Questions, Answered Directly"
            subtitle="If we have not published the answer yet, it is flagged rather than guessed."
          />
          <FaqList faqs={service.faqs} columns={2} />
        </Container>
      </section>

      <RelatedLinks
        title={`Industries & Materials for ${service.navLabel}`}
        intro="Cross-referenced so procurement and engineering land on the right page in one hop."
        links={[
          ...relatedIndustryLinks,
          ...relatedMaterialLinks,
          { label: "Equipment List", href: "/equipment-list", desc: "Full Okuma, Doosan, HAAS and ONA fleet" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection", desc: "Hexagon CMM, Keyence, Gagemaker" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining", desc: "Regional coverage and shipping" },
        ]}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            serviceJsonLd({ name: service.name, description: service.metaDescription, path }),
          ),
        }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd(service.faqs)) }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            breadcrumbJsonLd([
              { name: "Home", path: "/" },
              { name: "Services", path: "/services/cnc-machining-houston-tx" },
              { name: service.navLabel, path },
            ]),
          ),
        }}
      />
    </>
  );
}
