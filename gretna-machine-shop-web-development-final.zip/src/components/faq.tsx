import Image from "next/image";

export function FaqList({
  faqs,
  columns = 1,
}: {
  faqs: { q: string; a: string }[];
  columns?: 1 | 2;
}) {
  return (
    <div className={columns === 2 ? "grid gap-3 md:grid-cols-2" : "space-y-3"}>
      {faqs.map((f, i) => (
        <details
          key={f.q}
          open={i === 0}
          className="group rounded-sm border border-line bg-white px-4 py-3.5 open:border-brand-blue/30 open:shadow-sm"
        >
          <summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[14.5px] font-bold leading-snug text-ink marker:hidden">
            <span>{f.q}</span>
            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-sm border border-brand-blue/25 text-brand-blue">
              <svg
                width="11"
                height="11"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden="true"
                className="transition-transform duration-200 group-open:rotate-45"
              >
                <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </span>
          </summary>
          <p className="mt-2.5 border-t border-line/70 pt-2.5 text-[13.5px] leading-relaxed text-slate-body">
            {f.a}
          </p>
        </details>
      ))}
    </div>
  );
}

export function FaqSection({
  faqs,
  title = "Procurement FAQ",
  subtitle,
  image,
  imageAlt = "Gretna quality engineer inspecting a machined component",
  eyebrow,
}: {
  faqs: { q: string; a: string }[];
  title?: string;
  subtitle?: string;
  image?: string;
  imageAlt?: string;
  eyebrow?: string;
}) {
  return (
    <section className="border-t border-line bg-paper py-14 lg:py-16">
      <div className="container-x grid gap-9 lg:grid-cols-[0.32fr_0.68fr]">
        <div>
          {image && (
            <div className="relative mb-5 hidden min-h-[300px] overflow-hidden rounded-sm border border-line lg:block">
              <Image src={image} alt={imageAlt} fill sizes="32vw" className="object-cover" />
              <div className="absolute inset-x-0 bottom-0 bg-brand-blue-dark/90 p-4">
                <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/60">
                  Quality comes first
                </p>
                <p className="mt-1 text-[13px] font-semibold text-white">
                  AS9100 Rev D • In-house PE • Hexagon CMM
                </p>
              </div>
            </div>
          )}
          {eyebrow && (
            <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand-red">{eyebrow}</p>
          )}
          <h2 className="mt-2 text-3xl font-extrabold leading-tight text-ink">{title}</h2>
          {subtitle && <p className="mt-3 text-[14px] leading-relaxed text-slate-body">{subtitle}</p>}
        </div>
        <FaqList faqs={faqs} />
      </div>
    </section>
  );
}
