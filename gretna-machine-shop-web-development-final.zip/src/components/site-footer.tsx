import Link from "next/link";
import { company } from "@/lib/company";
import { serviceNav } from "@/lib/services";
import { industryNav } from "@/lib/industries";
import { materialNav } from "@/lib/materials";
import { Logo } from "./logo";
import { CertStrip, Container } from "./ui";

const qualityLinks = [
  { label: "Equipment List", href: "/equipment-list" },
  { label: "Quality & Inspection", href: "/quality-assurance-inspection" },
  { label: "Certifications", href: "/certifications" },
  { label: "Case Studies", href: "/case-studies" },
  { label: "Resources & DFM Guides", href: "/resources" },
];

const companyLinks = [
  { label: "About Gretna", href: "/about" },
  { label: "Texas CNC Machining", href: "/texas-cnc-machining" },
  { label: "Careers", href: "/careers" },
  { label: "Contact", href: "/contact" },
  { label: "Request a Quote", href: "/request-a-quote" },
];

export function SiteFooter() {
  return (
    <footer className="bg-brand-blue-dark text-white">
      <Container className="py-12">
        <div className="flex flex-col gap-8 border-b border-white/15 pb-9 lg:flex-row lg:items-start lg:justify-between">
          <div className="max-w-sm">
            <Logo variant="light" />
            <p className="mt-4 text-[13px] leading-relaxed text-white/65">
              Precision CNC machining from subsea to Mars. AS9100 Rev D and ITAR registered
              manufacturer in Houston, TX — women-owned and minority-owned since 1980.
            </p>
            <div className="mt-4 flex items-center gap-2">
              <a
                href={company.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Gretna Machine Shop on LinkedIn"
                className="flex h-8 w-8 items-center justify-center rounded-sm border border-white/20 text-white/70 hover:border-white/50 hover:text-white"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.7h.06C14.4 9.7 15.6 9 17.3 9 20.4 9 21 11 21 14v7h-4v-6.2c0-1.5-.03-3.4-2.1-3.4-2.1 0-2.4 1.6-2.4 3.3V21h-4V9Z" />
                </svg>
              </a>
              <a
                href={company.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Gretna Machine Shop on Facebook"
                className="flex h-8 w-8 items-center justify-center rounded-sm border border-white/20 text-white/70 hover:border-white/50 hover:text-white"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M13.5 21v-8h2.7l.4-3.1h-3.1V7.9c0-.9.25-1.5 1.55-1.5H17V3.6c-.3-.04-1.3-.13-2.5-.13-2.5 0-4.2 1.5-4.2 4.3v2.1H7.6V13h2.7v8h3.2Z" />
                </svg>
              </a>
              <Link
                href="/request-a-quote"
                className="ml-1 rounded-sm bg-brand-red px-3 py-2 text-[11px] font-bold uppercase tracking-[0.08em] text-white hover:bg-brand-red-dark"
              >
                Request a Quote
              </Link>
            </div>
          </div>

          <div className="grid flex-1 gap-8 sm:grid-cols-2 lg:ml-10 lg:grid-cols-4">
            <FooterColumn title="Services" links={serviceNav.map((s) => ({ label: s.label, href: `/services/${s.slug}` }))} />
            <FooterColumn
              title="Industries & Materials"
              links={[
                ...industryNav.map((i) => ({ label: i.label, href: `/industries/${i.slug}` })),
                ...materialNav.map((m) => ({ label: m.label, href: `/materials/${m.slug}` })),
              ]}
            />
            <FooterColumn title="Quality & Equipment" links={qualityLinks} />
            <div>
              <p className="mb-3 text-[10.5px] font-bold uppercase tracking-[0.18em] text-white/45">
                Company & Contact
              </p>
              <ul className="space-y-2 text-[12.5px]">
                {companyLinks.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-white/75 hover:text-white">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
              <div className="mt-4 space-y-1.5 text-[12px] text-white/65">
                <p>{company.address.full}</p>
                <p>
                  <a href={`tel:${company.phoneHref}`} className="font-semibold text-white hover:text-brand-red">
                    {company.phone}
                  </a>{" "}
                  • Fax {company.fax}
                </p>
                <p>
                  <a href={`mailto:${company.emails.quotes}`} className="hover:text-white">
                    {company.emails.quotes}
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <CertStrip tone="dark" />
          <div className="text-[11px] text-white/55">
            <p>
              DUNS {company.identifiers.duns} • CAGE {company.identifiers.cage} • SAM Registered •
              100% Women &amp; Minority Owned
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-col gap-2 border-t border-white/10 pt-5 text-[11px] text-white/45 sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 {company.name}. All rights reserved. Operating in Houston since 1980.</p>
          <p className="flex flex-wrap items-center gap-3">
            <span>NAICS 332510 • 332710 • 332721 • 332912 • 336411 • 336413 • 336419</span>
            <Link href="/resources" className="hover:text-white">
              Resources
            </Link>
            <Link href="/admin/rfqs" className="hover:text-white">
              RFQ Inbox
            </Link>
          </p>
        </div>
      </Container>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: { label: string; href: string }[];
}) {
  return (
    <div>
      <p className="mb-3 text-[10.5px] font-bold uppercase tracking-[0.18em] text-white/45">{title}</p>
      <ul className="space-y-1.5">
        {links.map((l) => (
          <li key={l.href}>
            <Link href={l.href} className="text-[12.5px] text-white/75 hover:text-white">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
