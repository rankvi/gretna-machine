import Image from "next/image";
import Link from "next/link";
import { metrology } from "@/lib/company";
import { img } from "@/lib/images";
import type { Card } from "@/lib/services";
import { Button, ClientTag, Container, SectionHeading } from "./ui";

export function AnchorBar({ items }: { items: { label: string; href: string }[] }) {
  return (
    <div className="sticky top-[60px] z-30 border-b border-line bg-white/95 shadow-sm backdrop-blur lg:top-[101px]">
      <Container className="flex gap-1 overflow-x-auto py-2">
        {items.map((i) => (
          <a
            key={i.href}
            href={i.href}
            className="whitespace-nowrap rounded-sm px-2.5 py-1.5 text-[11.5px] font-bold uppercase tracking-[0.06em] text-slate-500 transition-colors hover:bg-brand-blue-light hover:text-brand-blue"
          >
            {i.label}
          </a>
        ))}
        <Link
          href="/request-a-quote"
          className="ml-auto hidden whitespace-nowrap rounded-sm bg-brand-red px-3 py-1.5 text-[11.5px] font-bold uppercase tracking-[0.06em] text-white sm:block"
        >
          Get Quote
        </Link>
      </Container>
    </div>
  );
}

export function PhotoCardGrid({
  cards,
  columns = 3,
}: {
  cards: Card[];
  columns?: 2 | 3;
}) {
  return (
    <div className={`grid gap-4 sm:grid-cols-2 ${columns === 3 ? "lg:grid-cols-3" : ""}`}>
      {cards.map((c) => (
        <div
          key={c.title}
          className="group overflow-hidden rounded-sm border border-line bg-white transition-shadow hover:shadow-md"
        >
          {c.image && (
            <div className="relative h-40 overflow-hidden">
              <Image
                src={c.image}
                alt={c.title}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
          )}
          <div className="p-4">
            <h3 className="text-[15px] font-extrabold leading-snug text-ink">{c.title}</h3>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-body">{c.body}</p>
            {c.points && (
              <ul className="mt-3 space-y-1 border-t border-line/70 pt-2.5">
                {c.points.map((p) => (
                  <li key={p} className="flex items-start gap-1.5 text-[11.5px] text-slate-500">
                    <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-brand-red" />
                    {p}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export function ValueGrid({ items, columns = 4 }: { items: Card[]; columns?: 2 | 4 }) {
  return (
    <div className={`grid gap-4 sm:grid-cols-2 ${columns === 4 ? "lg:grid-cols-4" : ""}`}>
      {items.map((v) => (
        <div key={v.title} className="rounded-sm border border-line bg-white p-5">
          <span className="flex h-8 w-8 items-center justify-center rounded-sm bg-brand-blue-light text-brand-blue">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="m5 13 4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <h3 className="mt-3 text-[14px] font-bold leading-snug text-ink">{v.title}</h3>
          <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-body">{v.body}</p>
        </div>
      ))}
    </div>
  );
}

export function DfmGrid({ tips }: { tips: Card[] }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {tips.map((t, i) => (
        <div key={t.title} className="rounded-sm border border-line bg-white p-4">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand-red">
            Tip {String(i + 1).padStart(2, "0")}
          </p>
          <h3 className="mt-1.5 text-[13.5px] font-bold leading-snug text-ink">{t.title}</h3>
          <p className="mt-1 text-[12px] leading-relaxed text-slate-500">{t.body}</p>
        </div>
      ))}
    </div>
  );
}

export function InspectionBlock() {
  return (
    <div className="grid gap-6 lg:grid-cols-2 lg:gap-10">
      <div className="overflow-hidden rounded-sm border border-line bg-white">
        <div className="border-b border-line bg-brand-blue-light/50 px-4 py-3">
          <h3 className="text-[14px] font-extrabold uppercase tracking-[0.06em] text-brand-blue">
            In-House Metrology Equipment
          </h3>
        </div>
        <table className="w-full border-collapse text-left">
          <tbody>
            {metrology.map((m) => (
              <tr key={m.name} className="border-b border-line/70 last:border-0">
                <td className="px-4 py-2.5 align-top text-[12.5px] font-bold text-ink">{m.name}</td>
                <td className="px-4 py-2.5 text-[12px] text-slate-body">{m.purpose}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex flex-wrap gap-2 border-t border-line px-4 py-3">
          <ClientTag>[Client to Provide: FAIR / MTR / C of C Package]</ClientTag>
        </div>
      </div>
      <div className="space-y-4">
        <div className="relative min-h-[250px] overflow-hidden rounded-sm border border-line">
          <Image
            src={img.caliper}
            alt="Hexagon CMM and precision measurement at Gretna Machine Shop in Houston"
            fill
            sizes="(max-width: 1024px) 100vw, 48vw"
            className="object-cover"
          />
          <div className="absolute inset-x-0 bottom-0 bg-brand-blue-dark/85 p-3">
            <p className="text-[11.5px] font-semibold text-white">
              Dimensional data captured against the model — not a visual check.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[
            { src: img.caliperDetail, label: "Feature measurement" },
            { src: img.measuringTools, label: "Gage control" },
            { src: img.facilityFloor, label: "Final inspection" },
          ].map((s) => (
            <div key={s.label} className="overflow-hidden rounded-sm border border-line bg-white">
              <div className="relative h-20">
                <Image src={s.src} alt={s.label} fill sizes="140px" className="object-cover" />
              </div>
              <p className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-[0.06em] text-slate-500">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function RelatedLinks({
  title,
  links,
  intro,
}: {
  title: string;
  intro?: string;
  links: { label: string; href: string; desc?: string }[];
}) {
  return (
    <section className="py-12">
      <Container>
        <SectionHeading eyebrow="Keep Exploring" title={title} subtitle={intro} />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="group flex items-center justify-between gap-3 rounded-sm border border-line bg-white px-4 py-3.5 transition-colors hover:border-brand-red"
            >
              <span>
                <span className="block text-[13.5px] font-bold text-ink group-hover:text-brand-red">
                  {l.label}
                </span>
                {l.desc && <span className="mt-0.5 block text-[11.5px] text-slate-500">{l.desc}</span>}
              </span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="shrink-0 text-brand-red transition-transform group-hover:translate-x-1">
                <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </Link>
          ))}
        </div>
      </Container>
    </section>
  );
}

export function SectionCta({
  title,
  body,
  label = "Request a Quote",
}: {
  title: string;
  body: string;
  label?: string;
}) {
  return (
    <div className="rounded-sm border border-brand-blue/20 bg-brand-blue-light/50 px-5 py-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-[14px] font-bold text-ink">{title}</p>
          <p className="mt-1 text-[12.5px] text-slate-body">{body}</p>
        </div>
        <Button href="/request-a-quote">{label}</Button>
      </div>
    </div>
  );
}
