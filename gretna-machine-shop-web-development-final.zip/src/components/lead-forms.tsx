"use client";

import { useState } from "react";

const inputClass =
  "w-full rounded-sm border border-line bg-white px-3 py-2.5 text-[13.5px] text-ink outline-none transition-colors placeholder:text-slate-400 focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15";
const labelClass = "mb-1.5 block text-[11px] font-bold uppercase tracking-[0.1em] text-slate-500";

function SuccessPanel({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-sm border border-brand-blue/30 bg-brand-blue-light/40 p-6">
      <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-brand-blue text-white">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="m5 13 4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <h2 className="mt-3 text-xl font-extrabold text-ink">{title}</h2>
      <p className="mt-2 text-[13.5px] leading-relaxed text-slate-body">{body}</p>
    </div>
  );
}

export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    setError("");
    const fd = new FormData(e.currentTarget);
    fd.set("kind", "contact");
    try {
      const res = await fetch("/api/contact", { method: "POST", body: fd });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !data.ok) {
        setError(data.error ?? "Message could not be sent.");
        setStatus("error");
        return;
      }
      setStatus("sent");
      e.currentTarget.reset();
    } catch {
      setError("Network error. Please call 713-690-7328.");
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <SuccessPanel
        title="Message received."
        body="Our team reviews messages during Houston business hours (Mon–Fri, 7:00 AM – 4:30 PM CST). For urgent production needs, call 713-690-7328."
      />
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelClass} htmlFor="c-name">Name *</label>
          <input id="c-name" name="name" required className={inputClass} placeholder="Your name" />
        </div>
        <div>
          <label className={labelClass} htmlFor="c-email">Email *</label>
          <input id="c-email" name="email" type="email" required className={inputClass} placeholder="you@company.com" />
        </div>
        <div>
          <label className={labelClass} htmlFor="c-phone">Phone</label>
          <input id="c-phone" name="phone" type="tel" className={inputClass} placeholder="713-555-0100" />
        </div>
        <div>
          <label className={labelClass} htmlFor="c-role">Company / role</label>
          <input id="c-role" name="role" className={inputClass} placeholder="Company, title" />
        </div>
      </div>
      <div>
        <label className={labelClass} htmlFor="c-subject">Subject</label>
        <select id="c-subject" name="subject" className={inputClass} defaultValue="RFQ / Quote question">
          {[
            "RFQ / Quote question",
            "Supplier onboarding & certifications",
            "Engineering / DFM question",
            "Facility visit request",
            "Careers",
            "Other",
          ].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>
      <div>
        <label className={labelClass} htmlFor="c-message">Message *</label>
        <textarea id="c-message" name="message" required rows={5} className={inputClass} placeholder="Tell us what you need to machine, the material, quantity and timing." />
      </div>
      {error && <p role="alert" className="rounded-sm border border-brand-red/30 bg-brand-red/5 px-3 py-2 text-[12.5px] font-semibold text-brand-red">{error}</p>}
      <button
        type="submit"
        disabled={status === "sending"}
        className="rounded-sm bg-brand-red px-6 py-3 text-[13px] font-bold uppercase tracking-[0.08em] text-white hover:bg-brand-red-dark disabled:opacity-60"
      >
        {status === "sending" ? "Sending…" : "Send Message"}
      </button>
      <p className="text-[11px] text-slate-500">
        Do not send controlled technical data through this form. Use the RFQ workflow for prints.
      </p>
    </form>
  );
}

export function CareerForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    setError("");
    const fd = new FormData(e.currentTarget);
    fd.set("kind", "careers");
    try {
      const res = await fetch("/api/contact", { method: "POST", body: fd });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !data.ok) {
        setError(data.error ?? "Application could not be sent.");
        setStatus("error");
        return;
      }
      setStatus("sent");
      e.currentTarget.reset();
    } catch {
      setError("Network error. Please email Hr@gretnamachine.com.");
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <SuccessPanel
        title="Application received."
        body="Thank you for your interest in Gretna Machine Shop. Our HR team reviews applications and contacts candidates directly. You can also email Hr@gretnamachine.com."
      />
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelClass} htmlFor="j-name">Name *</label>
          <input id="j-name" name="name" required className={inputClass} placeholder="Full name" />
        </div>
        <div>
          <label className={labelClass} htmlFor="j-email">Email *</label>
          <input id="j-email" name="email" type="email" required className={inputClass} placeholder="you@email.com" />
        </div>
        <div>
          <label className={labelClass} htmlFor="j-phone">Phone</label>
          <input id="j-phone" name="phone" type="tel" className={inputClass} placeholder="713-555-0100" />
        </div>
        <div>
          <label className={labelClass} htmlFor="j-role">Position</label>
          <select id="j-role" name="role" className={inputClass} defaultValue="CNC Machinist">
            {["CNC Machinist", "CNC Programmer", "Quality Inspector", "Apprentice / Entry Level", "Engineering", "Other"].map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </div>
      </div>
      <div>
        <label className={labelClass} htmlFor="j-message">Experience summary *</label>
        <textarea id="j-message" name="message" required rows={5} className={inputClass} placeholder="Machines, controls, materials and years of experience." />
      </div>
      <div>
        <label className={labelClass} htmlFor="j-resume">Resume (PDF or DOCX)</label>
        <input
          id="j-resume"
          name="resume"
          type="file"
          accept=".pdf,.doc,.docx"
          className="w-full rounded-sm border border-line bg-white px-3 py-2.5 text-[12.5px] text-slate-body file:mr-3 file:rounded-sm file:border-0 file:bg-brand-blue-light file:px-3 file:py-1.5 file:text-[11px] file:font-bold file:uppercase file:tracking-[0.08em] file:text-brand-blue"
        />
      </div>
      {error && <p role="alert" className="rounded-sm border border-brand-red/30 bg-brand-red/5 px-3 py-2 text-[12.5px] font-semibold text-brand-red">{error}</p>}
      <button
        type="submit"
        disabled={status === "sending"}
        className="rounded-sm bg-brand-red px-6 py-3 text-[13px] font-bold uppercase tracking-[0.08em] text-white hover:bg-brand-red-dark disabled:opacity-60"
      >
        {status === "sending" ? "Submitting…" : "Submit Application"}
      </button>
    </form>
  );
}
