import Link from "next/link";
import type { MaterialContent } from "@/lib/materials";
import { services } from "@/lib/services";
import { breadcrumbJsonLd, faqJsonLd, serviceJsonLd } from "@/lib/seo";
import { FaqList } from "./faq";
import { DfmGrid, RelatedLinks, ValueGrid } from "./blocks";
import {
  ClientTag,
  Container,
  CtaBand,
  MachineSpecTable,
  PageHero,
  SectionHeading,
} from "./ui";

export function MaterialPage({ material }: { material: MaterialContent }) {
  const path = `/materials/${material.slug}`;
  const relatedServiceLinks = services
    .filter((s) => material.relatedServices.includes(s.slug))
    .map((s) => ({ label: s.navLabel, href: `/services/${s.slug}`, desc: s.heroUsps[0] }));

  return (
    <>
      <PageHero
        breadcrumbs={[
          { name: "Materials", href: "/materials" },
          { name: material.navLabel, href: path },
        ]}
        eyebrow={`${material.name} • Houston, TX`}
        h1={material.h1}
        intro={material.heroIntro}
        usps={material.heroUsps}
        badges={material.badges}
        image={material.heroImage}
        imageAlt={`${material.name} machining at Gretna Machine Shop in Houston, Texas`}
        secondary={{ href: "/equipment-list", label: "Equipment List" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Grades Covered"
            title="Alloy Grades We Machine"
            subtitle="If your grade is not listed, send the specification — we will confirm capability before quoting."
          />
          <div className="overflow-hidden rounded-sm border border-line bg-white">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] border-collapse text-left">
                <thead>
                  <tr className="bg-brand-blue-light/60 text-[10.5px] uppercase tracking-[0.12em] text-brand-blue">
                    <th className="px-4 py-3 font-bold">Grade</th>
                    <th className="px-4 py-3 font-bold">Family</th>
                    <th className="px-4 py-3 font-bold">Machinability</th>
                    <th className="px-4 py-3 font-bold">Typical Applications</th>
                  </tr>
                </thead>
                <tbody>
                  {material.grades.map((g) => (
                    <tr key={g.grade} className="border-t border-line/70 align-top text-[13px]">
                      <td className="px-4 py-3 font-bold text-ink">{g.grade}</td>
                      <td className="px-4 py-3 text-slate-body">{g.family}</td>
                      <td className="px-4 py-3 text-slate-body">{g.machinability}</td>
                      <td className="px-4 py-3 text-slate-body">{g.applications}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <ClientTag>[Client to Provide: Material Sourcing &amp; Certifications Policy]</ClientTag>
            <ClientTag>[Client to Provide: Standard &amp; Tightest Tolerances]</ClientTag>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Equipment Advantage"
            title={`How Gretna Machines ${material.navLabel}`}
            subtitle="Rigid platforms, correct tooling and the inspection discipline these alloys demand."
          />
          <ValueGrid items={material.advantages} />
          <div className="mt-8">
            <MachineSpecTable groupIds={material.equipmentGroups} />
          </div>
        </Container>
      </section>

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Industries" title="Where These Materials Are Used" subtitle="Common applications across our core markets." />
          <div className="flex flex-wrap justify-center gap-2">
            {material.industriesUsing.map((i) => (
              <span
                key={i}
                className="rounded-sm border border-brand-blue/20 bg-brand-blue-light/50 px-3 py-1.5 text-[12px] font-bold uppercase tracking-[0.08em] text-brand-blue"
              >
                {i}
              </span>
            ))}
          </div>
        </Container>
      </section>

      <CtaBand
        title={`Sending a ${material.navLabel} RFQ?`}
        body="Include the exact grade, heat-treat condition, quantity and any quality documentation requirements so engineering can quote accurately."
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="DFM Tips"
            title={`Design Guidance for ${material.navLabel}`}
            subtitle="Practical notes from our programming team — the changes that most often reduce cost or scrap."
          />
          <DfmGrid tips={material.dfmTips} />
        </Container>
      </section>

      <section className="border-t border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="FAQ" title={`${material.navLabel} Machining FAQ`} subtitle="Answers for engineers and buyers specifying this material family." />
          <FaqList faqs={material.faqs} columns={2} />
        </Container>
      </section>

      <RelatedLinks
        title={`Related Services & Material Guides`}
        intro="Cross-linked so you can move from material to process in one click."
        links={[
          ...relatedServiceLinks,
          { label: "All Materials", href: "/materials", desc: "Material comparison hub" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection", desc: "Metrology and documentation" },
          { label: "Request a Quote", href: "/request-a-quote", desc: "Upload CAD and prints" },
          { label: "Texas CNC Machining", href: "/texas-cnc-machining", desc: "Regional coverage" },
        ]}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            serviceJsonLd({ name: material.name, description: material.metaDescription, path }),
          ),
        }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd(material.faqs)) }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            breadcrumbJsonLd([
              { name: "Home", path: "/" },
              { name: "Materials", path: "/materials" },
              { name: material.navLabel, path },
            ]),
          ),
        }}
      />
      <Link href="/request-a-quote" className="sr-only">
        Request a quote from Gretna Machine Shop
      </Link>
    </>
  );
}
