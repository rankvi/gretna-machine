import Link from "next/link";
import { company } from "@/lib/company";
import type { IndustryContent } from "@/lib/industries";
import { materials } from "@/lib/materials";
import { services } from "@/lib/services";
import { breadcrumbJsonLd, faqJsonLd, serviceJsonLd } from "@/lib/seo";
import { FaqList } from "./faq";
import { PhotoCardGrid, RelatedLinks } from "./blocks";
import {
  Button,
  ClientTag,
  Container,
  CtaBand,
  MachineSpecTable,
  PageHero,
  SectionHeading,
  StatRow,
} from "./ui";

export function IndustryPage({ industry }: { industry: IndustryContent }) {
  const path = `/industries/${industry.slug}`;
  const relatedServiceLinks = services
    .filter((s) => industry.relatedServices.includes(s.slug))
    .map((s) => ({ label: s.navLabel, href: `/services/${s.slug}`, desc: s.heroUsps[0] }));
  const relatedMaterialLinks = materials
    .filter((m) => industry.relatedMaterials.includes(m.slug))
    .map((m) => ({ label: m.name, href: `/materials/${m.slug}`, desc: m.badges.slice(0, 3).join(" • ") }));

  return (
    <>
      <PageHero
        breadcrumbs={[
          { name: "Industries", href: "/industries/aerospace-cnc-machining" },
          { name: industry.navLabel, href: path },
        ]}
        eyebrow={`${industry.navLabel} • Houston, TX`}
        h1={industry.h1}
        intro={industry.heroIntro}
        usps={industry.heroUsps}
        badges={industry.badges}
        image={industry.heroImage}
        imageAlt={`${industry.name} CNC machining at Gretna Machine Shop, Houston TX`}
        secondary={{ href: "/certifications", label: "Certifications & Codes" }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Typical Components"
            title={`Parts We Machine for ${industry.navLabel}`}
            subtitle="Representative part families — each produced with the material, tolerance and documentation controls the program requires."
          />
          <PhotoCardGrid cards={industry.components} />
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">
              Part imagery:
            </span>
            <ClientTag>[Client to Provide: 3-6 Real Part Photos &amp; Dimensions]</ClientTag>
          </div>
        </Container>
      </section>

      <section className="border-y border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Applicable Equipment"
            title="Machines & Envelopes for This Market"
            subtitle="A quick capability check for engineers confirming machine fit before releasing prints."
          />
          <MachineSpecTable groupIds={industry.machineGroups} />
        </Container>
      </section>

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="Compliance" title={industry.complianceTitle} subtitle="What procurement receives, and what is still being finalized." />
          <div className="grid gap-4 sm:grid-cols-2">
            {industry.compliance.map((c) => (
              <div key={c.title} className="rounded-sm border border-line bg-white p-5">
                <h3 className="text-[14.5px] font-extrabold text-ink">{c.title}</h3>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-body">{c.body}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 grid gap-4 rounded-sm border border-line bg-brand-blue-light/40 p-5 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-slate-400">
                Identifiers for your PO &amp; supplier onboarding
              </p>
              <p className="mt-2 text-[13px] text-slate-body">
                DUNS <span className="font-bold text-ink">{company.identifiers.duns}</span> • CAGE{" "}
                <span className="font-bold text-ink">{company.identifiers.cage}</span> • SAM Registered
                • NAICS {company.naics.map((n) => n.code).join(", ")}
              </p>
            </div>
            <Button href="/certifications" variant="outline">
              Certification detail
            </Button>
          </div>
        </Container>
      </section>

      <CtaBand
        title={`Sending a ${industry.navLabel} RFQ?`}
        body="Include material, quantity, delivery target and any quality clauses. Controlled drawings can be routed through our ITAR-aware RFQ workflow."
        secondary={{ href: `tel:${company.phoneHref}`, label: `Call ${company.phone}` }}
      />

      <section className="py-12 lg:py-16">
        <Container>
          <SectionHeading
            eyebrow="Track Record"
            title={`${industry.navLabel} Proof Points`}
            subtitle="Verified facts — no invented percentages or fabricated customer quotes."
          />
          <StatRow items={industry.proof.map((p) => ({ stat: p.stat, label: p.label }))} />
        </Container>
      </section>

      <section className="border-t border-line bg-paper py-12 lg:py-16">
        <Container>
          <SectionHeading eyebrow="FAQ" title={`${industry.navLabel} Procurement FAQ`} subtitle="Direct answers for supplier onboarding and engineering review." />
          <FaqList faqs={industry.faqs} columns={2} />
        </Container>
      </section>

      <RelatedLinks
        title={`Services & Materials for ${industry.navLabel}`}
        intro="Every page links back to the capability and material detail it depends on."
        links={[
          ...relatedServiceLinks,
          ...relatedMaterialLinks,
          { label: "Case Studies", href: "/case-studies", desc: "NASA Orion and subsea examples" },
          { label: "Quality & Inspection", href: "/quality-assurance-inspection", desc: "CMM, Keyence, Gagemaker" },
          { label: "Request a Quote", href: "/request-a-quote", desc: "Upload CAD and prints" },
        ]}
      />

      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            serviceJsonLd({ name: industry.name, description: industry.metaDescription, path }),
          ),
        }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd(industry.faqs)) }}
      />
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            breadcrumbJsonLd([
              { name: "Home", path: "/" },
              { name: "Industries", path: "/industries/aerospace-cnc-machining" },
              { name: industry.navLabel, path },
            ]),
          ),
        }}
      />
      <Link href="/request-a-quote" className="sr-only">
        Request a quote from Gretna Machine Shop
      </Link>
    </>
  );
}
