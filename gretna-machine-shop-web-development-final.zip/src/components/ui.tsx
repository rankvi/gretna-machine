import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { company, machineGroups, processSteps } from "@/lib/company";
import { img } from "@/lib/images";
import { materialFamilies } from "@/lib/materials";

export function Container({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`container-x ${className}`}>{children}</div>;
}

export function Eyebrow({
  children,
  tone = "red",
}: {
  children: ReactNode;
  tone?: "red" | "light" | "blue";
}) {
  const color =
    tone === "light" ? "text-white/70" : tone === "blue" ? "text-brand-blue" : "text-brand-red";
  return (
    <p className={`flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] ${color}`}>
      <span
        className={`inline-block h-px w-6 ${tone === "light" ? "bg-white/50" : "bg-current opacity-60"}`}
      />
      {children}
    </p>
  );
}

export function Button({
  href,
  children,
  variant = "primary",
  className = "",
  target,
}: {
  href: string;
  children: ReactNode;
  variant?: "primary" | "outline" | "ghost" | "white";
  className?: string;
  target?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-sm px-5 py-3 text-[13px] font-bold uppercase tracking-[0.08em] transition-colors duration-200";
  const styles = {
    primary: "bg-brand-red text-white hover:bg-brand-red-dark shadow-sm",
    outline: "border border-brand-blue/40 text-brand-blue hover:border-brand-blue hover:bg-brand-blue-light",
    ghost: "border border-white/40 text-white hover:bg-white/10",
    white: "bg-white text-brand-blue hover:bg-brand-blue-light",
  }[variant];
  const external = href.startsWith("http") || href.startsWith("tel:") || href.startsWith("mailto:");
  const content = (
    <>
      {children}
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </>
  );
  if (external) {
    return (
      <a
        href={href}
        target={target ?? (href.startsWith("http") ? "_blank" : undefined)}
        rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
        className={`${base} ${styles} ${className}`}
      >
        {content}
      </a>
    );
  }
  return (
    <Link href={href} className={`${base} ${styles} ${className}`}>
      {content}
    </Link>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  tone = "dark",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  tone?: "dark" | "light";
}) {
  return (
    <div className={`${align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl"} mb-10`}>
      {eyebrow && (
        <p
          className={`mb-3 text-[11px] font-bold uppercase tracking-[0.22em] ${
            tone === "light" ? "text-white/60" : "text-brand-red"
          } ${align === "center" ? "flex justify-center" : ""}`}
        >
          {eyebrow}
        </p>
      )}
      <h2
        className={`text-3xl font-extrabold leading-[1.12] sm:text-[2.35rem] ${
          tone === "light" ? "text-white" : "text-ink"
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p
          className={`mt-4 text-[15px] leading-relaxed ${
            tone === "light" ? "text-white/75" : "text-slate-body"
          }`}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}

export function ClientTag({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded border border-dashed border-amber-500/70 bg-amber-50 px-2.5 py-1 text-[10.5px] font-bold uppercase leading-tight tracking-[0.06em] text-amber-900">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 8v5m0 3.5v.5" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
      </svg>
      {children}
    </span>
  );
}

export function CheckList({
  items,
  tone = "dark",
}: {
  items: string[];
  tone?: "dark" | "light";
}) {
  return (
    <ul className="space-y-2.5">
      {items.map((item) => (
        <li key={item} className="flex gap-2.5 text-[14px] leading-snug">
          <svg
            width="17"
            height="17"
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden="true"
            className={`mt-0.5 shrink-0 ${tone === "light" ? "text-white" : "text-brand-red"}`}
          >
            <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12" />
            <path d="m7.5 12.5 3 3 6-6.5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className={tone === "light" ? "text-white/85" : "text-slate-body"}>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export function PageHero({
  breadcrumbs,
  eyebrow,
  h1,
  intro,
  usps,
  badges,
  image,
  imageAlt,
  primary = { href: "/request-a-quote", label: "Request a Quote" },
  secondary,
  microTrust = "[Client to Provide: Quote Turnaround Time] • ITAR Compliant",
}: {
  breadcrumbs: { name: string; href: string }[];
  eyebrow: string;
  h1: string;
  intro: string;
  usps: string[];
  badges: string[];
  image: string;
  imageAlt: string;
  primary?: { href: string; label: string };
  secondary?: { href: string; label: string };
  microTrust?: string;
}) {
  return (
    <section className="relative border-b border-line bg-paper">
      <div className="border-b border-line bg-white">
        <Container className="flex items-center gap-2 py-3 text-[11.5px] text-slate-500">
          <Link href="/" className="hover:text-brand-red">
            Home
          </Link>
          {breadcrumbs.map((b, i) => (
            <span key={b.href} className="flex items-center gap-2">
              <span className="text-slate-300">/</span>
              {i === breadcrumbs.length - 1 ? (
                <span className="font-medium text-ink">{b.name}</span>
              ) : (
                <Link href={b.href} className="hover:text-brand-red">
                  {b.name}
                </Link>
              )}
            </span>
          ))}
        </Container>
      </div>

      <Container>
        <div className="grid items-center gap-8 py-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-12 lg:py-14">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-sm bg-brand-blue-dark px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-white">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-brand-red" />
              {eyebrow}
            </p>
            <h1 className="max-w-2xl text-[2.15rem] font-extrabold leading-[1.06] text-ink sm:text-[2.7rem] lg:text-[3rem]">
              {h1}
            </h1>
            <p className="mt-4 max-w-xl text-[15.5px] leading-relaxed text-slate-body">{intro}</p>

            <div className="mt-6 max-w-xl">{usps.length > 0 && <CheckList items={usps} />}</div>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Button href={primary.href}>{primary.label}</Button>
              {secondary && (
                <Button href={secondary.href} variant="outline">
                  {secondary.label}
                </Button>
              )}
            </div>

            <p className="mt-4 text-[11.5px] font-semibold uppercase tracking-[0.1em] text-slate-500">
              {microTrust}
            </p>

            <div className="mt-6 flex flex-wrap gap-1.5">
              {badges.map((b) => (
                <span
                  key={b}
                  className="rounded-sm border border-brand-blue/15 bg-white px-2 py-1 text-[10px] font-bold uppercase tracking-[0.1em] text-brand-blue"
                >
                  {b}
                </span>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="relative min-h-[280px] overflow-hidden rounded-sm border border-line bg-brand-blue-dark shadow-xl sm:min-h-[360px] lg:min-h-[420px]">
              <Image src={image} alt={imageAlt} fill priority sizes="(max-width: 1024px) 100vw, 48vw" className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/85 via-brand-blue-dark/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <div className="flex flex-wrap items-center gap-2 rounded-sm border border-white/15 bg-brand-blue-dark/80 px-3 py-2 backdrop-blur">
                  <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/60">
                    Houston, TX
                  </span>
                  <span className="h-3 w-px bg-white/25" />
                  <span className="text-[11px] font-semibold text-white">
                    50,000 sq. ft. • AS9100 Rev D • ITAR • HUBZone • WOSB
                  </span>
                </div>
              </div>
            </div>
            <div className="absolute -left-3 top-5 hidden rotate-0 rounded-sm bg-brand-red px-3 py-2 text-[10px] font-bold uppercase tracking-[0.16em] text-white shadow-lg lg:block">
              CAGE {company.identifiers.cage}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export function CtaBand({
  title = "Have Prints Ready? Send Us Your Specs.",
  body = "Upload CAD and prints for engineering review. Our team responds with manufacturability feedback and pricing.",
  primary = { href: "/request-a-quote", label: "Request a Quote" },
  secondary = { href: `tel:${company.phoneHref}`, label: `Call ${company.phone}` },
  image = img.caliper,
}: {
  title?: string;
  body?: string;
  primary?: { href: string; label: string };
  secondary?: { href: string; label: string };
  image?: string;
}) {
  return (
    <section className="bg-brand-blue-dark">
      <Container>
        <div className="grid items-center gap-6 py-10 lg:grid-cols-[auto_1fr_auto] lg:gap-10">
          <div className="relative hidden h-28 w-40 overflow-hidden rounded-sm border border-white/15 lg:block">
            <Image src={image} alt="Precision machined component ready for inspection" fill sizes="160px" className="object-cover" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold leading-tight text-white sm:text-2xl">{title}</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-white/70">{body}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button href={primary.href}>{primary.label}</Button>
            <Button href={secondary.href} variant="ghost">
              {secondary.label}
            </Button>
          </div>
        </div>
      </Container>
    </section>
  );
}

export function ProcessCards({ tone = "light" }: { tone?: "light" | "dark" }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {processSteps.map((s) => (
        <div
          key={s.step}
          className={`relative rounded-sm border p-6 ${
            tone === "dark"
              ? "border-white/15 bg-white/5"
              : "border-line bg-brand-blue-light/40"
          }`}
        >
          <span className="text-[26px] font-black leading-none tracking-tight text-brand-red/25">
            {s.step}
          </span>
          <h3 className={`mt-2 text-[17px] font-bold ${tone === "dark" ? "text-white" : "text-ink"}`}>
            {s.title}
          </h3>
          <p className={`mt-2 text-[13.5px] leading-relaxed ${tone === "dark" ? "text-white/70" : "text-slate-body"}`}>
            {s.body}
          </p>
        </div>
      ))}
    </div>
  );
}

export function MachineSpecTable({ groupIds }: { groupIds: string[] }) {
  const groups = machineGroups.filter((g) => groupIds.includes(g.id));
  return (
    <div className="space-y-8">
      {groups.map((group) => (
        <div key={group.id} className="overflow-hidden rounded-sm border border-line bg-white">
          <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line bg-brand-blue-light/50 px-4 py-3">
            <h3 className="text-[15px] font-extrabold uppercase tracking-[0.06em] text-brand-blue">
              {group.label}
            </h3>
            <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              {group.rows.length} {group.rows.length === 1 ? "platform" : "platforms"}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] border-collapse text-left">
              <thead>
                <tr className="bg-white text-[10.5px] uppercase tracking-[0.12em] text-slate-500">
                  <th className="px-4 py-2.5 font-bold">Machine</th>
                  <th className="px-4 py-2.5 font-bold">Spindle / Control</th>
                  <th className="px-4 py-2.5 font-bold">Travels / Capacity</th>
                  <th className="px-4 py-2.5 font-bold">Envelope / Notes</th>
                </tr>
              </thead>
              <tbody>
                {group.rows.map((row) => (
                  <tr key={row.model} className="border-t border-line/80 align-top text-[13px]">
                    <td className="px-4 py-3 font-bold text-ink">{row.model}</td>
                    <td className="px-4 py-3 text-slate-body">{row.spindle}</td>
                    <td className="px-4 py-3 text-slate-body">{row.travels}</td>
                    <td className="px-4 py-3 text-slate-body">
                      {row.capacity}
                      {row.note && <span className="mt-1 block text-[12px] text-slate-500">{row.note}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
      <p className="flex flex-wrap items-center gap-2 text-[12px] text-slate-500">
        <ClientTag>[Client to Provide: Standard &amp; Tightest Tolerances]</ClientTag>
        <ClientTag>[Client to Provide: OTD % &amp; Quality Acceptance Rate]</ClientTag>
      </p>
    </div>
  );
}

export function MaterialMatrix() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {materialFamilies.map((m) => (
        <Link
          key={m.name}
          href={`/materials/${m.slug}`}
          className="group rounded-sm border border-line bg-white p-4 transition-colors hover:border-brand-red"
        >
          <h3 className="text-[14px] font-bold text-ink group-hover:text-brand-red">{m.name}</h3>
          <p className="mt-1.5 text-[12px] leading-relaxed text-slate-500">{m.grades}</p>
        </Link>
      ))}
    </div>
  );
}

export function CertStrip({ tone = "light" }: { tone?: "light" | "dark" }) {
  const items = ["AS9100 Rev D", "ISO 9001:2015", "ITAR Registered", "SBA HUBZone", "SBA WOSB", "WBENC", "SAM Registered", "CAGE 0AXC7"];
  return (
    <div className="flex flex-wrap items-center gap-2">
      {items.map((c) => (
        <span
          key={c}
          className={`rounded-sm border px-2.5 py-1.5 text-[10.5px] font-bold uppercase tracking-[0.1em] ${
            tone === "dark"
              ? "border-white/20 bg-white/5 text-white/80"
              : "border-line bg-white text-brand-blue"
          }`}
        >
          {c}
        </span>
      ))}
    </div>
  );
}

export function StatRow({
  items,
}: {
  items: { stat: string; label: string; note?: string }[];
}) {
  return (
    <div className="grid gap-px overflow-hidden rounded-sm border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
      {items.map((s) => (
        <div key={s.label} className="bg-white px-5 py-6 text-center">
          <p className="text-[26px] font-black leading-none tracking-tight text-brand-blue">{s.stat}</p>
          <p className="mt-2 text-[11.5px] font-bold uppercase leading-tight tracking-[0.08em] text-slate-500">
            {s.label}
          </p>
          {s.note && <p className="mt-1 text-[11px] text-slate-400">{s.note}</p>}
        </div>
      ))}
    </div>
  );
}
