"use client";

import Link from "next/link";
import { useState } from "react";
import { company } from "@/lib/company";
import { mainNav } from "@/lib/site";
import { Logo } from "./logo";

export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);

  return (
    <header className="sticky top-0 z-50">
      {/* Utility bar */}
      <div className="hidden bg-brand-blue-dark text-white lg:block">
        <div className="container-x flex items-center justify-between gap-6 py-2 text-[11px]">
          <div className="flex items-center gap-4">
            <a
              href="https://maps.google.com/?q=3450+Lang+Rd,+Houston,+TX+77092"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-white/75 hover:text-white"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z" stroke="currentColor" strokeWidth="2" />
                <circle cx="12" cy="10" r="2.5" stroke="currentColor" strokeWidth="2" />
              </svg>
              {company.address.full}
            </a>
            <span className="h-3 w-px bg-white/20" />
            <a href={`tel:${company.phoneHref}`} className="flex items-center gap-1.5 font-semibold text-white hover:text-brand-red">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinejoin="round"
                />
              </svg>
              {company.phone}
            </a>
            <span className="h-3 w-px bg-white/20" />
            <span className="text-white/60">Mon–Fri, 7:00 AM – 4:30 PM CST</span>
          </div>
          <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.14em] text-white/70">
            <span>CAGE: {company.identifiers.cage}</span>
            <span className="h-3 w-px bg-white/20" />
            <span>AS9100D • ISO 9001 • ITAR • HUBZone • WOSB</span>
          </div>
        </div>
      </div>

      {/* Main bar */}
      <div className="border-b border-line bg-white/95 shadow-sm backdrop-blur">
        <div className="container-x flex items-center justify-between gap-4 py-3">
          <Logo />

          <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
            {mainNav.map((group) => (
              <div key={group.label} className="group relative">
                <Link
                  href={group.href}
                  className="flex items-center gap-1 rounded-sm px-2.5 py-2 text-[12.5px] font-bold uppercase tracking-[0.05em] text-ink transition-colors hover:text-brand-red"
                >
                  {group.label}
                  <svg width="9" height="9" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="mt-0.5 opacity-50">
                    <path d="m6 9 6 6 6-6" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                  </svg>
                </Link>
                <div className="invisible absolute left-0 top-full z-50 w-[430px] translate-y-1 rounded-sm border border-line bg-white p-4 opacity-0 shadow-2xl transition-all duration-150 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100">
                  <div className={`grid gap-5 ${group.groups.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                    {group.groups.map((sub) => (
                      <div key={sub.heading}>
                        <p className="mb-2 border-b border-line pb-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-brand-red">
                          {sub.heading}
                        </p>
                        <ul className="space-y-1">
                          {sub.links.map((link) => (
                            <li key={link.href}>
                              <Link
                                href={link.href}
                                className="block rounded-sm px-1.5 py-1.5 text-[12.5px] font-medium text-slate-body hover:bg-brand-blue-light/60 hover:text-brand-blue"
                              >
                                {link.label}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                  <Link
                    href="/request-a-quote"
                    className="mt-3 block rounded-sm bg-brand-blue-light px-2.5 py-2 text-[11px] font-bold uppercase tracking-[0.1em] text-brand-blue hover:bg-brand-blue hover:text-white"
                  >
                    Request a Quote →
                  </Link>
                </div>
              </div>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${company.phoneHref}`}
              className="hidden items-center gap-2 rounded-sm border border-brand-blue/25 px-3 py-2 text-[12px] font-bold text-brand-blue hover:border-brand-blue lg:flex xl:hidden"
              aria-label={`Call ${company.phone}`}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path
                  d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinejoin="round"
                />
              </svg>
              Call
            </a>
            <Link
              href="/request-a-quote"
              className="hidden rounded-sm bg-brand-red px-4 py-2.5 text-[12px] font-bold uppercase tracking-[0.08em] text-white shadow-sm hover:bg-brand-red-dark sm:inline-flex"
            >
              Request a Quote
            </Link>
            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              aria-expanded={mobileOpen}
              aria-label="Toggle navigation menu"
              className="inline-flex h-10 w-10 items-center justify-center rounded-sm border border-line text-ink lg:hidden"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                {mobileOpen ? (
                  <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                ) : (
                  <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile panel */}
      {mobileOpen && (
        <div className="max-h-[calc(100vh-70px)] overflow-y-auto border-b border-line bg-white shadow-xl lg:hidden">
          <div className="container-x py-3">
            {mainNav.map((group) => {
              const isOpen = openGroup === group.label;
              return (
                <div key={group.label} className="border-b border-line/70 py-1">
                  <button
                    type="button"
                    onClick={() => setOpenGroup(isOpen ? null : group.label)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between py-2.5 text-left text-[13.5px] font-bold uppercase tracking-[0.04em] text-ink"
                  >
                    {group.label}
                    <span className="text-brand-red">{isOpen ? "−" : "+"}</span>
                  </button>
                  {isOpen && (
                    <div className="pb-2">
                      {group.groups.map((sub) => (
                        <div key={sub.heading} className="mb-2">
                          <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                            {sub.heading}
                          </p>
                          {sub.links.map((link) => (
                            <Link
                              key={link.href}
                              href={link.href}
                              onClick={() => setMobileOpen(false)}
                              className="block rounded-sm px-2 py-1.5 text-[13px] text-slate-body hover:bg-brand-blue-light"
                            >
                              {link.label}
                            </Link>
                          ))}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            <div className="mt-3 grid gap-2 pb-3 sm:grid-cols-2">
              <Link
                href="/request-a-quote"
                onClick={() => setMobileOpen(false)}
                className="rounded-sm bg-brand-red px-4 py-3 text-center text-[12px] font-bold uppercase tracking-[0.08em] text-white"
              >
                Request a Quote
              </Link>
              <a
                href={`tel:${company.phoneHref}`}
                className="rounded-sm border border-brand-blue px-4 py-3 text-center text-[12px] font-bold uppercase tracking-[0.08em] text-brand-blue"
              >
                Call {company.phone}
              </a>
            </div>
            <p className="pb-3 text-[11px] text-slate-500">
              {company.address.full} • CAGE {company.identifiers.cage}
            </p>
          </div>
        </div>
      )}
    </header>
  );
}
