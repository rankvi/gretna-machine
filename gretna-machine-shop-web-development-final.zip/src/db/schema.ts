import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * RFQ submissions captured by /request-a-quote.
 * CAD / print files are validated server-side; metadata is stored so the
 * sales team can follow up on the originating package.
 */
export const rfqs = pgTable("rfqs", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 32 }).notNull().unique(),
  firstName: varchar("first_name", { length: 120 }).notNull(),
  lastName: varchar("last_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }),
  company: varchar("company", { length: 200 }).notNull(),
  industry: varchar("industry", { length: 120 }),
  services: jsonb("services").$type<string[]>().default([]).notNull(),
  material: varchar("material", { length: 200 }),
  quantity: varchar("quantity", { length: 120 }),
  targetDelivery: varchar("target_delivery", { length: 120 }),
  qualityDocs: jsonb("quality_docs").$type<string[]>().default([]).notNull(),
  itarControlled: boolean("itar_controlled").default(false).notNull(),
  notes: text("notes"),
  fileNames: jsonb("file_names").$type<string[]>().default([]).notNull(),
  status: varchar("status", { length: 40 }).default("new").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  kind: varchar("kind", { length: 40 }).default("contact").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }),
  role: varchar("role", { length: 120 }),
  subject: varchar("subject", { length: 200 }),
  message: text("message").notNull(),
  resumeName: varchar("resume_name", { length: 240 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const pageEnquiries = pgTable("page_enquiries", {
  id: serial("id").primaryKey(),
  path: varchar("path", { length: 240 }).notNull(),
  count: integer("count").default(0).notNull(),
});
